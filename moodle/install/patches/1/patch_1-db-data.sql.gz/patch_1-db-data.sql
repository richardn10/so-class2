SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SHOW TABLES;
SELECT COUNT(*) FROM message WHERE useridto = '2' AND timecreated > '0';
SELECT value FROM config WHERE name = 'release' LIMIT 1;
SHOW LOCAL VARIABLES LIKE 'character_set_database';
select version();
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343010 AND timemodified > 1254341115;
SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SHOW TABLES;
SELECT COUNT(*) FROM message WHERE useridto = '2' AND timecreated > '0';
SELECT name FROM modules;
SELECT name FROM block;
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343014 AND timemodified > 1254341115;
SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SHOW TABLES;
SELECT COUNT(*) FROM message WHERE useridto = '2' AND timecreated > '0';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/course:update'
                       AND rc.roleid = r.id AND (rc.contextid = '1' OR  rc.contextid IN (1)) AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '3' AND capability = 'moodle/course:visibility' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
SELECT * FROM role_capabilities WHERE id = '-1';
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 3, 'moodle/course:visibility', 1, 1254343021, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'moodle/course:visibility' LIMIT 1;
SELECT * FROM cache_flags WHERE name = '/1' AND flagtype = 'accesslib/dirtycontexts' LIMIT 1;
SHOW COLUMNS FROM `cache_flags`;
UPDATE cache_flags SET flagtype = 'accesslib/dirtycontexts',name = '/1',timemodified = '1254343021',value = '1',expiry = '1254350221' WHERE id = 1;
SELECT name FROM config WHERE name = 'version' LIMIT 1;
UPDATE config SET value = '2007101532.1' WHERE name = 'version';
SELECT * FROM capabilities WHERE name LIKE 'moodle/%:%';
SHOW COLUMNS FROM `capabilities`;
UPDATE capabilities SET riskbitmask = '8' WHERE id = 74;
SHOW COLUMNS FROM `capabilities`;
UPDATE capabilities SET riskbitmask = '0' WHERE id = 91;
SELECT * FROM capabilities WHERE id = '-1';
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'moodle/category:manage', 'write', 40, 'moodle', 4 );
SELECT * FROM role_capabilities WHERE capability = 'moodle/category:update';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'moodle/category:manage' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'moodle/category:manage', 1, 1254343021, 2 );
SELECT LAST_INSERT_ID();
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'moodle/category:viewhiddencategories', 'read', 40, 'moodle', 0 );
SELECT * FROM role_capabilities WHERE capability = 'moodle/category:visibility';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'moodle/category:viewhiddencategories' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'moodle/category:viewhiddencategories', 1, 1254343021, 2 );
SELECT LAST_INSERT_ID();
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'moodle/course:request', 'write', 10, 'moodle', 0 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:user'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '7' AND capability = 'moodle/course:request' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 7, 'moodle/course:request', 1, 1254343021, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'moodle/%:%';
DELETE FROM capabilities WHERE name = 'moodle/category:create';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/category:create'
                       AND rc.roleid = r.id ;
DELETE FROM role_capabilities WHERE capability = 'moodle/category:create' AND roleid = '1';
DELETE FROM capabilities WHERE name = 'moodle/category:delete';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/category:delete'
                       AND rc.roleid = r.id ;
DELETE FROM role_capabilities WHERE capability = 'moodle/category:delete' AND roleid = '1';
DELETE FROM capabilities WHERE name = 'moodle/category:update';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/category:update'
                       AND rc.roleid = r.id ;
DELETE FROM role_capabilities WHERE capability = 'moodle/category:update' AND roleid = '1';
DELETE FROM capabilities WHERE name = 'moodle/category:visibility';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/category:visibility'
                       AND rc.roleid = r.id ;
DELETE FROM role_capabilities WHERE capability = 'moodle/category:visibility' AND roleid = '1';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'moodle';
SELECT name FROM config WHERE name = 'version' LIMIT 1;
UPDATE config SET value = '2007101540' WHERE name = 'version';
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343021 AND timemodified > 1254341115;
SELECT ctx.path, ra.roleid, rc.capability, rc.permission
            FROM role_assignments ra
            JOIN context ctx
               ON ra.contextid=ctx.id
            LEFT OUTER JOIN role_capabilities rc
               ON (rc.roleid=ra.roleid AND rc.contextid=ra.contextid)
            WHERE ra.userid = 2 AND ctx.contextlevel <= 50
            ORDER BY ctx.depth, ctx.path, ra.roleid;
SELECT sctx.path, ra.roleid,
                   ctx.path AS parentpath,
                   rco.capability, rco.permission
            FROM role_assignments ra
            JOIN context ctx
              ON ra.contextid=ctx.id
            JOIN context sctx
              ON (sctx.path LIKE CONCAT(ctx.path,'/%') )
            JOIN role_capabilities rco
              ON (rco.roleid=ra.roleid AND rco.contextid=sctx.id)
            WHERE ra.userid = 2
                  AND sctx.contextlevel <= 50
            ORDER BY sctx.depth, sctx.path, ra.roleid;
SELECT ctx.path,
                   rc.capability, rc.permission
            FROM context ctx
            JOIN role_capabilities rc
              ON rc.contextid=ctx.id
            WHERE rc.roleid = 7
                  AND ctx.contextlevel <= 50
            ORDER BY ctx.depth, ctx.path;
SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343022 AND timemodified > 1254341115;
SELECT ctx.path, ra.roleid, rc.capability, rc.permission
            FROM role_assignments ra
            JOIN context ctx
               ON ra.contextid=ctx.id
            LEFT OUTER JOIN role_capabilities rc
               ON (rc.roleid=ra.roleid AND rc.contextid=ra.contextid)
            WHERE ra.userid = 2 AND ctx.contextlevel <= 50
            ORDER BY ctx.depth, ctx.path, ra.roleid;
SELECT sctx.path, ra.roleid,
                   ctx.path AS parentpath,
                   rco.capability, rco.permission
            FROM role_assignments ra
            JOIN context ctx
              ON ra.contextid=ctx.id
            JOIN context sctx
              ON (sctx.path LIKE CONCAT(ctx.path,'/%') )
            JOIN role_capabilities rco
              ON (rco.roleid=ra.roleid AND rco.contextid=sctx.id)
            WHERE ra.userid = 2
                  AND sctx.contextlevel <= 50
            ORDER BY sctx.depth, sctx.path, ra.roleid;
SELECT ctx.path,
                   rc.capability, rc.permission
            FROM context ctx
            JOIN role_capabilities rc
              ON rc.contextid=ctx.id
            WHERE rc.roleid = 7
                  AND ctx.contextlevel <= 50
            ORDER BY ctx.depth, ctx.path;
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SELECT rc.id, rc.roleid, rc.permission, rc.capability,
                   ctx.depth AS ctxdepth, ctx.contextlevel AS ctxlevel
            FROM role_capabilities rc
            JOIN context ctx on rc.contextid = ctx.id
            
            WHERE rc.capability IN ('moodle/site:approvecourse','moodle/site:doanything') AND ctx.id IN (1)
                  
            ORDER BY rc.roleid ASC, ctx.depth ASC;
 SELECT u.id,u.username,u.firstname,u.lastname FROM user u
                    JOIN (SELECT DISTINCT ssra.userid
                          FROM role_assignments ssra
                          WHERE ssra.contextid IN (1)
                                AND ssra.roleid IN (1)
                                
                          ) ra ON ra.userid = u.id
                     WHERE u.deleted = 0 ORDER BY u.lastname,u.firstname ;
SELECT * FROM role ORDER BY sortorder ASC;
SELECT MAX(id), name FROM timezone GROUP BY name;
SELECT * FROM modules;
SELECT * FROM role WHERE id = '6' LIMIT 1;
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:student'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:user'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:guest'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role ORDER BY sortorder ASC;
SELECT * FROM modules;
SELECT * FROM glossary_formats WHERE name = 'continuous' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'dictionary' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'encyclopedia' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'entrylist' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'faq' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithauthor' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithoutauthor' LIMIT 1;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats WHERE id = '1' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '3' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '4' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '5' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '6' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '7' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '2' LIMIT 1;
SELECT name FROM config WHERE name = 'scorm_updatetime' LIMIT 1;
SELECT * FROM config WHERE id = '-1';
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_updatetime', '2' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_advancedsettings' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_advancedsettings', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_windowsettings' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_windowsettings', '0' );
SELECT LAST_INSERT_ID();
SELECT * FROM block;
SELECT name, 1 FROM capabilities;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT value FROM config WHERE name = 'cachetype' LIMIT 1;
SELECT value FROM config WHERE name = 'rcache' LIMIT 1;
SELECT value FROM config_plugins WHERE plugin = 'qtype_random' AND name = 'selectmanual' LIMIT 1;
SELECT value FROM config_plugins WHERE plugin = 'qtype_random' AND name = 'selectmanual' LIMIT 1;
SELECT * FROM block_instance WHERE pageid = '0' AND pagetype = 'admin' ORDER BY position, weight;
SELECT * FROM block;
SELECT COUNT(*) FROM message WHERE useridto = '2' AND timecreated > '0';
SELECT * FROM context WHERE contextlevel = '80' AND instanceid = '5' LIMIT 1;
SELECT ctx.path, ra.roleid
            FROM role_assignments ra
            JOIN context ctx
               ON ra.contextid=ctx.id
            WHERE ra.userid = 2
                  AND (ctx.path = '/1/8' OR ctx.path LIKE '/1/8/%')
            ORDER BY ctx.depth, ctx.path, ra.roleid;
SELECT ctx.path, rc.roleid, rc.capability, rc.permission
            FROM role_capabilities rc
            JOIN context ctx
             ON rc.contextid=ctx.id
            WHERE (rc.roleid IN (1,7) AND
                    (ctx.id=8 OR ctx.path LIKE '/1/8/%'))
                    
            ORDER BY ctx.depth ASC, ctx.path DESC, rc.roleid ASC ;
SELECT * FROM context WHERE contextlevel = '80' AND instanceid = '6' LIMIT 1;
SELECT ctx.path, ra.roleid
            FROM role_assignments ra
            JOIN context ctx
               ON ra.contextid=ctx.id
            WHERE ra.userid = 2
                  AND (ctx.path = '/1/9' OR ctx.path LIKE '/1/9/%')
            ORDER BY ctx.depth, ctx.path, ra.roleid;
SELECT ctx.path, rc.roleid, rc.capability, rc.permission
            FROM role_capabilities rc
            JOIN context ctx
             ON rc.contextid=ctx.id
            WHERE (rc.roleid IN (1,7) AND
                    (ctx.id=9 OR ctx.path LIKE '/1/9/%'))
                    
            ORDER BY ctx.depth ASC, ctx.path DESC, rc.roleid ASC ;
SELECT * FROM block_instance WHERE pageid = '0' AND pagetype = 'admin' ORDER BY position, weight;
SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343033 AND timemodified > 1254343020;
SELECT ctx.path, ra.roleid, rc.capability, rc.permission
            FROM role_assignments ra
            JOIN context ctx
               ON ra.contextid=ctx.id
            LEFT OUTER JOIN role_capabilities rc
               ON (rc.roleid=ra.roleid AND rc.contextid=ra.contextid)
            WHERE ra.userid = 2 AND ctx.contextlevel <= 50
            ORDER BY ctx.depth, ctx.path, ra.roleid;
SELECT sctx.path, ra.roleid,
                   ctx.path AS parentpath,
                   rco.capability, rco.permission
            FROM role_assignments ra
            JOIN context ctx
              ON ra.contextid=ctx.id
            JOIN context sctx
              ON (sctx.path LIKE CONCAT(ctx.path,'/%') )
            JOIN role_capabilities rco
              ON (rco.roleid=ra.roleid AND rco.contextid=sctx.id)
            WHERE ra.userid = 2
                  AND sctx.contextlevel <= 50
            ORDER BY sctx.depth, sctx.path, ra.roleid;
SELECT ctx.path,
                   rc.capability, rc.permission
            FROM context ctx
            JOIN role_capabilities rc
              ON rc.contextid=ctx.id
            WHERE rc.roleid = 7
                  AND ctx.contextlevel <= 50
            ORDER BY ctx.depth, ctx.path;
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SELECT rc.id, rc.roleid, rc.permission, rc.capability,
                   ctx.depth AS ctxdepth, ctx.contextlevel AS ctxlevel
            FROM role_capabilities rc
            JOIN context ctx on rc.contextid = ctx.id
            
            WHERE rc.capability IN ('moodle/site:approvecourse','moodle/site:doanything') AND ctx.id IN (1)
                  
            ORDER BY rc.roleid ASC, ctx.depth ASC;
 SELECT u.id,u.username,u.firstname,u.lastname FROM user u
                    JOIN (SELECT DISTINCT ssra.userid
                          FROM role_assignments ssra
                          WHERE ssra.contextid IN (1)
                                AND ssra.roleid IN (1)
                                
                          ) ra ON ra.userid = u.id
                     WHERE u.deleted = 0 ORDER BY u.lastname,u.firstname ;
SELECT * FROM role ORDER BY sortorder ASC;
SELECT MAX(id), name FROM timezone GROUP BY name;
SELECT * FROM modules;
SELECT * FROM role WHERE id = '6' LIMIT 1;
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:student'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:user'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:guest'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role ORDER BY sortorder ASC;
SELECT * FROM modules;
SELECT * FROM glossary_formats WHERE name = 'continuous' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'dictionary' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'encyclopedia' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'entrylist' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'faq' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithauthor' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithoutauthor' LIMIT 1;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats WHERE id = '1' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '3' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '4' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '5' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '6' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '7' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '2' LIMIT 1;
SELECT * FROM block;
SELECT name, 1 FROM capabilities;
SELECT * FROM backup_config;
SELECT name FROM backup_config WHERE name = 'backup_sche_gradebook_history' LIMIT 1;
SELECT * FROM backup_config WHERE id = '-1';
INSERT INTO backup_config ( NAME, VALUE ) VALUES ( 'backup_sche_gradebook_history', '0' );
SELECT LAST_INSERT_ID();
SELECT * FROM backup_config;
SELECT name FROM config WHERE name = 'forum_ajaxrating' LIMIT 1;
SELECT * FROM config WHERE id = '-1';
INSERT INTO config ( NAME, VALUE ) VALUES ( 'forum_ajaxrating', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_grademethod' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_grademethod', '1' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_maxgrade' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_maxgrade', '100' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_maxattempts' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_maxattempts', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_whatgrade' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_whatgrade', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_popup' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_popup', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_resizable' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_resizable', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_scrollbars' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_scrollbars', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_directories' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_directories', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_location' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_location', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_menubar' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_menubar', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_toolbar' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_toolbar', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_status' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_status', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_skipview' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_skipview', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_hidebrowse' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_hidebrowse', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_hidetoc' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_hidetoc', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_hidenav' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_hidenav', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_auto' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_auto', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'scorm_updatefreq' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'scorm_updatefreq', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'profilesforenrolledusersonly' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'profilesforenrolledusersonly', '1' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'enablenotes' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'enablenotes', '1' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'enablecalendarexport' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'enablecalendarexport', '1' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'calendar_exportsalt' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'calendar_exportsalt', 'DUx47bCWUYxuJopovdQp31vCYHRjQbrn4XgrbGyuzTbY7MK4DGowePEWx7l4' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'maxcategorydepth' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'maxcategorydepth', '0' );
SELECT LAST_INSERT_ID();
SELECT value FROM config_plugins WHERE plugin = 'qtype_random' AND name = 'selectmanual' LIMIT 1;
SELECT id FROM config_plugins WHERE name = 'selectmanual' AND plugin = 'qtype_random' LIMIT 1;
SELECT * FROM config_plugins WHERE id = '-1';
INSERT INTO config_plugins ( PLUGIN, NAME, VALUE ) VALUES ( 'qtype_random', 'selectmanual', '0' );
SELECT LAST_INSERT_ID();
SELECT value FROM config_plugins WHERE plugin = 'qtype_random' AND name = 'selectmanual' LIMIT 1;
SELECT * FROM course WHERE id = '1' LIMIT 1;
SELECT rc.id, rc.roleid, rc.permission, rc.capability,
                   ctx.depth AS ctxdepth, ctx.contextlevel AS ctxlevel
            FROM role_capabilities rc
            JOIN context ctx on rc.contextid = ctx.id
            
            WHERE rc.capability IN ('moodle/site:approvecourse','moodle/site:doanything') AND ctx.id IN (1)
                  
            ORDER BY rc.roleid ASC, ctx.depth ASC;
 SELECT u.id,u.username,u.firstname,u.lastname FROM user u
                    JOIN (SELECT DISTINCT ssra.userid
                          FROM role_assignments ssra
                          WHERE ssra.contextid IN (1)
                                AND ssra.roleid IN (1)
                                
                          ) ra ON ra.userid = u.id
                     WHERE u.deleted = 0 ORDER BY u.lastname,u.firstname ;
SELECT * FROM role ORDER BY sortorder ASC;
SELECT * FROM modules;
SELECT * FROM role WHERE id = '6' LIMIT 1;
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:student'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:user'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:guest'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role ORDER BY sortorder ASC;
SELECT * FROM modules;
SELECT * FROM glossary_formats WHERE name = 'continuous' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'dictionary' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'encyclopedia' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'entrylist' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'faq' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithauthor' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithoutauthor' LIMIT 1;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats WHERE id = '1' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '3' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '4' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '5' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '6' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '7' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '2' LIMIT 1;
SELECT * FROM block;
SELECT rc.id, rc.roleid, rc.permission, rc.capability,
                   ctx.depth AS ctxdepth, ctx.contextlevel AS ctxlevel
            FROM role_capabilities rc
            JOIN context ctx on rc.contextid = ctx.id
            
            WHERE rc.capability IN ('moodle/site:approvecourse','moodle/site:doanything') AND ctx.id IN (1)
                  
            ORDER BY rc.roleid ASC, ctx.depth ASC;
 SELECT u.id,u.username,u.firstname,u.lastname FROM user u
                    JOIN (SELECT DISTINCT ssra.userid
                          FROM role_assignments ssra
                          WHERE ssra.contextid IN (1)
                                AND ssra.roleid IN (1)
                                
                          ) ra ON ra.userid = u.id
                     WHERE u.deleted = 0 ORDER BY u.lastname,u.firstname ;
SELECT * FROM role ORDER BY sortorder ASC;
SELECT * FROM modules;
SELECT * FROM role WHERE id = '6' LIMIT 1;
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:student'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:user'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:guest'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role ORDER BY sortorder ASC;
SELECT * FROM modules;
SELECT * FROM glossary_formats WHERE name = 'continuous' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'dictionary' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'encyclopedia' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'entrylist' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'faq' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithauthor' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithoutauthor' LIMIT 1;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats WHERE id = '1' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '3' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '4' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '5' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '6' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '7' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '2' LIMIT 1;
SELECT * FROM block;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT value FROM config WHERE name = 'cachetype' LIMIT 1;
SELECT value FROM config WHERE name = 'rcache' LIMIT 1;
SELECT value FROM config_plugins WHERE plugin = 'qtype_random' AND name = 'selectmanual' LIMIT 1;
SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SHOW TABLES;
SELECT name FROM config WHERE name = 'release' LIMIT 1;
UPDATE config SET value = '1.9.4 (Build: 20090128)' WHERE name = 'release';
SELECT * FROM modules WHERE name = 'assignment' LIMIT 1;
SELECT * FROM modules WHERE name = 'chat' LIMIT 1;
SELECT COUNT(*) FROM message WHERE useridto = '2' AND timecreated > '0';
SHOW COLUMNS FROM `modules`;
UPDATE modules SET name = 'chat',version = '2007101510',cron = '300' WHERE id = 2;
SELECT * FROM capabilities WHERE name LIKE 'mod/chat:%';
SELECT * FROM capabilities WHERE id = '-1';
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'mod/chat:talk', 'write', 70, 'mod/chat', 16 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:student'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '5' AND capability = 'mod/chat:talk' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
SELECT * FROM role_capabilities WHERE id = '-1';
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 5, 'mod/chat:talk', 1, 1254343034, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:teacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '4' AND capability = 'mod/chat:talk' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 4, 'mod/chat:talk', 1, 1254343034, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:editingteacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '3' AND capability = 'mod/chat:talk' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 3, 'mod/chat:talk', 1, 1254343034, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'mod/chat:talk' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'mod/chat:talk', 1, 1254343034, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'mod/chat:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'mod/chat';
SELECT * FROM modules WHERE name = 'choice' LIMIT 1;
SELECT * FROM modules WHERE name = 'data' LIMIT 1;
SELECT value FROM config_plugins WHERE plugin = 'data' AND name = 'requiredentriesfixflag' LIMIT 1;
SELECT id FROM config_plugins WHERE name = 'requiredentriesfixflag' AND plugin = 'data' LIMIT 1;
SELECT * FROM config_plugins WHERE id = '-1';
INSERT INTO config_plugins ( PLUGIN, NAME, VALUE ) VALUES ( 'data', 'requiredentriesfixflag', '1' );
SELECT LAST_INSERT_ID();
SELECT d.*, c.fullname
                                              FROM data d, course c
                                              WHERE d.course = c.id
                                              AND (d.requiredentries > 0 OR d.requiredentriestoview > 0)
                                              ORDER BY c.fullname, d.name;
SHOW COLUMNS FROM `modules`;
UPDATE modules SET name = 'data',version = '2007101514',cron = '60' WHERE id = 4;
SELECT * FROM capabilities WHERE name LIKE 'mod/data:%';
SELECT * FROM capabilities WHERE name LIKE 'mod/data:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'mod/data';
SELECT * FROM modules WHERE name = 'forum' LIMIT 1;
SELECT * FROM modules WHERE name = 'glossary' LIMIT 1;
SELECT * FROM modules WHERE name = 'hotpot' LIMIT 1;
SELECT * FROM modules WHERE name = 'journal' LIMIT 1;
SELECT * FROM modules WHERE name = 'label' LIMIT 1;
SELECT * FROM modules WHERE name = 'lams' LIMIT 1;
SELECT * FROM modules WHERE name = 'lesson' LIMIT 1;
SHOW COLUMNS FROM `modules`;
UPDATE modules SET name = 'lesson',version = '2008112600',cron = '0' WHERE id = 11;
SELECT * FROM capabilities WHERE name LIKE 'mod/lesson:%';
SELECT * FROM capabilities WHERE name LIKE 'mod/lesson:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'mod/lesson';
SELECT * FROM modules WHERE name = 'quiz' LIMIT 1;
SELECT value FROM config_plugins WHERE plugin = 'qtype_random' AND name = 'selectmanual' LIMIT 1;
SELECT value FROM config_plugins WHERE plugin = 'qtype_random' AND name = 'selectmanual' LIMIT 1;
SHOW COLUMNS FROM `modules`;
UPDATE modules SET name = 'quiz',version = '2007101511',cron = '0' WHERE id = 12;
SELECT * FROM capabilities WHERE name LIKE 'mod/quiz:%';
SHOW COLUMNS FROM `capabilities`;
UPDATE capabilities SET riskbitmask = '16' WHERE id = 172;
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'mod/quiz:reviewmyattempts', 'read', 70, 'mod/quiz', 0 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:student'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '5' AND capability = 'mod/quiz:reviewmyattempts' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 5, 'mod/quiz:reviewmyattempts', 1, 1254343034, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'mod/quiz:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'mod/quiz';
SELECT * FROM modules WHERE name = 'resource' LIMIT 1;
SELECT * FROM modules WHERE name = 'scorm' LIMIT 1;
SHOW COLUMNS FROM `modules`;
UPDATE modules SET name = 'scorm',version = '2007110502',cron = '300' WHERE id = 14;
SELECT * FROM capabilities WHERE name LIKE 'mod/scorm:%';
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'mod/scorm:deleteresponses', 'read', 70, 'mod/scorm', 0 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:teacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '4' AND capability = 'mod/scorm:deleteresponses' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 4, 'mod/scorm:deleteresponses', 1, 1254343034, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:editingteacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '3' AND capability = 'mod/scorm:deleteresponses' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 3, 'mod/scorm:deleteresponses', 1, 1254343034, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'mod/scorm:deleteresponses' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'mod/scorm:deleteresponses', 1, 1254343034, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'mod/scorm:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'mod/scorm';
SELECT * FROM modules WHERE name = 'survey' LIMIT 1;
SELECT * FROM modules WHERE name = 'wiki' LIMIT 1;
SELECT * FROM modules WHERE name = 'workshop' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343034 AND timemodified > 1254343031;
SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SHOW TABLES;
SELECT * FROM modules WHERE name = 'assignment' LIMIT 1;
SELECT * FROM modules WHERE name = 'chat' LIMIT 1;
SELECT * FROM modules WHERE name = 'choice' LIMIT 1;
SELECT * FROM modules WHERE name = 'data' LIMIT 1;
SELECT * FROM modules WHERE name = 'forum' LIMIT 1;
SELECT * FROM modules WHERE name = 'glossary' LIMIT 1;
SELECT * FROM modules WHERE name = 'hotpot' LIMIT 1;
SELECT * FROM modules WHERE name = 'journal' LIMIT 1;
SELECT * FROM modules WHERE name = 'label' LIMIT 1;
SELECT * FROM modules WHERE name = 'lams' LIMIT 1;
SELECT * FROM modules WHERE name = 'lesson' LIMIT 1;
SELECT * FROM modules WHERE name = 'quiz' LIMIT 1;
SELECT * FROM modules WHERE name = 'resource' LIMIT 1;
SELECT * FROM modules WHERE name = 'scorm' LIMIT 1;
SELECT * FROM modules WHERE name = 'survey' LIMIT 1;
SELECT * FROM modules WHERE name = 'wiki' LIMIT 1;
SELECT * FROM modules WHERE name = 'workshop' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SELECT COUNT(*) FROM message WHERE useridto = '2' AND timecreated > '0';
SELECT name FROM config WHERE name = 'backup_version' LIMIT 1;
UPDATE config SET value = '2008030301' WHERE name = 'backup_version';
SELECT name FROM config WHERE name = 'backup_release' LIMIT 1;
UPDATE config SET value = '1.9.3' WHERE name = 'backup_release';
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343035 AND timemodified > 1254343031;
SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SHOW TABLES;
SELECT * FROM modules WHERE name = 'assignment' LIMIT 1;
SELECT * FROM modules WHERE name = 'chat' LIMIT 1;
SELECT * FROM modules WHERE name = 'choice' LIMIT 1;
SELECT * FROM modules WHERE name = 'data' LIMIT 1;
SELECT * FROM modules WHERE name = 'forum' LIMIT 1;
SELECT * FROM modules WHERE name = 'glossary' LIMIT 1;
SELECT * FROM modules WHERE name = 'hotpot' LIMIT 1;
SELECT * FROM modules WHERE name = 'journal' LIMIT 1;
SELECT * FROM modules WHERE name = 'label' LIMIT 1;
SELECT * FROM modules WHERE name = 'lams' LIMIT 1;
SELECT * FROM modules WHERE name = 'lesson' LIMIT 1;
SELECT * FROM modules WHERE name = 'quiz' LIMIT 1;
SELECT * FROM modules WHERE name = 'resource' LIMIT 1;
SELECT * FROM modules WHERE name = 'scorm' LIMIT 1;
SELECT * FROM modules WHERE name = 'survey' LIMIT 1;
SELECT * FROM modules WHERE name = 'wiki' LIMIT 1;
SELECT * FROM modules WHERE name = 'workshop' LIMIT 1;
SELECT COUNT(*) FROM block ;
SELECT * FROM block WHERE name = 'activity_modules' LIMIT 1;
SELECT * FROM block WHERE name = 'admin' LIMIT 1;
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343036 AND timemodified > 1254343031;
SELECT * FROM block WHERE name = 'admin_bookmarks' LIMIT 1;
SELECT * FROM block WHERE name = 'admin_tree' LIMIT 1;
SELECT * FROM block WHERE name = 'blog_menu' LIMIT 1;
SELECT * FROM block WHERE name = 'blog_tags' LIMIT 1;
SELECT * FROM block WHERE name = 'calendar_month' LIMIT 1;
SELECT * FROM block WHERE name = 'calendar_upcoming' LIMIT 1;
SELECT * FROM block WHERE name = 'course_list' LIMIT 1;
SELECT * FROM block WHERE name = 'course_summary' LIMIT 1;
SELECT * FROM block WHERE name = 'glossary_random' LIMIT 1;
SELECT * FROM block WHERE name = 'html' LIMIT 1;
SELECT * FROM block WHERE name = 'inline_flv' LIMIT 1;
SELECT * FROM block WHERE name = 'loancalc' LIMIT 1;
SELECT * FROM block WHERE name = 'login' LIMIT 1;
SELECT * FROM block WHERE name = 'mentees' LIMIT 1;
SELECT * FROM block WHERE name = 'messages' LIMIT 1;
SELECT * FROM block WHERE name = 'mnet_hosts' LIMIT 1;
SELECT * FROM block WHERE name = 'news_items' LIMIT 1;
SELECT * FROM block WHERE name = 'online_users' LIMIT 1;
SELECT COUNT(*) FROM message WHERE useridto = '2' AND timecreated > '0';
SHOW COLUMNS FROM `block`;
UPDATE block SET name = 'online_users',version = '2007101510',cron = '0' WHERE id = 19;
SELECT * FROM capabilities WHERE name LIKE 'block/online_users:%';
SELECT * FROM capabilities WHERE id = '-1';
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'block/online_users:viewlist', 'read', 80, 'block/online_users', 0 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:user'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '7' AND capability = 'block/online_users:viewlist' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
SELECT * FROM role_capabilities WHERE id = '-1';
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 7, 'block/online_users:viewlist', 1, 1254343036, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:guest'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '6' AND capability = 'block/online_users:viewlist' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 6, 'block/online_users:viewlist', 1, 1254343036, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:student'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '5' AND capability = 'block/online_users:viewlist' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 5, 'block/online_users:viewlist', 1, 1254343036, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:teacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '4' AND capability = 'block/online_users:viewlist' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 4, 'block/online_users:viewlist', 1, 1254343036, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:editingteacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '3' AND capability = 'block/online_users:viewlist' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 3, 'block/online_users:viewlist', 1, 1254343036, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'block/online_users:viewlist' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'block/online_users:viewlist', 1, 1254343036, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'block/online_users:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'block/online_users';
SELECT * FROM block WHERE name = 'participants' LIMIT 1;
SELECT * FROM block WHERE name = 'quiz_results' LIMIT 1;
SELECT * FROM block WHERE name = 'recent_activity' LIMIT 1;
SELECT * FROM block WHERE name = 'rss_client' LIMIT 1;
SELECT * FROM block WHERE name = 'search' LIMIT 1;
SELECT * FROM block WHERE name = 'search_forums' LIMIT 1;
SELECT * FROM block WHERE name = 'section_links' LIMIT 1;
SELECT * FROM block WHERE name = 'site_main_menu' LIMIT 1;
SELECT * FROM block WHERE name = 'social_activities' LIMIT 1;
SELECT * FROM block WHERE name = 'tag_flickr' LIMIT 1;
SELECT * FROM block WHERE name = 'tag_youtube' LIMIT 1;
SELECT * FROM block WHERE name = 'tags' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SHOW TABLES;
SELECT * FROM modules WHERE name = 'assignment' LIMIT 1;
SELECT * FROM modules WHERE name = 'chat' LIMIT 1;
SELECT * FROM modules WHERE name = 'choice' LIMIT 1;
SELECT * FROM modules WHERE name = 'data' LIMIT 1;
SELECT * FROM modules WHERE name = 'forum' LIMIT 1;
SELECT * FROM modules WHERE name = 'glossary' LIMIT 1;
SELECT * FROM modules WHERE name = 'hotpot' LIMIT 1;
SELECT * FROM modules WHERE name = 'journal' LIMIT 1;
SELECT * FROM modules WHERE name = 'label' LIMIT 1;
SELECT * FROM modules WHERE name = 'lams' LIMIT 1;
SELECT * FROM modules WHERE name = 'lesson' LIMIT 1;
SELECT * FROM modules WHERE name = 'quiz' LIMIT 1;
SELECT * FROM modules WHERE name = 'resource' LIMIT 1;
SELECT * FROM modules WHERE name = 'scorm' LIMIT 1;
SELECT * FROM modules WHERE name = 'survey' LIMIT 1;
SELECT * FROM modules WHERE name = 'wiki' LIMIT 1;
SELECT * FROM modules WHERE name = 'workshop' LIMIT 1;
SELECT COUNT(*) FROM block ;
SELECT * FROM block WHERE name = 'activity_modules' LIMIT 1;
SELECT * FROM block WHERE name = 'admin' LIMIT 1;
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343037 AND timemodified > 1254343031;
SELECT * FROM block WHERE name = 'admin_bookmarks' LIMIT 1;
SELECT * FROM block WHERE name = 'admin_tree' LIMIT 1;
SELECT * FROM block WHERE name = 'blog_menu' LIMIT 1;
SELECT * FROM block WHERE name = 'blog_tags' LIMIT 1;
SELECT * FROM block WHERE name = 'calendar_month' LIMIT 1;
SELECT * FROM block WHERE name = 'calendar_upcoming' LIMIT 1;
SELECT * FROM block WHERE name = 'course_list' LIMIT 1;
SELECT * FROM block WHERE name = 'course_summary' LIMIT 1;
SELECT * FROM block WHERE name = 'glossary_random' LIMIT 1;
SELECT * FROM block WHERE name = 'html' LIMIT 1;
SELECT * FROM block WHERE name = 'inline_flv' LIMIT 1;
SELECT * FROM block WHERE name = 'loancalc' LIMIT 1;
SELECT * FROM block WHERE name = 'login' LIMIT 1;
SELECT * FROM block WHERE name = 'mentees' LIMIT 1;
SELECT * FROM block WHERE name = 'messages' LIMIT 1;
SELECT * FROM block WHERE name = 'mnet_hosts' LIMIT 1;
SELECT * FROM block WHERE name = 'news_items' LIMIT 1;
SELECT * FROM block WHERE name = 'online_users' LIMIT 1;
SELECT * FROM block WHERE name = 'participants' LIMIT 1;
SELECT * FROM block WHERE name = 'quiz_results' LIMIT 1;
SELECT * FROM block WHERE name = 'recent_activity' LIMIT 1;
SELECT * FROM block WHERE name = 'rss_client' LIMIT 1;
SELECT * FROM block WHERE name = 'search' LIMIT 1;
SELECT * FROM block WHERE name = 'search_forums' LIMIT 1;
SELECT * FROM block WHERE name = 'section_links' LIMIT 1;
SELECT * FROM block WHERE name = 'site_main_menu' LIMIT 1;
SELECT * FROM block WHERE name = 'social_activities' LIMIT 1;
SELECT * FROM block WHERE name = 'tag_flickr' LIMIT 1;
SELECT * FROM block WHERE name = 'tag_youtube' LIMIT 1;
SELECT * FROM block WHERE name = 'tags' LIMIT 1;
SELECT * FROM mnet_rpc WHERE  parent='workshop' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='glossary' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='hotpot' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='data' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='chat' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='wiki' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='scorm' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='journal' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='forum' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='lams' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='survey' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='quiz' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='choice' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='label' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='resource' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='assignment' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='lesson' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='nologin' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/pop3';
SELECT * FROM mnet_rpc WHERE  parent='pop3' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/nntp';
SELECT * FROM mnet_rpc WHERE  parent='nntp' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/manual';
SELECT * FROM mnet_rpc WHERE  parent='manual' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/shibboleth';
SELECT * FROM mnet_rpc WHERE  parent='shibboleth' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/fc';
SELECT * FROM mnet_rpc WHERE  parent='fc' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/email';
SELECT * FROM mnet_rpc WHERE  parent='email' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/cas';
SELECT * FROM mnet_rpc WHERE  parent='cas' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/imap';
SELECT * FROM mnet_rpc WHERE  parent='imap' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/radius';
SELECT * FROM mnet_rpc WHERE  parent='radius' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/none';
SELECT * FROM mnet_rpc WHERE  parent='none' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/pam';
SELECT * FROM mnet_rpc WHERE  parent='pam' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/mnet';
SELECT * FROM mnet_rpc WHERE  parent='mnet' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/user_authorise' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'user_authorise',xmlrpc_path = 'auth/mnet/auth.php/user_authorise',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Return user data for the provided token, compare with user_agent string.',profile = 'a:3:{i:0;a:2:{s:4:"type";s:5:"array";s:11:"description";s:44:"$userdata Array of user info for remote host";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:45:"token - The unique ID provided by remotehost.";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"useragent - User Agent string.";}}' WHERE id = 1;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '1' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/keepalive_server' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'keepalive_server',xmlrpc_path = 'auth/mnet/auth.php/keepalive_server',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Receives an array of usernames from a remote machine and prods their\\n sessions to keep them alive',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"\"All ok\" or an error message";}i:1;a:2:{s:4:"type";s:5:"array";s:11:"description";s:29:"array - An array of usernames";}}' WHERE id = 2;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '2' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/kill_children' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'kill_children',xmlrpc_path = 'auth/mnet/auth.php/kill_children',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'The IdP uses this function to kill child sessions on other hosts',profile = 'a:3:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"A plaintext report of what has happened";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"username - Username for session to kill";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"useragent - SHA1 hash of user agent to look for";}}' WHERE id = 3;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '3' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/refresh_log' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'refresh_log',xmlrpc_path = 'auth/mnet/auth.php/refresh_log',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Receives an array of log entries from an SP and adds them to the mnet_log\\n table',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"\"All ok\" or an error message";}i:1;a:2:{s:4:"type";s:5:"array";s:11:"description";s:29:"array - An array of usernames";}}' WHERE id = 4;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '4' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/fetch_user_image' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'fetch_user_image',xmlrpc_path = 'auth/mnet/auth.php/fetch_user_image',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Returns the user\'s image as a base64 encoded string.',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:17:"The encoded image";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:29:"username - The id of the user";}}' WHERE id = 5;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '5' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/fetch_theme_info' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'fetch_theme_info',xmlrpc_path = 'auth/mnet/auth.php/fetch_theme_info',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Returns the theme information and logo url as strings.',profile = 'a:1:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:14:"The theme info";}}' WHERE id = 6;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '6' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/update_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'update_enrolments',xmlrpc_path = 'auth/mnet/auth.php/update_enrolments',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Invoke this function _on_ the IDP to update it with enrolment info local to\\n the SP right after calling user_authorise()\\n \\n Normally called by the SP after calling',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";N;}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:23:"username - The username";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:77:"courses - Assoc array of courses following the structure of mnet_enrol_course";}}' WHERE id = 7;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '7' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/keepalive_client' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'keepalive_client',xmlrpc_path = 'auth/mnet/auth.php/keepalive_client',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Poll the IdP server to let it know that a user it has authenticated is still\\n online',profile = 'a:1:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";N;}}' WHERE id = 8;
SELECT * FROM mnet_service WHERE name = 'sso_sp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '8' AND serviceid = '2' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/kill_child' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'kill_child',xmlrpc_path = 'auth/mnet/auth.php/kill_child',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'TODO:Untested When the IdP requests that child sessions are terminated,\\n this function will be called on each of the child hosts. The machine that\\n calls the function (over xmlrpc) provides us with the mnethostid we need.',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:15:"True on success";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"username - Username for session to kill";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"useragent - SHA1 hash of user agent to look for";}}' WHERE id = 9;
SELECT * FROM mnet_service WHERE name = 'sso_sp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '9' AND serviceid = '2' LIMIT 1;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/db';
SELECT * FROM mnet_rpc WHERE  parent='db' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/ldap';
SELECT * FROM mnet_rpc WHERE  parent='ldap' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='manual' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='imsenterprise' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='paypal' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='database' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='authorize' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='mnet' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/available_courses' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'available_courses',xmlrpc_path = 'enrol/mnet/enrol.php/available_courses',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Does Foo',profile = 'a:1:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:47:"Whether the user can login from the remote host";}}' WHERE id = 10;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '10' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/user_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'user_enrolments',xmlrpc_path = 'enrol/mnet/enrol.php/user_enrolments',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'No description given.',profile = 'a:2:{i:0;a:2:{s:4:"type";s:4:"void";s:11:"description";s:0:"";}i:1;s:6:"userid";}' WHERE id = 11;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '11' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/enrol_user' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'enrol_user',xmlrpc_path = 'enrol/mnet/enrol.php/enrol_user',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Enrols user to course with the default role',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:41:"Whether the enrolment has been successful";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:37:"user - The username of the remote use";}i:2;a:2:{s:4:"type";s:3:"int";s:11:"description";s:37:"courseid - The id of the local course";}}' WHERE id = 12;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '12' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/unenrol_user' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '13' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/course_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'course_enrolments',xmlrpc_path = 'enrol/mnet/enrol.php/course_enrolments',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Get a list of users from the client server who are enrolled in a course',profile = 'a:3:{i:0;a:2:{s:4:"type";s:5:"array";s:11:"description";s:39:"Array of usernames who are homed on the";}i:1;a:2:{s:4:"type";s:3:"int";s:11:"description";s:24:"courseid - The Course ID";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"roles - Comma-separated list of role shortnames";}}' WHERE id = 14;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '14' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE  parent='flatfile' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='ldap' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT name FROM config WHERE name = 'coursereport_log_version' LIMIT 1;
SELECT * FROM config WHERE id = '-1';
INSERT INTO config ( NAME, VALUE ) VALUES ( 'coursereport_log_version', '0' );
SELECT LAST_INSERT_ID();
SELECT COUNT(*) FROM message WHERE useridto = '2' AND timecreated > '0';
SELECT name FROM config WHERE name = 'coursereport_log_version' LIMIT 1;
UPDATE config SET value = '2007101504' WHERE name = 'coursereport_log_version';
SELECT * FROM capabilities WHERE name LIKE 'coursereport/log:%';
SELECT * FROM capabilities WHERE id = '-1';
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'coursereport/log:view', 'read', 50, 'coursereport/log', 8 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:teacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '4' AND capability = 'coursereport/log:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
SELECT * FROM role_capabilities WHERE id = '-1';
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 4, 'coursereport/log:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:editingteacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '3' AND capability = 'coursereport/log:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 3, 'coursereport/log:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'coursereport/log:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'coursereport/log:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'coursereport/log:viewlive', 'read', 50, 'coursereport/log', 8 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:teacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '4' AND capability = 'coursereport/log:viewlive' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 4, 'coursereport/log:viewlive', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:editingteacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '3' AND capability = 'coursereport/log:viewlive' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 3, 'coursereport/log:viewlive', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'coursereport/log:viewlive' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'coursereport/log:viewlive', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'coursereport/log:viewtoday', 'read', 50, 'coursereport/log', 8 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:teacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '4' AND capability = 'coursereport/log:viewtoday' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 4, 'coursereport/log:viewtoday', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:editingteacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '3' AND capability = 'coursereport/log:viewtoday' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 3, 'coursereport/log:viewtoday', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'coursereport/log:viewtoday' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'coursereport/log:viewtoday', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'coursereport/log:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'coursereport/log';
SELECT name FROM config WHERE name = 'coursereport_outline_version' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'coursereport_outline_version', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'coursereport_outline_version' LIMIT 1;
UPDATE config SET value = '2007101501' WHERE name = 'coursereport_outline_version';
SELECT * FROM capabilities WHERE name LIKE 'coursereport/outline:%';
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'coursereport/outline:view', 'read', 50, 'coursereport/outline', 8 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:teacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '4' AND capability = 'coursereport/outline:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 4, 'coursereport/outline:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:editingteacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '3' AND capability = 'coursereport/outline:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 3, 'coursereport/outline:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'coursereport/outline:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'coursereport/outline:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'coursereport/outline:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'coursereport/outline';
SELECT name FROM config WHERE name = 'coursereport_participation_version' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'coursereport_participation_version', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'coursereport_participation_version' LIMIT 1;
UPDATE config SET value = '2007101501' WHERE name = 'coursereport_participation_version';
SELECT * FROM capabilities WHERE name LIKE 'coursereport/participation:%';
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'coursereport/participation:view', 'read', 50, 'coursereport/participation', 8 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:teacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '4' AND capability = 'coursereport/participation:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 4, 'coursereport/participation:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:editingteacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '3' AND capability = 'coursereport/participation:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 3, 'coursereport/participation:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'coursereport/participation:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'coursereport/participation:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'coursereport/participation:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'coursereport/participation';
SELECT name FROM config WHERE name = 'coursereport_stats_version' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'coursereport_stats_version', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'coursereport_stats_version' LIMIT 1;
UPDATE config SET value = '2007101501' WHERE name = 'coursereport_stats_version';
SELECT * FROM capabilities WHERE name LIKE 'coursereport/stats:%';
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'coursereport/stats:view', 'read', 50, 'coursereport/stats', 8 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:teacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '4' AND capability = 'coursereport/stats:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 4, 'coursereport/stats:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:editingteacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '3' AND capability = 'coursereport/stats:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 3, 'coursereport/stats:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'coursereport/stats:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'coursereport/stats:view', 1, 1254343037, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'coursereport/stats:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'coursereport/stats';
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SHOW TABLES;
SELECT * FROM modules WHERE name = 'assignment' LIMIT 1;
SELECT * FROM modules WHERE name = 'chat' LIMIT 1;
SELECT * FROM modules WHERE name = 'choice' LIMIT 1;
SELECT * FROM modules WHERE name = 'data' LIMIT 1;
SELECT * FROM modules WHERE name = 'forum' LIMIT 1;
SELECT * FROM modules WHERE name = 'glossary' LIMIT 1;
SELECT * FROM modules WHERE name = 'hotpot' LIMIT 1;
SELECT * FROM modules WHERE name = 'journal' LIMIT 1;
SELECT * FROM modules WHERE name = 'label' LIMIT 1;
SELECT * FROM modules WHERE name = 'lams' LIMIT 1;
SELECT * FROM modules WHERE name = 'lesson' LIMIT 1;
SELECT * FROM modules WHERE name = 'quiz' LIMIT 1;
SELECT * FROM modules WHERE name = 'resource' LIMIT 1;
SELECT * FROM modules WHERE name = 'scorm' LIMIT 1;
SELECT * FROM modules WHERE name = 'survey' LIMIT 1;
SELECT * FROM modules WHERE name = 'wiki' LIMIT 1;
SELECT * FROM modules WHERE name = 'workshop' LIMIT 1;
SELECT COUNT(*) FROM block ;
SELECT * FROM block WHERE name = 'activity_modules' LIMIT 1;
SELECT * FROM block WHERE name = 'admin' LIMIT 1;
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343038 AND timemodified > 1254343031;
SELECT * FROM block WHERE name = 'admin_bookmarks' LIMIT 1;
SELECT * FROM block WHERE name = 'admin_tree' LIMIT 1;
SELECT * FROM block WHERE name = 'blog_menu' LIMIT 1;
SELECT * FROM block WHERE name = 'blog_tags' LIMIT 1;
SELECT * FROM block WHERE name = 'calendar_month' LIMIT 1;
SELECT * FROM block WHERE name = 'calendar_upcoming' LIMIT 1;
SELECT * FROM block WHERE name = 'course_list' LIMIT 1;
SELECT * FROM block WHERE name = 'course_summary' LIMIT 1;
SELECT * FROM block WHERE name = 'glossary_random' LIMIT 1;
SELECT * FROM block WHERE name = 'html' LIMIT 1;
SELECT * FROM block WHERE name = 'inline_flv' LIMIT 1;
SELECT * FROM block WHERE name = 'loancalc' LIMIT 1;
SELECT * FROM block WHERE name = 'login' LIMIT 1;
SELECT * FROM block WHERE name = 'mentees' LIMIT 1;
SELECT * FROM block WHERE name = 'messages' LIMIT 1;
SELECT * FROM block WHERE name = 'mnet_hosts' LIMIT 1;
SELECT * FROM block WHERE name = 'news_items' LIMIT 1;
SELECT * FROM block WHERE name = 'online_users' LIMIT 1;
SELECT * FROM block WHERE name = 'participants' LIMIT 1;
SELECT * FROM block WHERE name = 'quiz_results' LIMIT 1;
SELECT * FROM block WHERE name = 'recent_activity' LIMIT 1;
SELECT * FROM block WHERE name = 'rss_client' LIMIT 1;
SELECT * FROM block WHERE name = 'search' LIMIT 1;
SELECT * FROM block WHERE name = 'search_forums' LIMIT 1;
SELECT * FROM block WHERE name = 'section_links' LIMIT 1;
SELECT * FROM block WHERE name = 'site_main_menu' LIMIT 1;
SELECT * FROM block WHERE name = 'social_activities' LIMIT 1;
SELECT * FROM block WHERE name = 'tag_flickr' LIMIT 1;
SELECT * FROM block WHERE name = 'tag_youtube' LIMIT 1;
SELECT * FROM block WHERE name = 'tags' LIMIT 1;
SELECT * FROM mnet_rpc WHERE  parent='workshop' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='glossary' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='hotpot' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='data' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='chat' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='wiki' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='scorm' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='journal' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='forum' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='lams' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='survey' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='quiz' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='choice' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='label' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='resource' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='assignment' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='lesson' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='nologin' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/pop3';
SELECT * FROM mnet_rpc WHERE  parent='pop3' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/nntp';
SELECT * FROM mnet_rpc WHERE  parent='nntp' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/manual';
SELECT * FROM mnet_rpc WHERE  parent='manual' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/shibboleth';
SELECT * FROM mnet_rpc WHERE  parent='shibboleth' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/fc';
SELECT * FROM mnet_rpc WHERE  parent='fc' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/email';
SELECT * FROM mnet_rpc WHERE  parent='email' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/cas';
SELECT * FROM mnet_rpc WHERE  parent='cas' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/imap';
SELECT * FROM mnet_rpc WHERE  parent='imap' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/radius';
SELECT * FROM mnet_rpc WHERE  parent='radius' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/none';
SELECT * FROM mnet_rpc WHERE  parent='none' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/pam';
SELECT * FROM mnet_rpc WHERE  parent='pam' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/mnet';
SELECT * FROM mnet_rpc WHERE  parent='mnet' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/user_authorise' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'user_authorise',xmlrpc_path = 'auth/mnet/auth.php/user_authorise',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Return user data for the provided token, compare with user_agent string.',profile = 'a:3:{i:0;a:2:{s:4:"type";s:5:"array";s:11:"description";s:44:"$userdata Array of user info for remote host";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:45:"token - The unique ID provided by remotehost.";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"useragent - User Agent string.";}}' WHERE id = 1;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '1' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/keepalive_server' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'keepalive_server',xmlrpc_path = 'auth/mnet/auth.php/keepalive_server',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Receives an array of usernames from a remote machine and prods their\\n sessions to keep them alive',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"\"All ok\" or an error message";}i:1;a:2:{s:4:"type";s:5:"array";s:11:"description";s:29:"array - An array of usernames";}}' WHERE id = 2;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '2' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/kill_children' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'kill_children',xmlrpc_path = 'auth/mnet/auth.php/kill_children',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'The IdP uses this function to kill child sessions on other hosts',profile = 'a:3:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"A plaintext report of what has happened";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"username - Username for session to kill";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"useragent - SHA1 hash of user agent to look for";}}' WHERE id = 3;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '3' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/refresh_log' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'refresh_log',xmlrpc_path = 'auth/mnet/auth.php/refresh_log',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Receives an array of log entries from an SP and adds them to the mnet_log\\n table',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"\"All ok\" or an error message";}i:1;a:2:{s:4:"type";s:5:"array";s:11:"description";s:29:"array - An array of usernames";}}' WHERE id = 4;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '4' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/fetch_user_image' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'fetch_user_image',xmlrpc_path = 'auth/mnet/auth.php/fetch_user_image',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Returns the user\'s image as a base64 encoded string.',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:17:"The encoded image";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:29:"username - The id of the user";}}' WHERE id = 5;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '5' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/fetch_theme_info' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'fetch_theme_info',xmlrpc_path = 'auth/mnet/auth.php/fetch_theme_info',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Returns the theme information and logo url as strings.',profile = 'a:1:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:14:"The theme info";}}' WHERE id = 6;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '6' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/update_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'update_enrolments',xmlrpc_path = 'auth/mnet/auth.php/update_enrolments',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Invoke this function _on_ the IDP to update it with enrolment info local to\\n the SP right after calling user_authorise()\\n \\n Normally called by the SP after calling',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";N;}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:23:"username - The username";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:77:"courses - Assoc array of courses following the structure of mnet_enrol_course";}}' WHERE id = 7;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '7' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/keepalive_client' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'keepalive_client',xmlrpc_path = 'auth/mnet/auth.php/keepalive_client',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Poll the IdP server to let it know that a user it has authenticated is still\\n online',profile = 'a:1:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";N;}}' WHERE id = 8;
SELECT * FROM mnet_service WHERE name = 'sso_sp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '8' AND serviceid = '2' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/kill_child' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'kill_child',xmlrpc_path = 'auth/mnet/auth.php/kill_child',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'TODO:Untested When the IdP requests that child sessions are terminated,\\n this function will be called on each of the child hosts. The machine that\\n calls the function (over xmlrpc) provides us with the mnethostid we need.',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:15:"True on success";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"username - Username for session to kill";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"useragent - SHA1 hash of user agent to look for";}}' WHERE id = 9;
SELECT * FROM mnet_service WHERE name = 'sso_sp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '9' AND serviceid = '2' LIMIT 1;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/db';
SELECT * FROM mnet_rpc WHERE  parent='db' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/ldap';
SELECT * FROM mnet_rpc WHERE  parent='ldap' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='manual' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='imsenterprise' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='paypal' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='database' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='authorize' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='mnet' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/available_courses' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'available_courses',xmlrpc_path = 'enrol/mnet/enrol.php/available_courses',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Does Foo',profile = 'a:1:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:47:"Whether the user can login from the remote host";}}' WHERE id = 10;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '10' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/user_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'user_enrolments',xmlrpc_path = 'enrol/mnet/enrol.php/user_enrolments',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'No description given.',profile = 'a:2:{i:0;a:2:{s:4:"type";s:4:"void";s:11:"description";s:0:"";}i:1;s:6:"userid";}' WHERE id = 11;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '11' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/enrol_user' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'enrol_user',xmlrpc_path = 'enrol/mnet/enrol.php/enrol_user',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Enrols user to course with the default role',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:41:"Whether the enrolment has been successful";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:37:"user - The username of the remote use";}i:2;a:2:{s:4:"type";s:3:"int";s:11:"description";s:37:"courseid - The id of the local course";}}' WHERE id = 12;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '12' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/unenrol_user' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '13' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/course_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'course_enrolments',xmlrpc_path = 'enrol/mnet/enrol.php/course_enrolments',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Get a list of users from the client server who are enrolled in a course',profile = 'a:3:{i:0;a:2:{s:4:"type";s:5:"array";s:11:"description";s:39:"Array of usernames who are homed on the";}i:1;a:2:{s:4:"type";s:3:"int";s:11:"description";s:24:"courseid - The Course ID";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"roles - Comma-separated list of role shortnames";}}' WHERE id = 14;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '14' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE  parent='flatfile' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='ldap' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT name FROM config WHERE name = 'report_courseoverview_version' LIMIT 1;
SELECT * FROM config WHERE id = '-1';
INSERT INTO config ( NAME, VALUE ) VALUES ( 'report_courseoverview_version', '0' );
SELECT LAST_INSERT_ID();
SELECT COUNT(*) FROM message WHERE useridto = '2' AND timecreated > '0';
SELECT name FROM config WHERE name = 'report_courseoverview_version' LIMIT 1;
UPDATE config SET value = '2007101503' WHERE name = 'report_courseoverview_version';
SELECT * FROM capabilities WHERE name LIKE 'report/courseoverview:%';
SELECT * FROM capabilities WHERE id = '-1';
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'report/courseoverview:view', 'read', 10, 'report/courseoverview', 8 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:teacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '4' AND capability = 'report/courseoverview:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
SELECT * FROM role_capabilities WHERE id = '-1';
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 4, 'report/courseoverview:view', 1, 1254343039, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:editingteacher'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '3' AND capability = 'report/courseoverview:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 3, 'report/courseoverview:view', 1, 1254343039, 2 );
SELECT LAST_INSERT_ID();
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'report/courseoverview:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'report/courseoverview:view', 1, 1254343039, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'report/courseoverview:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'report/courseoverview';
SELECT name FROM config WHERE name = 'report_security_version' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'report_security_version', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'report_security_version' LIMIT 1;
UPDATE config SET value = '2007101500' WHERE name = 'report_security_version';
SELECT * FROM capabilities WHERE name LIKE 'report/security:%';
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'report/security:view', 'read', 10, 'report/security', 2 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'report/security:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'report/security:view', 1, 1254343039, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'report/security:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'report/security';
SELECT name FROM config WHERE name = 'report_unittest_version' LIMIT 1;
INSERT INTO config ( NAME, VALUE ) VALUES ( 'report_unittest_version', '0' );
SELECT LAST_INSERT_ID();
SELECT name FROM config WHERE name = 'report_unittest_version' LIMIT 1;
UPDATE config SET value = '2007101501' WHERE name = 'report_unittest_version';
SELECT * FROM capabilities WHERE name LIKE 'report/unittest:%';
INSERT INTO capabilities ( NAME, CAPTYPE, CONTEXTLEVEL, COMPONENT, RISKBITMASK ) VALUES ( 'report/unittest:view', 'read', 10, 'report/unittest', 32 );
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:admin'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role_capabilities WHERE contextid = '1' AND roleid = '1' AND capability = 'report/unittest:view' LIMIT 1;
SELECT * FROM context WHERE id = '1' LIMIT 1;
INSERT INTO role_capabilities ( CONTEXTID, ROLEID, CAPABILITY, PERMISSION, TIMEMODIFIED, MODIFIERID ) VALUES ( 1, 1, 'report/unittest:view', 1, 1254343039, 2 );
SELECT LAST_INSERT_ID();
SELECT * FROM capabilities WHERE name LIKE 'report/unittest:%';
SELECT name, 1 FROM capabilities;
SELECT * FROM events_handlers WHERE handlermodule = 'report/unittest';
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SHOW TABLES;
SELECT * FROM modules WHERE name = 'assignment' LIMIT 1;
SELECT * FROM modules WHERE name = 'chat' LIMIT 1;
SELECT * FROM modules WHERE name = 'choice' LIMIT 1;
SELECT * FROM modules WHERE name = 'data' LIMIT 1;
SELECT * FROM modules WHERE name = 'forum' LIMIT 1;
SELECT * FROM modules WHERE name = 'glossary' LIMIT 1;
SELECT * FROM modules WHERE name = 'hotpot' LIMIT 1;
SELECT * FROM modules WHERE name = 'journal' LIMIT 1;
SELECT * FROM modules WHERE name = 'label' LIMIT 1;
SELECT * FROM modules WHERE name = 'lams' LIMIT 1;
SELECT * FROM modules WHERE name = 'lesson' LIMIT 1;
SELECT * FROM modules WHERE name = 'quiz' LIMIT 1;
SELECT * FROM modules WHERE name = 'resource' LIMIT 1;
SELECT * FROM modules WHERE name = 'scorm' LIMIT 1;
SELECT * FROM modules WHERE name = 'survey' LIMIT 1;
SELECT * FROM modules WHERE name = 'wiki' LIMIT 1;
SELECT * FROM modules WHERE name = 'workshop' LIMIT 1;
SELECT COUNT(*) FROM block ;
SELECT * FROM block WHERE name = 'activity_modules' LIMIT 1;
SELECT * FROM block WHERE name = 'admin' LIMIT 1;
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343040 AND timemodified > 1254343031;
SELECT * FROM block WHERE name = 'admin_bookmarks' LIMIT 1;
SELECT * FROM block WHERE name = 'admin_tree' LIMIT 1;
SELECT * FROM block WHERE name = 'blog_menu' LIMIT 1;
SELECT * FROM block WHERE name = 'blog_tags' LIMIT 1;
SELECT * FROM block WHERE name = 'calendar_month' LIMIT 1;
SELECT * FROM block WHERE name = 'calendar_upcoming' LIMIT 1;
SELECT * FROM block WHERE name = 'course_list' LIMIT 1;
SELECT * FROM block WHERE name = 'course_summary' LIMIT 1;
SELECT * FROM block WHERE name = 'glossary_random' LIMIT 1;
SELECT * FROM block WHERE name = 'html' LIMIT 1;
SELECT * FROM block WHERE name = 'inline_flv' LIMIT 1;
SELECT * FROM block WHERE name = 'loancalc' LIMIT 1;
SELECT * FROM block WHERE name = 'login' LIMIT 1;
SELECT * FROM block WHERE name = 'mentees' LIMIT 1;
SELECT * FROM block WHERE name = 'messages' LIMIT 1;
SELECT * FROM block WHERE name = 'mnet_hosts' LIMIT 1;
SELECT * FROM block WHERE name = 'news_items' LIMIT 1;
SELECT * FROM block WHERE name = 'online_users' LIMIT 1;
SELECT * FROM block WHERE name = 'participants' LIMIT 1;
SELECT * FROM block WHERE name = 'quiz_results' LIMIT 1;
SELECT * FROM block WHERE name = 'recent_activity' LIMIT 1;
SELECT * FROM block WHERE name = 'rss_client' LIMIT 1;
SELECT * FROM block WHERE name = 'search' LIMIT 1;
SELECT * FROM block WHERE name = 'search_forums' LIMIT 1;
SELECT * FROM block WHERE name = 'section_links' LIMIT 1;
SELECT * FROM block WHERE name = 'site_main_menu' LIMIT 1;
SELECT * FROM block WHERE name = 'social_activities' LIMIT 1;
SELECT * FROM block WHERE name = 'tag_flickr' LIMIT 1;
SELECT * FROM block WHERE name = 'tag_youtube' LIMIT 1;
SELECT * FROM block WHERE name = 'tags' LIMIT 1;
SELECT * FROM mnet_rpc WHERE  parent='workshop' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='glossary' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='hotpot' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='data' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='chat' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='wiki' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='scorm' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='journal' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='forum' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='lams' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='survey' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='quiz' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='choice' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='label' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='resource' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='assignment' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='lesson' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='nologin' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/pop3';
SELECT * FROM mnet_rpc WHERE  parent='pop3' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/nntp';
SELECT * FROM mnet_rpc WHERE  parent='nntp' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/manual';
SELECT * FROM mnet_rpc WHERE  parent='manual' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/shibboleth';
SELECT * FROM mnet_rpc WHERE  parent='shibboleth' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/fc';
SELECT * FROM mnet_rpc WHERE  parent='fc' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/email';
SELECT * FROM mnet_rpc WHERE  parent='email' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/cas';
SELECT * FROM mnet_rpc WHERE  parent='cas' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/imap';
SELECT * FROM mnet_rpc WHERE  parent='imap' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/radius';
SELECT * FROM mnet_rpc WHERE  parent='radius' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/none';
SELECT * FROM mnet_rpc WHERE  parent='none' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/pam';
SELECT * FROM mnet_rpc WHERE  parent='pam' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/mnet';
SELECT * FROM mnet_rpc WHERE  parent='mnet' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/user_authorise' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'user_authorise',xmlrpc_path = 'auth/mnet/auth.php/user_authorise',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Return user data for the provided token, compare with user_agent string.',profile = 'a:3:{i:0;a:2:{s:4:"type";s:5:"array";s:11:"description";s:44:"$userdata Array of user info for remote host";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:45:"token - The unique ID provided by remotehost.";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"useragent - User Agent string.";}}' WHERE id = 1;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '1' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/keepalive_server' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'keepalive_server',xmlrpc_path = 'auth/mnet/auth.php/keepalive_server',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Receives an array of usernames from a remote machine and prods their\\n sessions to keep them alive',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"\"All ok\" or an error message";}i:1;a:2:{s:4:"type";s:5:"array";s:11:"description";s:29:"array - An array of usernames";}}' WHERE id = 2;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '2' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/kill_children' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'kill_children',xmlrpc_path = 'auth/mnet/auth.php/kill_children',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'The IdP uses this function to kill child sessions on other hosts',profile = 'a:3:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"A plaintext report of what has happened";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"username - Username for session to kill";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"useragent - SHA1 hash of user agent to look for";}}' WHERE id = 3;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '3' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/refresh_log' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'refresh_log',xmlrpc_path = 'auth/mnet/auth.php/refresh_log',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Receives an array of log entries from an SP and adds them to the mnet_log\\n table',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"\"All ok\" or an error message";}i:1;a:2:{s:4:"type";s:5:"array";s:11:"description";s:29:"array - An array of usernames";}}' WHERE id = 4;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '4' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/fetch_user_image' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'fetch_user_image',xmlrpc_path = 'auth/mnet/auth.php/fetch_user_image',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Returns the user\'s image as a base64 encoded string.',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:17:"The encoded image";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:29:"username - The id of the user";}}' WHERE id = 5;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '5' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/fetch_theme_info' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'fetch_theme_info',xmlrpc_path = 'auth/mnet/auth.php/fetch_theme_info',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Returns the theme information and logo url as strings.',profile = 'a:1:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:14:"The theme info";}}' WHERE id = 6;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '6' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/update_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'update_enrolments',xmlrpc_path = 'auth/mnet/auth.php/update_enrolments',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Invoke this function _on_ the IDP to update it with enrolment info local to\\n the SP right after calling user_authorise()\\n \\n Normally called by the SP after calling',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";N;}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:23:"username - The username";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:77:"courses - Assoc array of courses following the structure of mnet_enrol_course";}}' WHERE id = 7;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '7' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/keepalive_client' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'keepalive_client',xmlrpc_path = 'auth/mnet/auth.php/keepalive_client',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Poll the IdP server to let it know that a user it has authenticated is still\\n online',profile = 'a:1:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";N;}}' WHERE id = 8;
SELECT * FROM mnet_service WHERE name = 'sso_sp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '8' AND serviceid = '2' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/kill_child' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'kill_child',xmlrpc_path = 'auth/mnet/auth.php/kill_child',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'TODO:Untested When the IdP requests that child sessions are terminated,\\n this function will be called on each of the child hosts. The machine that\\n calls the function (over xmlrpc) provides us with the mnethostid we need.',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:15:"True on success";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"username - Username for session to kill";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"useragent - SHA1 hash of user agent to look for";}}' WHERE id = 9;
SELECT * FROM mnet_service WHERE name = 'sso_sp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '9' AND serviceid = '2' LIMIT 1;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/db';
SELECT * FROM mnet_rpc WHERE  parent='db' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/ldap';
SELECT * FROM mnet_rpc WHERE  parent='ldap' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='manual' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='imsenterprise' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='paypal' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='database' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='authorize' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='mnet' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/available_courses' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'available_courses',xmlrpc_path = 'enrol/mnet/enrol.php/available_courses',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Does Foo',profile = 'a:1:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:47:"Whether the user can login from the remote host";}}' WHERE id = 10;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '10' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/user_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'user_enrolments',xmlrpc_path = 'enrol/mnet/enrol.php/user_enrolments',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'No description given.',profile = 'a:2:{i:0;a:2:{s:4:"type";s:4:"void";s:11:"description";s:0:"";}i:1;s:6:"userid";}' WHERE id = 11;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '11' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/enrol_user' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'enrol_user',xmlrpc_path = 'enrol/mnet/enrol.php/enrol_user',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Enrols user to course with the default role',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:41:"Whether the enrolment has been successful";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:37:"user - The username of the remote use";}i:2;a:2:{s:4:"type";s:3:"int";s:11:"description";s:37:"courseid - The id of the local course";}}' WHERE id = 12;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '12' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/unenrol_user' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '13' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/course_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'course_enrolments',xmlrpc_path = 'enrol/mnet/enrol.php/course_enrolments',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Get a list of users from the client server who are enrolled in a course',profile = 'a:3:{i:0;a:2:{s:4:"type";s:5:"array";s:11:"description";s:39:"Array of usernames who are homed on the";}i:1;a:2:{s:4:"type";s:3:"int";s:11:"description";s:24:"courseid - The Course ID";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"roles - Comma-separated list of role shortnames";}}' WHERE id = 14;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '14' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE  parent='flatfile' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='ldap' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM user WHERE username = 'guest' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SELECT rc.id, rc.roleid, rc.permission, rc.capability,
                   ctx.depth AS ctxdepth, ctx.contextlevel AS ctxlevel
            FROM role_capabilities rc
            JOIN context ctx on rc.contextid = ctx.id
            
            WHERE rc.capability IN ('moodle/site:approvecourse','moodle/site:doanything') AND ctx.id IN (1)
                  
            ORDER BY rc.roleid ASC, ctx.depth ASC;
 SELECT u.id,u.username,u.firstname,u.lastname FROM user u
                    JOIN (SELECT DISTINCT ssra.userid
                          FROM role_assignments ssra
                          WHERE ssra.contextid IN (1)
                                AND ssra.roleid IN (1)
                                
                          ) ra ON ra.userid = u.id
                     WHERE u.deleted = 0 ORDER BY u.lastname,u.firstname ;
SELECT * FROM role ORDER BY sortorder ASC;
SELECT MAX(id), name FROM timezone GROUP BY name;
SELECT * FROM modules;
SELECT * FROM role WHERE id = '6' LIMIT 1;
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:student'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:user'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:guest'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role ORDER BY sortorder ASC;
SELECT * FROM modules;
SELECT * FROM glossary_formats WHERE name = 'continuous' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'dictionary' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'encyclopedia' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'entrylist' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'faq' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithauthor' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithoutauthor' LIMIT 1;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats WHERE id = '1' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '3' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '4' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '5' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '6' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '7' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '2' LIMIT 1;
SELECT * FROM block;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT value FROM config WHERE name = 'cachetype' LIMIT 1;
SELECT value FROM config WHERE name = 'rcache' LIMIT 1;
SELECT value FROM config_plugins WHERE plugin = 'qtype_random' AND name = 'selectmanual' LIMIT 1;
SELECT name, 1 FROM capabilities;
SELECT * FROM block_instance WHERE pageid = '0' AND pagetype = 'admin' ORDER BY position, weight;
SELECT * FROM block;
SELECT COUNT(*) FROM message WHERE useridto = '2' AND timecreated > '0';
SELECT * FROM context WHERE contextlevel = '80' AND instanceid = '5' LIMIT 1;
SELECT ctx.path, ra.roleid
            FROM role_assignments ra
            JOIN context ctx
               ON ra.contextid=ctx.id
            WHERE ra.userid = 2
                  AND (ctx.path = '/1/8' OR ctx.path LIKE '/1/8/%')
            ORDER BY ctx.depth, ctx.path, ra.roleid;
SELECT ctx.path, rc.roleid, rc.capability, rc.permission
            FROM role_capabilities rc
            JOIN context ctx
             ON rc.contextid=ctx.id
            WHERE (rc.roleid IN (1,7) AND
                    (ctx.id=8 OR ctx.path LIKE '/1/8/%'))
                    
            ORDER BY ctx.depth ASC, ctx.path DESC, rc.roleid ASC ;
SELECT * FROM context WHERE contextlevel = '80' AND instanceid = '6' LIMIT 1;
SELECT ctx.path, ra.roleid
            FROM role_assignments ra
            JOIN context ctx
               ON ra.contextid=ctx.id
            WHERE ra.userid = 2
                  AND (ctx.path = '/1/9' OR ctx.path LIKE '/1/9/%')
            ORDER BY ctx.depth, ctx.path, ra.roleid;
SELECT ctx.path, rc.roleid, rc.capability, rc.permission
            FROM role_capabilities rc
            JOIN context ctx
             ON rc.contextid=ctx.id
            WHERE (rc.roleid IN (1,7) AND
                    (ctx.id=9 OR ctx.path LIKE '/1/9/%'))
                    
            ORDER BY ctx.depth ASC, ctx.path DESC, rc.roleid ASC ;
SELECT max(lastcron) FROM modules LIMIT 1;
SELECT * FROM block_instance WHERE pageid = '0' AND pagetype = 'admin' ORDER BY position, weight;
SET NAMES 'utf8';
SELECT * FROM config;
SELECT * FROM course WHERE category = '0' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '10' LIMIT 1;
SHOW TABLES;
SELECT * FROM modules WHERE name = 'assignment' LIMIT 1;
SELECT * FROM modules WHERE name = 'chat' LIMIT 1;
SELECT * FROM modules WHERE name = 'choice' LIMIT 1;
SELECT * FROM modules WHERE name = 'data' LIMIT 1;
SELECT * FROM modules WHERE name = 'forum' LIMIT 1;
SELECT * FROM modules WHERE name = 'glossary' LIMIT 1;
SELECT * FROM modules WHERE name = 'hotpot' LIMIT 1;
SELECT * FROM modules WHERE name = 'journal' LIMIT 1;
SELECT * FROM modules WHERE name = 'label' LIMIT 1;
SELECT * FROM modules WHERE name = 'lams' LIMIT 1;
SELECT * FROM modules WHERE name = 'lesson' LIMIT 1;
SELECT * FROM modules WHERE name = 'quiz' LIMIT 1;
SELECT * FROM modules WHERE name = 'resource' LIMIT 1;
SELECT * FROM modules WHERE name = 'scorm' LIMIT 1;
SELECT * FROM modules WHERE name = 'survey' LIMIT 1;
SELECT * FROM modules WHERE name = 'wiki' LIMIT 1;
SELECT * FROM modules WHERE name = 'workshop' LIMIT 1;
SELECT COUNT(*) FROM block ;
SELECT * FROM block WHERE name = 'activity_modules' LIMIT 1;
SELECT * FROM block WHERE name = 'admin' LIMIT 1;
SELECT name,value FROM cache_flags WHERE flagtype='accesslib/dirtycontexts' AND expiry >= 1254343051 AND timemodified > 1254343031;
SELECT * FROM block WHERE name = 'admin_bookmarks' LIMIT 1;
SELECT * FROM block WHERE name = 'admin_tree' LIMIT 1;
SELECT * FROM block WHERE name = 'blog_menu' LIMIT 1;
SELECT * FROM block WHERE name = 'blog_tags' LIMIT 1;
SELECT * FROM block WHERE name = 'calendar_month' LIMIT 1;
SELECT * FROM block WHERE name = 'calendar_upcoming' LIMIT 1;
SELECT * FROM block WHERE name = 'course_list' LIMIT 1;
SELECT * FROM block WHERE name = 'course_summary' LIMIT 1;
SELECT * FROM block WHERE name = 'glossary_random' LIMIT 1;
SELECT * FROM block WHERE name = 'html' LIMIT 1;
SELECT * FROM block WHERE name = 'inline_flv' LIMIT 1;
SELECT * FROM block WHERE name = 'loancalc' LIMIT 1;
SELECT * FROM block WHERE name = 'login' LIMIT 1;
SELECT * FROM block WHERE name = 'mentees' LIMIT 1;
SELECT * FROM block WHERE name = 'messages' LIMIT 1;
SELECT * FROM block WHERE name = 'mnet_hosts' LIMIT 1;
SELECT * FROM block WHERE name = 'news_items' LIMIT 1;
SELECT * FROM block WHERE name = 'online_users' LIMIT 1;
SELECT * FROM block WHERE name = 'participants' LIMIT 1;
SELECT * FROM block WHERE name = 'quiz_results' LIMIT 1;
SELECT * FROM block WHERE name = 'recent_activity' LIMIT 1;
SELECT * FROM block WHERE name = 'rss_client' LIMIT 1;
SELECT * FROM block WHERE name = 'search' LIMIT 1;
SELECT * FROM block WHERE name = 'search_forums' LIMIT 1;
SELECT * FROM block WHERE name = 'section_links' LIMIT 1;
SELECT * FROM block WHERE name = 'site_main_menu' LIMIT 1;
SELECT * FROM block WHERE name = 'social_activities' LIMIT 1;
SELECT * FROM block WHERE name = 'tag_flickr' LIMIT 1;
SELECT * FROM block WHERE name = 'tag_youtube' LIMIT 1;
SELECT * FROM block WHERE name = 'tags' LIMIT 1;
SELECT * FROM mnet_rpc WHERE  parent='workshop' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='glossary' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='hotpot' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='data' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='chat' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='wiki' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='scorm' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='journal' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='forum' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='lams' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='survey' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='quiz' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='choice' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='label' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='resource' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='assignment' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='lesson' AND parent_type='mod'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='nologin' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/pop3';
SELECT * FROM mnet_rpc WHERE  parent='pop3' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/nntp';
SELECT * FROM mnet_rpc WHERE  parent='nntp' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/manual';
SELECT * FROM mnet_rpc WHERE  parent='manual' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/shibboleth';
SELECT * FROM mnet_rpc WHERE  parent='shibboleth' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/fc';
SELECT * FROM mnet_rpc WHERE  parent='fc' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/email';
SELECT * FROM mnet_rpc WHERE  parent='email' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/cas';
SELECT * FROM mnet_rpc WHERE  parent='cas' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/imap';
SELECT * FROM mnet_rpc WHERE  parent='imap' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/radius';
SELECT * FROM mnet_rpc WHERE  parent='radius' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/none';
SELECT * FROM mnet_rpc WHERE  parent='none' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/pam';
SELECT * FROM mnet_rpc WHERE  parent='pam' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/mnet';
SELECT * FROM mnet_rpc WHERE  parent='mnet' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/user_authorise' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'user_authorise',xmlrpc_path = 'auth/mnet/auth.php/user_authorise',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Return user data for the provided token, compare with user_agent string.',profile = 'a:3:{i:0;a:2:{s:4:"type";s:5:"array";s:11:"description";s:44:"$userdata Array of user info for remote host";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:45:"token - The unique ID provided by remotehost.";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"useragent - User Agent string.";}}' WHERE id = 1;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '1' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/keepalive_server' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'keepalive_server',xmlrpc_path = 'auth/mnet/auth.php/keepalive_server',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Receives an array of usernames from a remote machine and prods their\\n sessions to keep them alive',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"\"All ok\" or an error message";}i:1;a:2:{s:4:"type";s:5:"array";s:11:"description";s:29:"array - An array of usernames";}}' WHERE id = 2;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '2' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/kill_children' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'kill_children',xmlrpc_path = 'auth/mnet/auth.php/kill_children',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'The IdP uses this function to kill child sessions on other hosts',profile = 'a:3:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"A plaintext report of what has happened";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"username - Username for session to kill";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"useragent - SHA1 hash of user agent to look for";}}' WHERE id = 3;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '3' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/refresh_log' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'refresh_log',xmlrpc_path = 'auth/mnet/auth.php/refresh_log',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Receives an array of log entries from an SP and adds them to the mnet_log\\n table',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:30:"\"All ok\" or an error message";}i:1;a:2:{s:4:"type";s:5:"array";s:11:"description";s:29:"array - An array of usernames";}}' WHERE id = 4;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '4' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/fetch_user_image' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'fetch_user_image',xmlrpc_path = 'auth/mnet/auth.php/fetch_user_image',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Returns the user\'s image as a base64 encoded string.',profile = 'a:2:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:17:"The encoded image";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:29:"username - The id of the user";}}' WHERE id = 5;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '5' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/fetch_theme_info' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'fetch_theme_info',xmlrpc_path = 'auth/mnet/auth.php/fetch_theme_info',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Returns the theme information and logo url as strings.',profile = 'a:1:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";s:14:"The theme info";}}' WHERE id = 6;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '6' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/update_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'update_enrolments',xmlrpc_path = 'auth/mnet/auth.php/update_enrolments',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Invoke this function _on_ the IDP to update it with enrolment info local to\\n the SP right after calling user_authorise()\\n \\n Normally called by the SP after calling',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";N;}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:23:"username - The username";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:77:"courses - Assoc array of courses following the structure of mnet_enrol_course";}}' WHERE id = 7;
SELECT * FROM mnet_service WHERE name = 'sso_idp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '7' AND serviceid = '1' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/keepalive_client' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'keepalive_client',xmlrpc_path = 'auth/mnet/auth.php/keepalive_client',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'Poll the IdP server to let it know that a user it has authenticated is still\\n online',profile = 'a:1:{i:0;a:2:{s:4:"type";s:6:"string";s:11:"description";N;}}' WHERE id = 8;
SELECT * FROM mnet_service WHERE name = 'sso_sp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '8' AND serviceid = '2' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'auth/mnet/auth.php/kill_child' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'kill_child',xmlrpc_path = 'auth/mnet/auth.php/kill_child',parent_type = 'auth',parent = 'mnet',enabled = '0',help = 'TODO:Untested When the IdP requests that child sessions are terminated,\\n this function will be called on each of the child hosts. The machine that\\n calls the function (over xmlrpc) provides us with the mnethostid we need.',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:15:"True on success";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:39:"username - Username for session to kill";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"useragent - SHA1 hash of user agent to look for";}}' WHERE id = 9;
SELECT * FROM mnet_service WHERE name = 'sso_sp' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '9' AND serviceid = '2' LIMIT 1;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/db';
SELECT * FROM mnet_rpc WHERE  parent='db' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT name,value FROM config_plugins WHERE plugin = 'auth/ldap';
SELECT * FROM mnet_rpc WHERE  parent='ldap' AND parent_type='auth'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='manual' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='imsenterprise' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='paypal' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='database' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='authorize' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='mnet' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/available_courses' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'available_courses',xmlrpc_path = 'enrol/mnet/enrol.php/available_courses',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Does Foo',profile = 'a:1:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:47:"Whether the user can login from the remote host";}}' WHERE id = 10;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '10' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/user_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'user_enrolments',xmlrpc_path = 'enrol/mnet/enrol.php/user_enrolments',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'No description given.',profile = 'a:2:{i:0;a:2:{s:4:"type";s:4:"void";s:11:"description";s:0:"";}i:1;s:6:"userid";}' WHERE id = 11;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '11' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/enrol_user' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'enrol_user',xmlrpc_path = 'enrol/mnet/enrol.php/enrol_user',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Enrols user to course with the default role',profile = 'a:3:{i:0;a:2:{s:4:"type";s:7:"boolean";s:11:"description";s:41:"Whether the enrolment has been successful";}i:1;a:2:{s:4:"type";s:6:"string";s:11:"description";s:37:"user - The username of the remote use";}i:2;a:2:{s:4:"type";s:3:"int";s:11:"description";s:37:"courseid - The id of the local course";}}' WHERE id = 12;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '12' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/unenrol_user' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '13' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE xmlrpc_path = 'enrol/mnet/enrol.php/course_enrolments' LIMIT 1;
SHOW COLUMNS FROM `mnet_rpc`;
UPDATE mnet_rpc SET function_name = 'course_enrolments',xmlrpc_path = 'enrol/mnet/enrol.php/course_enrolments',parent_type = 'enrol',parent = 'mnet',enabled = '0',help = 'Get a list of users from the client server who are enrolled in a course',profile = 'a:3:{i:0;a:2:{s:4:"type";s:5:"array";s:11:"description";s:39:"Array of usernames who are homed on the";}i:1;a:2:{s:4:"type";s:3:"int";s:11:"description";s:24:"courseid - The Course ID";}i:2;a:2:{s:4:"type";s:6:"string";s:11:"description";s:47:"roles - Comma-separated list of role shortnames";}}' WHERE id = 14;
SELECT * FROM mnet_service WHERE name = 'mnet_enrol' LIMIT 1;
SELECT * FROM mnet_service2rpc WHERE rpcid = '14' AND serviceid = '3' LIMIT 1;
SELECT * FROM mnet_rpc WHERE  parent='flatfile' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM mnet_rpc WHERE  parent='ldap' AND parent_type='enrol'  ORDER BY function_name ASC ;
SELECT * FROM user WHERE username = 'guest' LIMIT 1;
SELECT * FROM context WHERE contextlevel = '50' AND instanceid = '1' LIMIT 1;
SELECT rc.id, rc.roleid, rc.permission, rc.capability,
                   ctx.depth AS ctxdepth, ctx.contextlevel AS ctxlevel
            FROM role_capabilities rc
            JOIN context ctx on rc.contextid = ctx.id
            
            WHERE rc.capability IN ('moodle/site:approvecourse','moodle/site:doanything') AND ctx.id IN (1)
                  
            ORDER BY rc.roleid ASC, ctx.depth ASC;
 SELECT u.id,u.username,u.firstname,u.lastname FROM user u
                    JOIN (SELECT DISTINCT ssra.userid
                          FROM role_assignments ssra
                          WHERE ssra.contextid IN (1)
                                AND ssra.roleid IN (1)
                                
                          ) ra ON ra.userid = u.id
                     WHERE u.deleted = 0 ORDER BY u.lastname,u.firstname ;
SELECT * FROM role ORDER BY sortorder ASC;
SELECT MAX(id), name FROM timezone GROUP BY name;
SELECT * FROM modules;
SELECT * FROM role WHERE id = '6' LIMIT 1;
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:student'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:user'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT r.*
                      FROM role r,
                           role_capabilities rc
                     WHERE rc.capability = 'moodle/legacy:guest'
                       AND rc.roleid = r.id  AND rc.permission = '1';
SELECT * FROM role ORDER BY sortorder ASC;
SELECT * FROM modules;
SELECT * FROM glossary_formats WHERE name = 'continuous' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'dictionary' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'encyclopedia' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'entrylist' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'faq' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithauthor' LIMIT 1;
SELECT * FROM glossary_formats WHERE name = 'fullwithoutauthor' LIMIT 1;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats;
SELECT * FROM glossary_formats WHERE id = '1' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '3' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '4' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '5' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '6' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '7' LIMIT 1;
SELECT * FROM glossary_formats WHERE id = '2' LIMIT 1;
SELECT * FROM block;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
SELECT * FROM backup_config;
