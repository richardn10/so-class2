<?php
$string['repositoryname'] = 'Youtube Repository';
$string['search'] = 'Search';
