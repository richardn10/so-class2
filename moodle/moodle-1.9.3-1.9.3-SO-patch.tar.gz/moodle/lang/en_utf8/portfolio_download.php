<?php

$string['downloadfile'] = 'Download your portfolio export file';
$string['pluginname'] = 'File download';
$string['downloading'] = 'Downloading ...';

?>
