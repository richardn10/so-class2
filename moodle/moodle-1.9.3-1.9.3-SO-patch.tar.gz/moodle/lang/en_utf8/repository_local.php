<?php // $Id: repository_local.php,v 1.2 2008/08/26 05:13:35 moodler Exp $
$string['configplugin'] = 'Configuration for local file repository';
$string['repositoryname'] = 'Local Files';
$string['repositorydesc'] = 'Repository on the local Moodle server';
$string['notitle'] = 'notitle';
$string['remember'] = 'Remember me';
$string['emptyfilelist'] = 'There are no files to show';
