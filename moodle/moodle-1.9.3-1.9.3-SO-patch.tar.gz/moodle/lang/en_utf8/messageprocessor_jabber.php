<?PHP // $Id: messageprocessor_jabber.php,v 1.3 2008/09/23 03:05:44 moodler Exp $ 
$string['jabber'] = 'Jabber message';
$string['jabberid'] = 'Jabber ID';
?>
