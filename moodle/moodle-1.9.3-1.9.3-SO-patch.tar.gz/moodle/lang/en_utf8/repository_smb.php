<?php
$string['repositoryname'] = 'SMB Repository';
$string['smb_server'] = 'SMB Server';
