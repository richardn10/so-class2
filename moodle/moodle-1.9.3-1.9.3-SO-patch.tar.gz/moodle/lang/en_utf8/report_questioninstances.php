<?PHP  // $Id: report_questioninstances.php,v 1.2 2008/09/10 05:34:09 tjhunt Exp $

$string['editquestionshere'] = 'Edit questions in this context';
$string['getreport'] = 'Get the report';
$string['hiddenquestions'] = 'Hidden';
$string['intro'] = 'This report lists all the contexts in the system where there are questions of a particular type.';
$string['reportforallqtypes'] = 'Report for all question types';
$string['reportformissingqtypes'] = 'Report for question of unknown types';
$string['reportforqtype'] = 'Report for question type \'$a\'';
$string['reportsettings'] = 'Report settings';
$string['questioninstances'] = 'Question instances';
$string['totalquestions'] = 'Total';
$string['visiblequestions'] = 'Visible';
?>
