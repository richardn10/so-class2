<?php // $Id: repository_upload.php,v 1.1 2008/09/02 04:05:11 dongsheng Exp $
$string['configplugin'] = 'Configuration for upload plugin';
$string['repositoryname'] = 'Upload a file';
$string['repositorydesc'] = 'Upload a file to Moodle';
