<?php
$string['alfresco_url'] = 'Alfresco URL';
$string['configplugin'] = 'Alfresco configuration';
$string['notitle'] = 'notitle';
$string['repositoryname'] = 'Alfresco Repository';
$string['repositorydesc'] = 'A plug-in for Alfresco CMS';
$string['username'] = 'User name';
$string['password'] = 'Password';
$string['soapmustbeenabled'] = "SOAP extension must be enabled for alfresco plugin";
