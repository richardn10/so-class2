<?php // $Id: dbtransfer.php,v 1.1 2008/09/02 21:20:46 skodak Exp $

$string['dbexport'] = 'Database export';
$string['dbtransfer'] = 'Database transfer';
$string['differenttableexception'] = 'Table $a structure does not match.';
$string['exportdata'] = 'Export data';
$string['exportschemaexception'] = 'Current database structure does not match all install.xml files. <br /> $a';
$string['importschemaexception'] = 'Current database structure does not match all install.xml files. <br /> $a';
$string['importversionmismatchexception'] = 'Current version $->currentver does match exported version $a->schemaver.';
$string['malformedxmlexception'] = 'Malformed XML found, can not continue.';
$string['notargetconectexception'] = 'Can not connect target database, sorry.';
$string['transferdata'] = 'Transfer data';
$string['unknowntableexception'] = 'Unknown table $a found in export file.';
