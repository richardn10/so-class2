<?PHP  // $Id: report_capability.php,v 1.1 2008/09/08 07:01:41 tjhunt Exp $

$string['capability'] = 'Capability report';
$string['capabilitylabel'] = 'Capability:';
$string['capabilityreport'] = 'Capability report';
$string['changeoverrides'] = 'Change overrides in this context';
$string['changeroles'] = 'Change role definitions';
$string['forroles'] = 'For roles $a';
$string['getreport'] = 'Get the report';
$string['intro'] = 'This report shows, for a particular capability, what permission that capability has in the definition of every role (or a selection of roles), and everywhere in the site where that capability is overridden.';
$string['reportforcapability'] = 'Report for capability \'$a\'';
$string['reportsettings'] = 'Report settings';
$string['roleslabel'] = 'Roles:';
?>
