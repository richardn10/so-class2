<?PHP // $Id: messageprocessor_email.php,v 1.2 2008/09/23 02:27:57 moodler Exp $ 
$string['email'] = 'Email';
?>
