<?php
$string['repositoryname'] = 'WebDAV repository';
$string['webdav_server'] = 'WebDAV server';
$string['webdav_port'] = 'WebDAV server port';
$string['webdav_user'] = 'WebDAV server user';
$string['webdav_password'] = 'WebDAV server password';
