<?php // $Id: repository_flickr_public.php,v 1.2 2008/09/17 06:09:10 jerome Exp $
$string['apikey'] = 'API Key';
$string['callbackurl'] = 'Callback URL';
$string['configplugin'] = 'Flickr Public configuration';
$string['emailaddress'] = 'Email address';
$string['information'] = '<div style=\"font-size:0.8em\">Get <a href=\"http://www.flickr.com/services/api/keys/\">Flickr API Key</a> for your Moodle site. </div>';
$string['invalidemail'] = 'Invalid email address for flickr';
$string['notitle'] = 'notitle';
$string['nullphotolist'] = 'There are no photos in this account';
$string['remember'] = 'Remember me';
$string['repositoryname'] = 'Flickr Public';
$string['repositorydesc'] = 'Repository on flickr.com';
$string['secret'] = 'Secret';
$string['username'] = 'Flickr account email';

