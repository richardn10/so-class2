<?php // $Id: qtype_missingtype.php,v 1.1 2008/09/09 08:43:39 tjhunt Exp $ 

$string['missingtype'] = 'Missing type';
$string['warningmissingtype'] = '<b>This question is of a type that has not been installed on your Moodle yet.<br />Please alert your Moodle administrator.</b>';
?>
