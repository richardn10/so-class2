<?php
$string['apikey'] = 'API Key';
$string['configplugin'] = 'Box.net configuration';
$string['information'] = '<div style=\"font-size:0.8em\">Get <a href=\"http://enabled.box.net/\">Box.net API Key</a> for your Moodle site. </div>';
$string['invalidpassword'] = 'Invalid password';
$stirng['invalidtoken'] = 'Invalid authentication token';
$string['nullfilelist'] = 'There are no files in this repository';
$string['password'] = 'Password';
$string['repositorydesc'] = 'Repository on Box.net';
$string['repositoryname'] = 'Box.net';
$string['saved'] = 'Box.net data saved';
$string['shareurl'] = 'Share URL';
$string['username'] = 'Username for Box.net';
