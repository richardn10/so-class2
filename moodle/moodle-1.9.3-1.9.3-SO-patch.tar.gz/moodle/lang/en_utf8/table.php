<?php  // $Id: table.php,v 1.2 2008/08/15 10:06:11 jamiesensei Exp $
$string['downloadas'] = 'Download table data as';
$string['downloadexcel'] = 'a Microsoft Excel spreadsheet';
$string['downloadods'] = 'an OpenDocument Spreadsheet (ODS)';
$string['downloadtsv'] = 'a tab separated values text file';
$string['downloadcsv'] = 'a comma separated values text file';
$string['downloadxhtml'] = 'an unpaged XHTML document';
$string['tableexportformats'] = 'Downloading Table Data';
?>
