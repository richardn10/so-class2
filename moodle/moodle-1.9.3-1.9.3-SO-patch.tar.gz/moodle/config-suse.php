<?php
include ('/etc/moodle/moodle-config.php');
?>
