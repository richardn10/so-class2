-- MySQL dump 10.11
--
-- Host: localhost    Database: moodle
-- ------------------------------------------------------
-- Server version	5.0.75-0ubuntu10.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adodb_logsql`
--

DROP TABLE IF EXISTS `adodb_logsql`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `adodb_logsql` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `created` datetime NOT NULL,
  `sql0` varchar(250) NOT NULL default '',
  `sql1` text,
  `params` text,
  `tracer` text,
  `timer` decimal(16,6) NOT NULL default '0.000000',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to save some logs from ADOdb';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `adodb_logsql`
--

LOCK TABLES `adodb_logsql` WRITE;
/*!40000 ALTER TABLE `adodb_logsql` DISABLE KEYS */;
/*!40000 ALTER TABLE `adodb_logsql` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment`
--

DROP TABLE IF EXISTS `assignment`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `assignment` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `format` smallint(4) unsigned NOT NULL default '0',
  `assignmenttype` varchar(50) NOT NULL default '',
  `resubmit` tinyint(2) unsigned NOT NULL default '0',
  `preventlate` tinyint(2) unsigned NOT NULL default '0',
  `emailteachers` tinyint(2) unsigned NOT NULL default '0',
  `var1` bigint(10) default '0',
  `var2` bigint(10) default '0',
  `var3` bigint(10) default '0',
  `var4` bigint(10) default '0',
  `var5` bigint(10) default '0',
  `maxbytes` bigint(10) unsigned NOT NULL default '100000',
  `timedue` bigint(10) unsigned NOT NULL default '0',
  `timeavailable` bigint(10) unsigned NOT NULL default '0',
  `grade` bigint(10) NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `assi_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines assignments';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `assignment`
--

LOCK TABLES `assignment` WRITE;
/*!40000 ALTER TABLE `assignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `assignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment_submissions`
--

DROP TABLE IF EXISTS `assignment_submissions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `assignment_submissions` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `assignment` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `numfiles` bigint(10) unsigned NOT NULL default '0',
  `data1` text,
  `data2` text,
  `grade` bigint(11) NOT NULL default '0',
  `submissioncomment` text NOT NULL,
  `format` smallint(4) unsigned NOT NULL default '0',
  `teacher` bigint(10) unsigned NOT NULL default '0',
  `timemarked` bigint(10) unsigned NOT NULL default '0',
  `mailed` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `assisubm_use_ix` (`userid`),
  KEY `assisubm_mai_ix` (`mailed`),
  KEY `assisubm_tim_ix` (`timemarked`),
  KEY `assisubm_ass_ix` (`assignment`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about submitted assignments';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `assignment_submissions`
--

LOCK TABLES `assignment_submissions` WRITE;
/*!40000 ALTER TABLE `assignment_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assignment_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_config`
--

DROP TABLE IF EXISTS `backup_config`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `backup_config` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `backconf_nam_uix` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='To store backup configuration variables';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `backup_config`
--

LOCK TABLES `backup_config` WRITE;
/*!40000 ALTER TABLE `backup_config` DISABLE KEYS */;
INSERT INTO `backup_config` VALUES (1,'backup_sche_modules','0'),(2,'backup_sche_withuserdata','0'),(3,'backup_sche_metacourse','0'),(4,'backup_sche_users','0'),(5,'backup_sche_logs','0'),(6,'backup_sche_userfiles','0'),(7,'backup_sche_coursefiles','0'),(8,'backup_sche_sitefiles','0'),(9,'backup_sche_messages','0'),(10,'backup_sche_blogs','0'),(11,'backup_sche_keep','1'),(12,'backup_sche_active','0'),(13,'backup_sche_weekdays','0000000'),(14,'backup_sche_hour','0'),(15,'backup_sche_minute','0'),(16,'backup_sche_destination','');
/*!40000 ALTER TABLE `backup_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_courses`
--

DROP TABLE IF EXISTS `backup_courses`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `backup_courses` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `laststarttime` bigint(10) unsigned NOT NULL default '0',
  `lastendtime` bigint(10) unsigned NOT NULL default '0',
  `laststatus` varchar(1) NOT NULL default '0',
  `nextstarttime` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `backcour_cou_uix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To store every course backup status';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `backup_courses`
--

LOCK TABLES `backup_courses` WRITE;
/*!40000 ALTER TABLE `backup_courses` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_files`
--

DROP TABLE IF EXISTS `backup_files`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `backup_files` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `backup_code` bigint(10) unsigned NOT NULL default '0',
  `file_type` varchar(10) NOT NULL default '',
  `path` varchar(255) NOT NULL default '',
  `old_id` bigint(10) unsigned NOT NULL default '0',
  `new_id` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `backfile_bacfilpat_uix` (`backup_code`,`file_type`,`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To store and recode ids to user and course files';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `backup_files`
--

LOCK TABLES `backup_files` WRITE;
/*!40000 ALTER TABLE `backup_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_ids`
--

DROP TABLE IF EXISTS `backup_ids`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `backup_ids` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `backup_code` bigint(12) unsigned NOT NULL default '0',
  `table_name` varchar(30) NOT NULL default '',
  `old_id` bigint(10) unsigned NOT NULL default '0',
  `new_id` bigint(10) unsigned NOT NULL default '0',
  `info` mediumtext NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `backids_bactabold_uix` (`backup_code`,`table_name`,`old_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To store and convert ids in backup/restore';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `backup_ids`
--

LOCK TABLES `backup_ids` WRITE;
/*!40000 ALTER TABLE `backup_ids` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_ids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_log`
--

DROP TABLE IF EXISTS `backup_log`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `backup_log` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `time` bigint(10) unsigned NOT NULL default '0',
  `laststarttime` bigint(10) unsigned NOT NULL default '0',
  `info` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `backlog_cou_ix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To store every course backup log info';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `backup_log`
--

LOCK TABLES `backup_log` WRITE;
/*!40000 ALTER TABLE `backup_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `block`
--

DROP TABLE IF EXISTS `block`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `block` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(40) NOT NULL default '',
  `version` bigint(10) unsigned NOT NULL default '0',
  `cron` bigint(10) unsigned NOT NULL default '0',
  `lastcron` bigint(10) unsigned NOT NULL default '0',
  `visible` tinyint(1) NOT NULL default '1',
  `multiple` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='to store installed blocks';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `block`
--

LOCK TABLES `block` WRITE;
/*!40000 ALTER TABLE `block` DISABLE KEYS */;
INSERT INTO `block` VALUES (1,'activity_modules',2007101509,0,0,1,0),(2,'admin',2007101509,0,0,1,0),(3,'admin_bookmarks',2007101509,0,0,1,0),(4,'admin_tree',2007101509,0,0,1,0),(5,'blog_menu',2007101509,0,0,1,0),(6,'blog_tags',2007101509,0,0,1,1),(7,'calendar_month',2007101509,0,0,1,0),(8,'calendar_upcoming',2007101509,0,0,1,0),(9,'course_list',2007101509,0,0,1,0),(10,'course_summary',2007101509,0,0,1,0),(11,'glossary_random',2007101509,0,0,1,1),(12,'html',2007101509,0,0,1,1),(13,'loancalc',2007101509,0,0,1,0),(14,'login',2007101509,0,0,1,0),(15,'mentees',2007101509,0,0,1,1),(16,'messages',2007101509,0,0,1,0),(17,'mnet_hosts',2007101509,0,0,1,0),(18,'news_items',2007101509,0,0,1,0),(19,'online_users',2007101509,0,0,1,0),(20,'participants',2007101509,0,0,1,0),(21,'quiz_results',2007101509,0,0,1,1),(22,'recent_activity',2007101509,0,0,1,0),(23,'rss_client',2007101511,300,0,1,1),(24,'search',2008031500,1,0,1,0),(25,'search_forums',2007101509,0,0,1,0),(26,'section_links',2007101509,0,0,1,0),(27,'site_main_menu',2007101509,0,0,1,0),(28,'social_activities',2007101509,0,0,1,0),(29,'tag_flickr',2007101509,0,0,1,1),(30,'tag_youtube',2007101509,0,0,1,1),(31,'tags',2007101509,0,0,1,1),(32,'inline_flv',200909200920,0,0,1,1);
/*!40000 ALTER TABLE `block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `block_instance`
--

DROP TABLE IF EXISTS `block_instance`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `block_instance` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `blockid` bigint(10) unsigned NOT NULL default '0',
  `pageid` bigint(10) unsigned NOT NULL default '0',
  `pagetype` varchar(20) NOT NULL default '',
  `position` varchar(10) NOT NULL default '',
  `weight` smallint(3) NOT NULL default '0',
  `visible` tinyint(1) NOT NULL default '0',
  `configdata` text,
  PRIMARY KEY  (`id`),
  KEY `blocinst_pag_ix` (`pageid`),
  KEY `blocinst_pag2_ix` (`pagetype`),
  KEY `blocinst_blo_ix` (`blockid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='to store block instances in pages';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `block_instance`
--

LOCK TABLES `block_instance` WRITE;
/*!40000 ALTER TABLE `block_instance` DISABLE KEYS */;
INSERT INTO `block_instance` VALUES (1,27,1,'course-view','l',0,1,''),(2,4,1,'course-view','l',1,1,''),(3,10,1,'course-view','r',0,1,''),(4,7,1,'course-view','r',1,1,''),(5,4,0,'admin','l',0,1,''),(6,3,0,'admin','l',1,1,'');
/*!40000 ALTER TABLE `block_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `block_pinned`
--

DROP TABLE IF EXISTS `block_pinned`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `block_pinned` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `blockid` bigint(10) unsigned NOT NULL default '0',
  `pagetype` varchar(20) NOT NULL default '',
  `position` varchar(10) NOT NULL default '',
  `weight` smallint(3) NOT NULL default '0',
  `visible` tinyint(1) NOT NULL default '0',
  `configdata` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `blocpinn_pag_ix` (`pagetype`),
  KEY `blocpinn_blo_ix` (`blockid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to pin blocks';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `block_pinned`
--

LOCK TABLES `block_pinned` WRITE;
/*!40000 ALTER TABLE `block_pinned` DISABLE KEYS */;
/*!40000 ALTER TABLE `block_pinned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `block_rss_client`
--

DROP TABLE IF EXISTS `block_rss_client`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `block_rss_client` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `title` text NOT NULL,
  `preferredtitle` varchar(64) NOT NULL default '',
  `description` text NOT NULL,
  `shared` tinyint(2) unsigned NOT NULL default '0',
  `url` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Remote news feed information. Contains the news feed id, the';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `block_rss_client`
--

LOCK TABLES `block_rss_client` WRITE;
/*!40000 ALTER TABLE `block_rss_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `block_rss_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `block_search_documents`
--

DROP TABLE IF EXISTS `block_search_documents`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `block_search_documents` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `docid` varchar(32) NOT NULL default '',
  `doctype` varchar(32) NOT NULL default 'none',
  `itemtype` varchar(32) NOT NULL default 'standard',
  `title` varchar(255) NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  `docdate` bigint(10) unsigned NOT NULL default '0',
  `updated` bigint(10) unsigned NOT NULL default '0',
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `groupid` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `blocseardocu_doc_ix` (`docid`),
  KEY `blocseardocu_doc2_ix` (`doctype`),
  KEY `blocseardocu_ite_ix` (`itemtype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='table to store search index backups';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `block_search_documents`
--

LOCK TABLES `block_search_documents` WRITE;
/*!40000 ALTER TABLE `block_search_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `block_search_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_filters`
--

DROP TABLE IF EXISTS `cache_filters`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache_filters` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `filter` varchar(32) NOT NULL default '',
  `version` bigint(10) unsigned NOT NULL default '0',
  `md5key` varchar(32) NOT NULL default '',
  `rawtext` text NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cachfilt_filmd5_ix` (`filter`,`md5key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='For keeping information about cached data';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cache_filters`
--

LOCK TABLES `cache_filters` WRITE;
/*!40000 ALTER TABLE `cache_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_flags`
--

DROP TABLE IF EXISTS `cache_flags`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache_flags` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `flagtype` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `value` mediumtext NOT NULL,
  `expiry` bigint(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cachflag_fla_ix` (`flagtype`),
  KEY `cachflag_nam_ix` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Cache of time-sensitive flags';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cache_flags`
--

LOCK TABLES `cache_flags` WRITE;
/*!40000 ALTER TABLE `cache_flags` DISABLE KEYS */;
INSERT INTO `cache_flags` VALUES (1,'accesslib/dirtycontexts','/1',1253737996,'1',1253745196);
/*!40000 ALTER TABLE `cache_flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_text`
--

DROP TABLE IF EXISTS `cache_text`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache_text` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `md5key` varchar(32) NOT NULL default '',
  `formattedtext` longtext NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cachtext_md5_ix` (`md5key`),
  KEY `cachtext_tim_ix` (`timemodified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='For storing temporary copies of processed texts';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cache_text`
--

LOCK TABLES `cache_text` WRITE;
/*!40000 ALTER TABLE `cache_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `capabilities`
--

DROP TABLE IF EXISTS `capabilities`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `capabilities` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `captype` varchar(50) NOT NULL default '',
  `contextlevel` bigint(10) unsigned NOT NULL default '0',
  `component` varchar(100) NOT NULL default '',
  `riskbitmask` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `capa_nam_uix` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=214 DEFAULT CHARSET=utf8 COMMENT='this defines all capabilities';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `capabilities`
--

LOCK TABLES `capabilities` WRITE;
/*!40000 ALTER TABLE `capabilities` DISABLE KEYS */;
INSERT INTO `capabilities` VALUES (1,'moodle/site:doanything','admin',10,'moodle',62),(2,'moodle/legacy:guest','legacy',10,'moodle',0),(3,'moodle/legacy:user','legacy',10,'moodle',0),(4,'moodle/legacy:student','legacy',10,'moodle',16),(5,'moodle/legacy:teacher','legacy',10,'moodle',24),(6,'moodle/legacy:editingteacher','legacy',10,'moodle',28),(7,'moodle/legacy:coursecreator','legacy',10,'moodle',28),(8,'moodle/legacy:admin','legacy',10,'moodle',62),(9,'moodle/site:config','write',10,'moodle',62),(10,'moodle/site:readallmessages','read',10,'moodle',8),(11,'moodle/site:sendmessage','write',10,'moodle',16),(12,'moodle/site:approvecourse','write',10,'moodle',4),(13,'moodle/site:import','write',50,'moodle',28),(14,'moodle/site:backup','write',50,'moodle',28),(15,'moodle/site:restore','write',50,'moodle',28),(16,'moodle/site:manageblocks','write',80,'moodle',20),(17,'moodle/site:accessallgroups','read',50,'moodle',0),(18,'moodle/site:viewfullnames','read',50,'moodle',0),(19,'moodle/site:viewreports','read',50,'moodle',8),(20,'moodle/site:trustcontent','write',50,'moodle',4),(21,'moodle/site:uploadusers','write',10,'moodle',24),(22,'moodle/site:langeditmaster','write',10,'moodle',6),(23,'moodle/site:langeditlocal','write',10,'moodle',6),(24,'moodle/user:create','write',10,'moodle',24),(25,'moodle/user:delete','write',10,'moodle',8),(26,'moodle/user:update','write',10,'moodle',24),(27,'moodle/user:viewdetails','read',50,'moodle',0),(28,'moodle/user:viewhiddendetails','read',50,'moodle',8),(29,'moodle/user:loginas','write',50,'moodle',30),(30,'moodle/role:assign','write',50,'moodle',28),(31,'moodle/role:override','write',50,'moodle',28),(32,'moodle/role:safeoverride','write',50,'moodle',16),(33,'moodle/role:manage','write',10,'moodle',28),(34,'moodle/role:unassignself','write',50,'moodle',0),(35,'moodle/role:viewhiddenassigns','read',50,'moodle',0),(36,'moodle/role:switchroles','read',50,'moodle',12),(37,'moodle/category:create','write',40,'moodle',4),(38,'moodle/category:delete','write',40,'moodle',32),(39,'moodle/category:update','write',40,'moodle',4),(40,'moodle/category:visibility','write',40,'moodle',0),(41,'moodle/course:create','write',40,'moodle',4),(42,'moodle/course:delete','write',50,'moodle',32),(43,'moodle/course:update','write',50,'moodle',4),(44,'moodle/course:view','read',50,'moodle',0),(45,'moodle/course:bulkmessaging','write',50,'moodle',16),(46,'moodle/course:viewhiddenuserfields','read',50,'moodle',8),(47,'moodle/course:viewhiddencourses','read',50,'moodle',0),(48,'moodle/course:visibility','write',50,'moodle',0),(49,'moodle/course:managefiles','write',50,'moodle',4),(50,'moodle/course:manageactivities','write',50,'moodle',4),(51,'moodle/course:managemetacourse','write',50,'moodle',12),(52,'moodle/course:activityvisibility','write',50,'moodle',0),(53,'moodle/course:viewhiddenactivities','write',50,'moodle',0),(54,'moodle/course:viewparticipants','read',50,'moodle',0),(55,'moodle/course:changefullname','write',50,'moodle',4),(56,'moodle/course:changeshortname','write',50,'moodle',4),(57,'moodle/course:changeidnumber','write',50,'moodle',4),(58,'moodle/site:viewparticipants','read',10,'moodle',0),(59,'moodle/course:viewscales','read',50,'moodle',0),(60,'moodle/course:managescales','write',50,'moodle',0),(61,'moodle/course:managegroups','write',50,'moodle',0),(62,'moodle/course:reset','write',50,'moodle',32),(63,'moodle/blog:view','read',50,'moodle',0),(64,'moodle/blog:create','write',10,'moodle',16),(65,'moodle/blog:manageentries','write',50,'moodle',16),(66,'moodle/calendar:manageownentries','write',50,'moodle',16),(67,'moodle/calendar:managegroupentries','write',50,'moodle',16),(68,'moodle/calendar:manageentries','write',50,'moodle',16),(69,'moodle/user:editprofile','write',30,'moodle',24),(70,'moodle/user:editownprofile','write',10,'moodle',16),(71,'moodle/user:changeownpassword','write',10,'moodle',0),(72,'moodle/user:readuserposts','read',30,'moodle',0),(73,'moodle/user:readuserblogs','read',30,'moodle',0),(74,'moodle/user:viewuseractivitiesreport','read',30,'moodle',0),(75,'moodle/question:managecategory','write',50,'moodle',20),(76,'moodle/question:add','write',50,'moodle',20),(77,'moodle/question:editmine','write',50,'moodle',20),(78,'moodle/question:editall','write',50,'moodle',20),(79,'moodle/question:viewmine','read',50,'moodle',0),(80,'moodle/question:viewall','read',50,'moodle',0),(81,'moodle/question:usemine','read',50,'moodle',0),(82,'moodle/question:useall','read',50,'moodle',0),(83,'moodle/question:movemine','write',50,'moodle',0),(84,'moodle/question:moveall','write',50,'moodle',0),(85,'moodle/question:config','write',10,'moodle',2),(86,'moodle/site:doclinks','read',10,'moodle',0),(87,'moodle/course:sectionvisibility','write',50,'moodle',0),(88,'moodle/course:useremail','write',50,'moodle',0),(89,'moodle/course:viewhiddensections','write',50,'moodle',0),(90,'moodle/course:setcurrentsection','write',50,'moodle',0),(91,'moodle/site:mnetlogintoremote','read',10,'moodle',12),(92,'moodle/grade:viewall','read',50,'moodle',8),(93,'moodle/grade:view','read',50,'moodle',0),(94,'moodle/grade:viewhidden','read',50,'moodle',8),(95,'moodle/grade:import','write',50,'moodle',12),(96,'moodle/grade:export','read',50,'moodle',8),(97,'moodle/grade:manage','write',50,'moodle',12),(98,'moodle/grade:edit','write',50,'moodle',12),(99,'moodle/grade:manageoutcomes','write',50,'moodle',0),(100,'moodle/grade:manageletters','write',50,'moodle',0),(101,'moodle/grade:hide','write',50,'moodle',0),(102,'moodle/grade:lock','write',50,'moodle',0),(103,'moodle/grade:unlock','write',50,'moodle',0),(104,'moodle/my:manageblocks','write',10,'moodle',0),(105,'moodle/notes:view','read',50,'moodle',0),(106,'moodle/notes:manage','write',50,'moodle',16),(107,'moodle/tag:manage','write',10,'moodle',16),(108,'moodle/tag:create','write',10,'moodle',16),(109,'moodle/tag:edit','write',10,'moodle',16),(110,'moodle/tag:editblocks','write',10,'moodle',0),(111,'moodle/block:view','read',80,'moodle',0),(112,'mod/assignment:view','read',70,'mod/assignment',0),(113,'mod/assignment:submit','write',70,'mod/assignment',0),(114,'mod/assignment:grade','write',70,'mod/assignment',4),(115,'mod/chat:chat','write',70,'mod/chat',16),(116,'mod/chat:readlog','read',70,'mod/chat',0),(117,'mod/chat:deletelog','write',70,'mod/chat',0),(118,'mod/choice:choose','write',70,'mod/choice',0),(119,'mod/choice:readresponses','read',70,'mod/choice',0),(120,'mod/choice:deleteresponses','write',70,'mod/choice',0),(121,'mod/choice:downloadresponses','read',70,'mod/choice',0),(122,'mod/data:viewentry','read',70,'mod/data',0),(123,'mod/data:writeentry','write',70,'mod/data',16),(124,'mod/data:comment','write',70,'mod/data',16),(125,'mod/data:viewrating','read',70,'mod/data',0),(126,'mod/data:rate','write',70,'mod/data',0),(127,'mod/data:approve','write',70,'mod/data',16),(128,'mod/data:manageentries','write',70,'mod/data',16),(129,'mod/data:managecomments','write',70,'mod/data',16),(130,'mod/data:managetemplates','write',70,'mod/data',20),(131,'mod/data:viewalluserpresets','read',70,'mod/data',0),(132,'mod/data:manageuserpresets','write',70,'mod/data',20),(133,'mod/forum:viewdiscussion','read',70,'mod/forum',0),(134,'mod/forum:viewhiddentimedposts','read',70,'mod/forum',0),(135,'mod/forum:startdiscussion','write',70,'mod/forum',16),(136,'mod/forum:replypost','write',70,'mod/forum',16),(137,'mod/forum:addnews','write',70,'mod/forum',16),(138,'mod/forum:replynews','write',70,'mod/forum',16),(139,'mod/forum:viewrating','read',70,'mod/forum',0),(140,'mod/forum:viewanyrating','read',70,'mod/forum',0),(141,'mod/forum:rate','write',70,'mod/forum',0),(142,'mod/forum:createattachment','write',70,'mod/forum',16),(143,'mod/forum:deleteownpost','read',70,'mod/forum',0),(144,'mod/forum:deleteanypost','read',70,'mod/forum',0),(145,'mod/forum:splitdiscussions','read',70,'mod/forum',0),(146,'mod/forum:movediscussions','read',70,'mod/forum',0),(147,'mod/forum:editanypost','write',70,'mod/forum',16),(148,'mod/forum:viewqandawithoutposting','read',70,'mod/forum',0),(149,'mod/forum:viewsubscribers','read',70,'mod/forum',0),(150,'mod/forum:managesubscriptions','read',70,'mod/forum',16),(151,'mod/forum:initialsubscriptions','read',70,'mod/forum',0),(152,'mod/forum:throttlingapplies','write',70,'mod/forum',16),(153,'mod/glossary:write','write',70,'mod/glossary',16),(154,'mod/glossary:manageentries','write',70,'mod/glossary',16),(155,'mod/glossary:managecategories','write',70,'mod/glossary',16),(156,'mod/glossary:comment','write',70,'mod/glossary',16),(157,'mod/glossary:managecomments','write',70,'mod/glossary',16),(158,'mod/glossary:import','write',70,'mod/glossary',16),(159,'mod/glossary:export','read',70,'mod/glossary',0),(160,'mod/glossary:approve','write',70,'mod/glossary',16),(161,'mod/glossary:rate','write',70,'mod/glossary',0),(162,'mod/glossary:viewrating','read',70,'mod/glossary',0),(163,'mod/hotpot:attempt','read',70,'mod/hotpot',0),(164,'mod/hotpot:viewreport','read',70,'mod/hotpot',0),(165,'mod/hotpot:grade','read',70,'mod/hotpot',0),(166,'mod/hotpot:deleteattempt','read',70,'mod/hotpot',0),(167,'mod/lams:participate','write',70,'mod/lams',0),(168,'mod/lams:manage','write',70,'mod/lams',0),(169,'mod/lesson:edit','write',70,'mod/lesson',4),(170,'mod/lesson:manage','write',70,'mod/lesson',0),(171,'mod/quiz:view','read',70,'mod/quiz',0),(172,'mod/quiz:attempt','write',70,'mod/quiz',0),(173,'mod/quiz:manage','write',70,'mod/quiz',16),(174,'mod/quiz:preview','write',70,'mod/quiz',0),(175,'mod/quiz:grade','write',70,'mod/quiz',20),(176,'mod/quiz:viewreports','read',70,'mod/quiz',8),(177,'mod/quiz:deleteattempts','write',70,'mod/quiz',32),(178,'mod/quiz:ignoretimelimits','read',70,'mod/quiz',0),(179,'mod/quiz:emailconfirmsubmission','read',70,'mod/quiz',0),(180,'mod/quiz:emailnotifysubmission','read',70,'mod/quiz',0),(181,'mod/scorm:viewreport','read',70,'mod/scorm',0),(182,'mod/scorm:skipview','write',70,'mod/scorm',0),(183,'mod/scorm:savetrack','write',70,'mod/scorm',0),(184,'mod/scorm:viewscores','read',70,'mod/scorm',0),(185,'mod/survey:participate','read',70,'mod/survey',0),(186,'mod/survey:readresponses','read',70,'mod/survey',0),(187,'mod/survey:download','read',70,'mod/survey',0),(188,'mod/wiki:participate','write',70,'mod/wiki',16),(189,'mod/wiki:manage','write',70,'mod/wiki',16),(190,'mod/wiki:overridelock','write',70,'mod/wiki',0),(191,'mod/workshop:participate','write',70,'mod/workshop',16),(192,'mod/workshop:manage','write',70,'mod/workshop',16),(193,'block/rss_client:createprivatefeeds','write',80,'block/rss_client',0),(194,'block/rss_client:createsharedfeeds','write',80,'block/rss_client',16),(195,'block/rss_client:manageownfeeds','write',80,'block/rss_client',0),(196,'block/rss_client:manageanyfeeds','write',80,'block/rss_client',16),(197,'enrol/authorize:managepayments','write',10,'enrol/authorize',8),(198,'enrol/authorize:uploadcsv','write',10,'enrol/authorize',4),(199,'gradeexport/ods:view','read',50,'gradeexport/ods',8),(200,'gradeexport/ods:publish','read',50,'gradeexport/ods',8),(201,'gradeexport/txt:view','read',50,'gradeexport/txt',8),(202,'gradeexport/txt:publish','read',50,'gradeexport/txt',8),(203,'gradeexport/xls:view','read',50,'gradeexport/xls',8),(204,'gradeexport/xls:publish','read',50,'gradeexport/xls',8),(205,'gradeexport/xml:view','read',50,'gradeexport/xml',8),(206,'gradeexport/xml:publish','read',50,'gradeexport/xml',8),(207,'gradeimport/csv:view','write',50,'gradeimport/csv',0),(208,'gradeimport/xml:view','write',50,'gradeimport/xml',0),(209,'gradeimport/xml:publish','write',50,'gradeimport/xml',0),(210,'gradereport/grader:view','read',50,'gradereport/grader',8),(211,'gradereport/outcomes:view','read',50,'gradereport/outcomes',8),(212,'gradereport/overview:view','read',50,'gradereport/overview',8),(213,'gradereport/user:view','read',50,'gradereport/user',8);
/*!40000 ALTER TABLE `capabilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `chat` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `intro` text NOT NULL,
  `keepdays` bigint(11) NOT NULL default '0',
  `studentlogs` smallint(4) NOT NULL default '0',
  `chattime` bigint(10) unsigned NOT NULL default '0',
  `schedule` smallint(4) NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `chat_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Each of these is a chat room';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `chat`
--

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `chat_messages` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `chatid` bigint(10) NOT NULL default '0',
  `userid` bigint(10) NOT NULL default '0',
  `groupid` bigint(10) NOT NULL default '0',
  `system` tinyint(1) unsigned NOT NULL default '0',
  `message` text NOT NULL,
  `timestamp` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `chatmess_use_ix` (`userid`),
  KEY `chatmess_gro_ix` (`groupid`),
  KEY `chatmess_timcha_ix` (`timestamp`,`chatid`),
  KEY `chatmess_cha_ix` (`chatid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores all the actual chat messages';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_users`
--

DROP TABLE IF EXISTS `chat_users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `chat_users` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `chatid` bigint(11) NOT NULL default '0',
  `userid` bigint(11) NOT NULL default '0',
  `groupid` bigint(11) NOT NULL default '0',
  `version` varchar(16) NOT NULL default '',
  `ip` varchar(15) NOT NULL default '',
  `firstping` bigint(10) unsigned NOT NULL default '0',
  `lastping` bigint(10) unsigned NOT NULL default '0',
  `lastmessageping` bigint(10) unsigned NOT NULL default '0',
  `sid` varchar(32) NOT NULL default '',
  `course` bigint(10) unsigned NOT NULL default '0',
  `lang` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `chatuser_use_ix` (`userid`),
  KEY `chatuser_las_ix` (`lastping`),
  KEY `chatuser_gro_ix` (`groupid`),
  KEY `chatuser_cha_ix` (`chatid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Keeps track of which users are in which chat rooms';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `chat_users`
--

LOCK TABLES `chat_users` WRITE;
/*!40000 ALTER TABLE `chat_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `choice`
--

DROP TABLE IF EXISTS `choice`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `choice` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `text` text NOT NULL,
  `format` tinyint(2) unsigned NOT NULL default '0',
  `publish` tinyint(2) unsigned NOT NULL default '0',
  `showresults` tinyint(2) unsigned NOT NULL default '0',
  `display` smallint(4) unsigned NOT NULL default '0',
  `allowupdate` tinyint(2) unsigned NOT NULL default '0',
  `showunanswered` tinyint(2) unsigned NOT NULL default '0',
  `limitanswers` tinyint(2) unsigned NOT NULL default '0',
  `timeopen` bigint(10) unsigned NOT NULL default '0',
  `timeclose` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `choi_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Available choices are stored here';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `choice`
--

LOCK TABLES `choice` WRITE;
/*!40000 ALTER TABLE `choice` DISABLE KEYS */;
/*!40000 ALTER TABLE `choice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `choice_answers`
--

DROP TABLE IF EXISTS `choice_answers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `choice_answers` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `choiceid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `optionid` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `choiansw_use_ix` (`userid`),
  KEY `choiansw_cho_ix` (`choiceid`),
  KEY `choiansw_opt_ix` (`optionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='choices performed by users';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `choice_answers`
--

LOCK TABLES `choice_answers` WRITE;
/*!40000 ALTER TABLE `choice_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `choice_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `choice_options`
--

DROP TABLE IF EXISTS `choice_options`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `choice_options` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `choiceid` bigint(10) unsigned NOT NULL default '0',
  `text` text,
  `maxanswers` bigint(10) unsigned default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `choiopti_cho_ix` (`choiceid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='available options to choice';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `choice_options`
--

LOCK TABLES `choice_options` WRITE;
/*!40000 ALTER TABLE `choice_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `choice_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `config` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `value` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `conf_nam_uix` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=381 DEFAULT CHARSET=utf8 COMMENT='Moodle configuration variables';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'unicodedb','1'),(2,'statsrolesupgraded','1253737974'),(3,'auth','email'),(4,'auth_pop3mailbox','INBOX'),(5,'enrol','manual'),(6,'enrol_plugins_enabled','manual'),(7,'style','default'),(8,'template','default'),(9,'theme','SwitchedOn'),(10,'filter_multilang_converted','1'),(380,'registerauth',''),(12,'guestloginbutton','1'),(13,'alternateloginurl',''),(14,'forgottenpasswordurl',''),(15,'auth_instructions',''),(16,'allowemailaddresses',''),(17,'denyemailaddresses',''),(18,'verifychangedemail','1'),(19,'recaptchapublickey',''),(20,'recaptchaprivatekey',''),(21,'nodefaultuserrolelists','0'),(22,'autologinguests','0'),(23,'hiddenuserfields',''),(24,'enablecourserequests','0'),(25,'enableoutcomes','0'),(26,'grade_profilereport','user'),(27,'grade_aggregationposition','1'),(28,'grade_includescalesinaggregation','1'),(29,'grade_hiddenasdate','0'),(30,'gradepublishing','0'),(31,'grade_export_displaytype','1'),(32,'grade_export_decimalpoints','2'),(33,'gradeexport',''),(34,'grade_hideforcedsettings','1'),(35,'grade_aggregation','11'),(36,'grade_aggregation_flag','0'),(37,'grade_aggregateonlygraded','1'),(38,'grade_aggregateonlygraded_flag','2'),(39,'grade_aggregateoutcomes','0'),(40,'grade_aggregateoutcomes_flag','2'),(41,'grade_aggregatesubcats','0'),(42,'grade_aggregatesubcats_flag','2'),(43,'grade_keephigh','0'),(44,'grade_keephigh_flag','3'),(45,'grade_droplow','0'),(46,'grade_droplow_flag','2'),(47,'grade_displaytype','1'),(48,'grade_decimalpoints','2'),(49,'grade_item_advanced','iteminfo,idnumber,gradepass,plusfactor,multfactor,display,decimals,hiddenuntil,locktime'),(50,'grade_report_studentsperpage','100'),(51,'grade_report_quickgrading','1'),(52,'grade_report_showquickfeedback','0'),(53,'grade_report_aggregationview','0'),(54,'grade_report_meanselection','1'),(55,'grade_report_showcalculations','0'),(56,'grade_report_showeyecons','0'),(57,'grade_report_showaverages','1'),(58,'grade_report_showgroups','0'),(59,'grade_report_showlocks','0'),(60,'grade_report_showranges','0'),(61,'grade_report_showuserimage','1'),(62,'grade_report_showuseridnumber','0'),(63,'grade_report_showactivityicons','1'),(64,'grade_report_shownumberofgrades','0'),(65,'grade_report_averagesdisplaytype','inherit'),(66,'grade_report_rangesdisplaytype','inherit'),(67,'grade_report_averagesdecimalpoints','inherit'),(68,'grade_report_rangesdecimalpoints','inherit'),(69,'grade_report_overview_showrank','0'),(70,'grade_report_user_showrank','0'),(71,'grade_report_user_showpercentage','2'),(72,'grade_report_user_showhiddenitems','1'),(73,'timezone','99'),(74,'forcetimezone','99'),(75,'country','0'),(76,'geoipfile','/var/moodledata/geoip/GeoLiteCity.dat'),(77,'googlemapkey',''),(78,'autolang','1'),(79,'lang','en_utf8'),(80,'langmenu','1'),(81,'langlist',''),(82,'langcache','1'),(83,'locale',''),(84,'latinexcelexport','0'),(85,'cachetext','60'),(86,'filteruploadedfiles','0'),(87,'filtermatchoneperpage','0'),(88,'filtermatchonepertext','0'),(89,'filterall','0'),(90,'filter_multilang_force_old','0'),(91,'filter_mediaplugin_enable_mp3','1'),(92,'filter_mediaplugin_enable_swf','0'),(93,'filter_mediaplugin_enable_mov','1'),(94,'filter_mediaplugin_enable_wmv','1'),(95,'filter_mediaplugin_enable_mpg','1'),(96,'filter_mediaplugin_enable_avi','1'),(97,'filter_mediaplugin_enable_flv','1'),(98,'filter_mediaplugin_enable_ram','1'),(99,'filter_mediaplugin_enable_rpm','1'),(100,'filter_mediaplugin_enable_rm','1'),(101,'filter_tex_latexpreamble',' \\usepackage[latin1]{inputenc}\n \\usepackage{amsmath}\n \\usepackage{amsfonts}\n \\RequirePackage{amsmath,amssymb,latexsym}\n'),(102,'filter_tex_latexbackground','#FFFFFF'),(103,'filter_tex_density','120'),(104,'filter_tex_pathlatex','/usr/bin/latex'),(105,'filter_tex_pathdvips','/usr/bin/dvips'),(106,'filter_tex_pathconvert','/usr/bin/convert'),(107,'filter_censor_badwords',''),(108,'protectusernames','1'),(109,'forcelogin','0'),(110,'forceloginforprofiles','1'),(111,'opentogoogle','0'),(112,'maxbytes','0'),(113,'messaging','1'),(114,'allowobjectembed','0'),(115,'enabletrusttext','0'),(116,'maxeditingtime','1800'),(117,'fullnamedisplay','firstname lastname'),(118,'extendedusernamechars','0'),(119,'sitepolicy',''),(120,'bloglevel','4'),(121,'usetags','1'),(122,'keeptagnamecase','1'),(123,'cronclionly','0'),(124,'cronremotepassword',''),(125,'passwordpolicy','0'),(126,'minpasswordlength','8'),(127,'minpassworddigits','1'),(128,'minpasswordlower','1'),(129,'minpasswordupper','1'),(130,'minpasswordnonalphanum','1'),(131,'disableuserimages','0'),(132,'emailchangeconfirmation','1'),(133,'loginhttps','0'),(134,'cookiesecure','0'),(135,'cookiehttponly','0'),(136,'restrictmodulesfor','none'),(137,'restrictbydefault','0'),(138,'displayloginfailures',''),(139,'notifyloginfailures',''),(140,'notifyloginthreshold','10'),(141,'runclamonupload','0'),(142,'pathtoclam',''),(143,'quarantinedir',''),(144,'clamfailureonupload','donothing'),(145,'themelist',''),(146,'allowuserthemes','0'),(147,'allowcoursethemes','0'),(148,'allowcategorythemes','0'),(149,'allowuserblockhiding','1'),(150,'showblocksonmodpages','0'),(151,'hideactivitytypenavlink','0'),(152,'calendar_adminseesall','0'),(153,'calendar_site_timeformat','0'),(154,'calendar_startwday','0'),(155,'calendar_weekend','65'),(156,'calendar_lookahead','21'),(157,'calendar_maxevents','10'),(158,'htmleditor','1'),(159,'editorbackgroundcolor','#ffffff'),(160,'editorfontfamily','Trebuchet MS,Verdana,Arial,Helvetica,sans-serif'),(161,'editorfontsize',''),(162,'editorfontlist','Trebuchet:Trebuchet MS,Verdana,Arial,Helvetica,sans-serif;Arial:arial,helvetica,sans-serif;Courier New:courier new,courier,monospace;Georgia:georgia,times new roman,times,serif;Tahoma:tahoma,arial,helvetica,sans-serif;Times New Roman:times new roman,times,serif;Verdana:verdana,arial,helvetica,sans-serif;Impact:impact;Wingdings:wingdings'),(163,'editorkillword','1'),(164,'editorhidebuttons',''),(165,'emoticons',':-){:}smiley{;}:){:}smiley{;}:-D{:}biggrin{;};-){:}wink{;}:-/{:}mixed{;}V-.{:}thoughtful{;}:-P{:}tongueout{;}B-){:}cool{;}^-){:}approve{;}8-){:}wideeyes{;}:o){:}clown{;}:-({:}sad{;}:({:}sad{;}8-.{:}shy{;}:-I{:}blush{;}:-X{:}kiss{;}8-o{:}surprise{;}P-|{:}blackeye{;}8-[{:}angry{;}xx-P{:}dead{;}|-.{:}sleepy{;}}-]{:}evil{;}(h){:}heart{;}(heart){:}heart{;}(y){:}yes{;}(n){:}no{;}(martin){:}martin{;}( ){:}egg'),(166,'formatstringstriptags','1'),(167,'docroot','http://docs.moodle.org'),(168,'doctonewwindow','0'),(169,'mymoodleredirect','0'),(170,'enableajax','1'),(171,'disablecourseajax','1'),(172,'gdversion','0'),(173,'zip',''),(174,'unzip',''),(175,'pathtodu',''),(176,'aspellpath',''),(177,'smtphosts',''),(178,'smtpuser',''),(179,'smtppass',''),(180,'smtpmaxbulk','1'),(181,'noreplyaddress','noreply@localhost'),(182,'digestmailtime','17'),(183,'sitemailcharset','0'),(184,'allowusermailcharset','0'),(185,'mailnewline','LF'),(186,'supportname','Admin User'),(187,'supportemail','edbuckley@uk2.net'),(188,'supportpage',''),(189,'dbsessions','0'),(190,'sessiontimeout','7200'),(191,'sessioncookie',''),(192,'sessioncookiepath','/'),(193,'enablerssfeeds','0'),(194,'debug','0'),(195,'debugdisplay','1'),(196,'xmlstrictheaders','0'),(197,'debugsmtp','0'),(198,'perfdebug','7'),(199,'enablestats','0'),(200,'statsfirstrun','none'),(201,'statsmaxruntime','0'),(202,'statsruntimedays','31'),(203,'statsruntimestarthour','0'),(204,'statsruntimestartminute','0'),(205,'statsuserthreshold','0'),(206,'statscatdepth','1'),(207,'framename','_top'),(208,'slasharguments','1'),(209,'getremoteaddrconf','0'),(210,'proxyhost',''),(211,'proxyport','0'),(212,'proxytype','HTTP'),(213,'proxyuser',''),(214,'proxypassword',''),(215,'longtimenosee','120'),(216,'deleteunconfirmed','168'),(217,'deleteincompleteusers','0'),(218,'loglifetime','0'),(219,'disablegradehistory','0'),(220,'gradehistorylifetime','0'),(221,'cachetype',''),(222,'rcache','0'),(223,'rcachettl','10'),(224,'intcachemax','10'),(225,'memcachedhosts',''),(226,'memcachedpconn','0'),(227,'enableglobalsearch','0'),(228,'smartpix','0'),(229,'enablehtmlpurifier','0'),(230,'enablegroupings','0'),(231,'mnet_dispatcher_mode','off'),(232,'mnet_localhost_id','1'),(233,'mnet_all_hosts_id','2'),(234,'version','2007101530'),(235,'release','1.9.3 (Build: 20081015)'),(236,'assignment_type_online_version','2005042900'),(237,'hotpot_showtimes','0'),(238,'hotpot_excelencodings',''),(239,'hotpot_initialdisable','1'),(240,'journal_showrecentactivity','1'),(241,'journal_initialdisable','1'),(242,'lams_initialdisable','1'),(243,'quiz_review','16777215'),(244,'quiz_attemptonlast','0'),(245,'quiz_attempts','0'),(246,'quiz_grademethod',''),(247,'quiz_decimalpoints','2'),(248,'quiz_maximumgrade','10'),(249,'quiz_password',''),(250,'quiz_popup','0'),(251,'quiz_questionsperpage','0'),(252,'quiz_shuffleanswers','1'),(253,'quiz_shufflequestions','0'),(254,'quiz_subnet',''),(255,'quiz_timelimit','0'),(256,'quiz_optionflags','1'),(257,'quiz_penaltyscheme','1'),(258,'quiz_delay1','0'),(259,'quiz_delay2','0'),(260,'quiz_fix_review','0'),(261,'quiz_fix_attemptonlast','0'),(262,'quiz_fix_attempts','0'),(263,'quiz_fix_grademethod','0'),(264,'quiz_fix_decimalpoints','0'),(265,'quiz_fix_password','0'),(266,'quiz_fix_popup','0'),(267,'quiz_fix_questionsperpage','0'),(268,'quiz_fix_shuffleanswers','0'),(269,'quiz_fix_shufflequestions','0'),(270,'quiz_fix_subnet','0'),(271,'quiz_fix_timelimit','0'),(272,'quiz_fix_adaptive','0'),(273,'quiz_fix_penaltyscheme','0'),(274,'quiz_fix_delay1','0'),(275,'quiz_fix_delay2','0'),(276,'resource_hide_repository','1'),(277,'workshop_initialdisable','1'),(278,'qtype_calculated_version','2006032200'),(279,'qtype_essay_version','2006032200'),(280,'qtype_match_version','2006032200'),(281,'qtype_multianswer_version','2008050800'),(282,'qtype_multichoice_version','2007081700'),(283,'qtype_numerical_version','2006121500'),(284,'qtype_randomsamatch_version','2006042800'),(285,'qtype_shortanswer_version','2006032200'),(286,'qtype_truefalse_version','2006032200'),(287,'backup_version','2008030300'),(288,'backup_release','1.9'),(289,'blocks_version','2007081300'),(290,'enrol_authorize_version','2006112903'),(291,'enrol_paypal_version','2006092200'),(292,'gradeexport_ods_version','2007092701'),(293,'gradeexport_txt_version','2007092700'),(294,'gradeexport_xls_version','2007092700'),(295,'gradeexport_xml_version','2007092700'),(296,'gradeimport_csv_version','2007072500'),(297,'gradeimport_xml_version','2007092700'),(298,'gradereport_grader_version','2007091700'),(299,'gradereport_outcomes_version','2007073000'),(300,'gradereport_overview_version','2007100801'),(301,'gradereport_user_version','2007092500'),(302,'adminblocks_initialised','1'),(303,'siteidentifier','4WsVPRIZawK8xrZlgdiJBhiRQJNXSwFzlocalhost'),(304,'rolesactive','1'),(305,'guestroleid','6'),(306,'creatornewroleid','3'),(307,'notloggedinroleid','6'),(308,'defaultuserroleid','7'),(309,'defaultcourseroleid','5'),(310,'nonmetacoursesyncroleids',''),(311,'defaultrequestcategory','1'),(312,'gradebookroles','5'),(313,'assignment_maxbytes','1048576'),(314,'assignment_itemstocount','1'),(315,'assignment_showrecentsubmissions','1'),(316,'chat_method','header_js'),(317,'chat_refresh_userlist','10'),(318,'chat_old_ping','35'),(319,'chat_refresh_room','5'),(320,'chat_normal_updatemode','jsupdate'),(321,'chat_serverhost','localhost'),(322,'chat_serverip','127.0.0.1'),(323,'chat_serverport','9111'),(324,'chat_servermax','100'),(325,'data_enablerssfeeds','0'),(326,'forum_displaymode','3'),(327,'forum_replytouser','1'),(328,'forum_shortpost','300'),(329,'forum_longpost','600'),(330,'forum_manydiscussions','100'),(331,'forum_maxbytes','512000'),(332,'forum_trackreadposts','1'),(333,'forum_oldpostdays','14'),(334,'forum_usermarksread','0'),(335,'forum_cleanreadtime','2'),(336,'forum_enablerssfeeds','0'),(337,'forum_enabletimedposts','0'),(338,'forum_logblocked','1'),(339,'glossary_entbypage','10'),(340,'glossary_dupentries','0'),(341,'glossary_allowcomments','0'),(342,'glossary_linkbydefault','1'),(343,'glossary_defaultapproval','1'),(344,'glossary_enablerssfeeds','0'),(345,'glossary_linkentries','0'),(346,'glossary_casesensitive','0'),(347,'glossary_fullmatch','0'),(348,'lams_serverurl',''),(349,'lams_serverid',''),(350,'lams_serverkey',''),(351,'resource_framesize','130'),(352,'resource_websearch','http://google.com/'),(353,'resource_defaulturl','http://'),(354,'resource_secretphrase','zbUfJQcOR4tEzzNvna70'),(355,'resource_allowlocalfiles','0'),(356,'resource_popup',''),(357,'resource_popupresizable','checked'),(358,'resource_popupscrollbars','checked'),(359,'resource_popupdirectories','checked'),(360,'resource_popuplocation','checked'),(361,'resource_popupmenubar','checked'),(362,'resource_popuptoolbar','checked'),(363,'resource_popupstatus','checked'),(364,'resource_popupwidth','620'),(365,'resource_popupheight','450'),(366,'resource_autofilerename','1'),(367,'resource_blockdeletingfile','1'),(368,'scorm_framewidth','100%'),(369,'scorm_frameheight','500'),(370,'block_course_list_adminview','all'),(371,'block_course_list_hideallcourseslink','0'),(372,'block_online_users_timetosee','5'),(373,'defaultallowedmodules',''),(374,'coursemanager','3'),(375,'frontpage','1'),(376,'frontpageloggedin','1'),(377,'coursesperpage','20'),(378,'allowvisiblecoursesinhiddencategories','0'),(379,'defaultfrontpageroleid','0');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_plugins`
--

DROP TABLE IF EXISTS `config_plugins`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `config_plugins` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `plugin` varchar(100) NOT NULL default 'core',
  `name` varchar(100) NOT NULL default '',
  `value` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `confplug_plunam_uix` (`plugin`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Moodle modules and plugins configuration variables';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `config_plugins`
--

LOCK TABLES `config_plugins` WRITE;
/*!40000 ALTER TABLE `config_plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `config_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `context`
--

DROP TABLE IF EXISTS `context`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `context` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `contextlevel` bigint(10) unsigned NOT NULL default '0',
  `instanceid` bigint(10) unsigned NOT NULL default '0',
  `path` varchar(255) default NULL,
  `depth` tinyint(2) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `cont_conins_uix` (`contextlevel`,`instanceid`),
  KEY `cont_ins_ix` (`instanceid`),
  KEY `cont_pat_ix` (`path`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='one of these must be set';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `context`
--

LOCK TABLES `context` WRITE;
/*!40000 ALTER TABLE `context` DISABLE KEYS */;
INSERT INTO `context` VALUES (1,10,0,'/1',1),(2,50,1,'/1/2',2),(3,40,1,'/1/3',2),(4,80,1,'/1/2/4',3),(5,80,2,'/1/2/5',3),(6,80,3,'/1/2/6',3),(7,80,4,'/1/2/7',3),(8,80,5,'/1/8',2),(9,80,6,'/1/9',2);
/*!40000 ALTER TABLE `context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `context_temp`
--

DROP TABLE IF EXISTS `context_temp`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `context_temp` (
  `id` bigint(10) unsigned NOT NULL,
  `path` varchar(255) NOT NULL default '',
  `depth` tinyint(2) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Used by build_context_path() in upgrade and cron to keep con';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `context_temp`
--

LOCK TABLES `context_temp` WRITE;
/*!40000 ALTER TABLE `context_temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `context_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `course` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `category` bigint(10) unsigned NOT NULL default '0',
  `sortorder` bigint(10) unsigned NOT NULL default '0',
  `password` varchar(50) NOT NULL default '',
  `fullname` varchar(254) NOT NULL default '',
  `shortname` varchar(100) NOT NULL default '',
  `idnumber` varchar(100) NOT NULL default '',
  `summary` text,
  `format` varchar(10) NOT NULL default 'topics',
  `showgrades` tinyint(2) unsigned NOT NULL default '1',
  `modinfo` longtext,
  `newsitems` mediumint(5) unsigned NOT NULL default '1',
  `teacher` varchar(100) NOT NULL default 'Teacher',
  `teachers` varchar(100) NOT NULL default 'Teachers',
  `student` varchar(100) NOT NULL default 'Student',
  `students` varchar(100) NOT NULL default 'Students',
  `guest` tinyint(2) unsigned NOT NULL default '0',
  `startdate` bigint(10) unsigned NOT NULL default '0',
  `enrolperiod` bigint(10) unsigned NOT NULL default '0',
  `numsections` mediumint(5) unsigned NOT NULL default '1',
  `marker` bigint(10) unsigned NOT NULL default '0',
  `maxbytes` bigint(10) unsigned NOT NULL default '0',
  `showreports` smallint(4) unsigned NOT NULL default '0',
  `visible` tinyint(1) unsigned NOT NULL default '1',
  `hiddensections` tinyint(2) unsigned NOT NULL default '0',
  `groupmode` smallint(4) unsigned NOT NULL default '0',
  `groupmodeforce` smallint(4) unsigned NOT NULL default '0',
  `defaultgroupingid` bigint(10) unsigned NOT NULL default '0',
  `lang` varchar(30) NOT NULL default '',
  `theme` varchar(50) NOT NULL default '',
  `cost` varchar(10) NOT NULL default '',
  `currency` varchar(3) NOT NULL default 'USD',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `metacourse` tinyint(1) unsigned NOT NULL default '0',
  `requested` tinyint(1) unsigned NOT NULL default '0',
  `restrictmodules` tinyint(1) unsigned NOT NULL default '0',
  `expirynotify` tinyint(1) unsigned NOT NULL default '0',
  `expirythreshold` bigint(10) unsigned NOT NULL default '0',
  `notifystudents` tinyint(1) unsigned NOT NULL default '0',
  `enrollable` tinyint(1) unsigned NOT NULL default '1',
  `enrolstartdate` bigint(10) unsigned NOT NULL default '0',
  `enrolenddate` bigint(10) unsigned NOT NULL default '0',
  `enrol` varchar(20) NOT NULL default '',
  `defaultrole` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cour_cat_ix` (`category`),
  KEY `cour_idn_ix` (`idnumber`),
  KEY `cour_sho_ix` (`shortname`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Central course table';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,0,0,'','Switched On','so-class2','','','site',1,'a:0:{}',3,'Teacher','Teachers','Student','Students',0,0,0,0,0,0,0,1,0,0,0,0,'','','','USD',0,1253738300,0,0,0,0,0,0,1,0,0,'',0);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_allowed_modules`
--

DROP TABLE IF EXISTS `course_allowed_modules`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `course_allowed_modules` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `module` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `courallomodu_cou_ix` (`course`),
  KEY `courallomodu_mod_ix` (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='allowed modules foreach course';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `course_allowed_modules`
--

LOCK TABLES `course_allowed_modules` WRITE;
/*!40000 ALTER TABLE `course_allowed_modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_allowed_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_categories`
--

DROP TABLE IF EXISTS `course_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `course_categories` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` text,
  `parent` bigint(10) unsigned NOT NULL default '0',
  `sortorder` bigint(10) unsigned NOT NULL default '0',
  `coursecount` bigint(10) unsigned NOT NULL default '0',
  `visible` tinyint(1) NOT NULL default '1',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `depth` bigint(10) unsigned NOT NULL default '0',
  `path` varchar(255) NOT NULL default '',
  `theme` varchar(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `courcate_par_ix` (`parent`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Course categories';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `course_categories`
--

LOCK TABLES `course_categories` WRITE;
/*!40000 ALTER TABLE `course_categories` DISABLE KEYS */;
INSERT INTO `course_categories` VALUES (1,'Miscellaneous',NULL,0,0,0,1,0,1,'',NULL);
/*!40000 ALTER TABLE `course_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_display`
--

DROP TABLE IF EXISTS `course_display`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `course_display` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `display` bigint(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `courdisp_couuse_ix` (`course`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores info about how to display the course';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `course_display`
--

LOCK TABLES `course_display` WRITE;
/*!40000 ALTER TABLE `course_display` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_display` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_meta`
--

DROP TABLE IF EXISTS `course_meta`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `course_meta` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `parent_course` bigint(10) unsigned NOT NULL default '0',
  `child_course` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `courmeta_par_ix` (`parent_course`),
  KEY `courmeta_chi_ix` (`child_course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to store meta-courses relations';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `course_meta`
--

LOCK TABLES `course_meta` WRITE;
/*!40000 ALTER TABLE `course_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_modules`
--

DROP TABLE IF EXISTS `course_modules`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `course_modules` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `module` bigint(10) unsigned NOT NULL default '0',
  `instance` bigint(10) unsigned NOT NULL default '0',
  `section` bigint(10) unsigned NOT NULL default '0',
  `idnumber` varchar(100) default NULL,
  `added` bigint(10) unsigned NOT NULL default '0',
  `score` smallint(4) NOT NULL default '0',
  `indent` mediumint(5) unsigned NOT NULL default '0',
  `visible` tinyint(1) NOT NULL default '1',
  `visibleold` tinyint(1) NOT NULL default '1',
  `groupmode` smallint(4) NOT NULL default '0',
  `groupingid` bigint(10) unsigned NOT NULL default '0',
  `groupmembersonly` smallint(4) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `courmodu_vis_ix` (`visible`),
  KEY `courmodu_cou_ix` (`course`),
  KEY `courmodu_mod_ix` (`module`),
  KEY `courmodu_ins_ix` (`instance`),
  KEY `courmodu_idncou_ix` (`idnumber`,`course`),
  KEY `courmodu_gro_ix` (`groupingid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='course_modules table retrofitted from MySQL';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `course_modules`
--

LOCK TABLES `course_modules` WRITE;
/*!40000 ALTER TABLE `course_modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_request`
--

DROP TABLE IF EXISTS `course_request`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `course_request` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `fullname` varchar(254) NOT NULL default '',
  `shortname` varchar(15) NOT NULL default '',
  `summary` text NOT NULL,
  `reason` text NOT NULL,
  `requester` bigint(10) unsigned NOT NULL default '0',
  `password` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `courrequ_sho_ix` (`shortname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='course requests';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `course_request`
--

LOCK TABLES `course_request` WRITE;
/*!40000 ALTER TABLE `course_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_sections`
--

DROP TABLE IF EXISTS `course_sections`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `course_sections` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `section` bigint(10) unsigned NOT NULL default '0',
  `summary` text,
  `sequence` text,
  `visible` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `coursect_cousec_ix` (`course`,`section`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to define the sections for each course';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `course_sections`
--

LOCK TABLES `course_sections` WRITE;
/*!40000 ALTER TABLE `course_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data`
--

DROP TABLE IF EXISTS `data`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `data` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `intro` text NOT NULL,
  `comments` smallint(4) unsigned NOT NULL default '0',
  `timeavailablefrom` bigint(10) unsigned NOT NULL default '0',
  `timeavailableto` bigint(10) unsigned NOT NULL default '0',
  `timeviewfrom` bigint(10) unsigned NOT NULL default '0',
  `timeviewto` bigint(10) unsigned NOT NULL default '0',
  `requiredentries` int(8) unsigned NOT NULL default '0',
  `requiredentriestoview` int(8) unsigned NOT NULL default '0',
  `maxentries` int(8) unsigned NOT NULL default '0',
  `rssarticles` smallint(4) unsigned NOT NULL default '0',
  `singletemplate` text,
  `listtemplate` text,
  `listtemplateheader` text,
  `listtemplatefooter` text,
  `addtemplate` text,
  `rsstemplate` text,
  `rsstitletemplate` text,
  `csstemplate` text,
  `jstemplate` text,
  `asearchtemplate` text,
  `approval` smallint(4) unsigned NOT NULL default '0',
  `scale` bigint(10) NOT NULL default '0',
  `assessed` bigint(10) unsigned NOT NULL default '0',
  `defaultsort` bigint(10) unsigned NOT NULL default '0',
  `defaultsortdir` smallint(4) unsigned NOT NULL default '0',
  `editany` smallint(4) unsigned NOT NULL default '0',
  `notification` bigint(10) default NULL,
  PRIMARY KEY  (`id`),
  KEY `data_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Removed ratings column';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `data`
--

LOCK TABLES `data` WRITE;
/*!40000 ALTER TABLE `data` DISABLE KEYS */;
/*!40000 ALTER TABLE `data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_comments`
--

DROP TABLE IF EXISTS `data_comments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `data_comments` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `recordid` bigint(10) unsigned NOT NULL default '0',
  `content` text NOT NULL,
  `format` tinyint(2) unsigned NOT NULL default '0',
  `created` bigint(10) unsigned NOT NULL default '0',
  `modified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `datacomm_rec_ix` (`recordid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to comment data records';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `data_comments`
--

LOCK TABLES `data_comments` WRITE;
/*!40000 ALTER TABLE `data_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_content`
--

DROP TABLE IF EXISTS `data_content`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `data_content` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `fieldid` bigint(10) unsigned NOT NULL default '0',
  `recordid` bigint(10) unsigned NOT NULL default '0',
  `content` longtext,
  `content1` longtext,
  `content2` longtext,
  `content3` longtext,
  `content4` longtext,
  PRIMARY KEY  (`id`),
  KEY `datacont_rec_ix` (`recordid`),
  KEY `datacont_fie_ix` (`fieldid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='the content introduced in each record/fields';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `data_content`
--

LOCK TABLES `data_content` WRITE;
/*!40000 ALTER TABLE `data_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_fields`
--

DROP TABLE IF EXISTS `data_fields`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `data_fields` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `dataid` bigint(10) unsigned NOT NULL default '0',
  `type` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `param1` text,
  `param2` text,
  `param3` text,
  `param4` text,
  `param5` text,
  `param6` text,
  `param7` text,
  `param8` text,
  `param9` text,
  `param10` text,
  PRIMARY KEY  (`id`),
  KEY `datafiel_typdat_ix` (`type`,`dataid`),
  KEY `datafiel_dat_ix` (`dataid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='every field available';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `data_fields`
--

LOCK TABLES `data_fields` WRITE;
/*!40000 ALTER TABLE `data_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_ratings`
--

DROP TABLE IF EXISTS `data_ratings`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `data_ratings` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `recordid` bigint(10) unsigned NOT NULL default '0',
  `rating` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `datarati_rec_ix` (`recordid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to rate data records';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `data_ratings`
--

LOCK TABLES `data_ratings` WRITE;
/*!40000 ALTER TABLE `data_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_records`
--

DROP TABLE IF EXISTS `data_records`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `data_records` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `groupid` bigint(10) unsigned NOT NULL default '0',
  `dataid` bigint(10) unsigned NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `approved` smallint(4) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `datareco_dat_ix` (`dataid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='every record introduced';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `data_records`
--

LOCK TABLES `data_records` WRITE;
/*!40000 ALTER TABLE `data_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrol_authorize`
--

DROP TABLE IF EXISTS `enrol_authorize`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `enrol_authorize` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `paymentmethod` enum('cc','echeck') NOT NULL default 'cc',
  `refundinfo` smallint(4) unsigned NOT NULL default '0',
  `ccname` varchar(255) NOT NULL default '',
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `transid` bigint(20) unsigned NOT NULL default '0',
  `status` bigint(10) unsigned NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `settletime` bigint(10) unsigned NOT NULL default '0',
  `amount` varchar(10) NOT NULL default '',
  `currency` varchar(3) NOT NULL default 'USD',
  PRIMARY KEY  (`id`),
  KEY `enroauth_cou_ix` (`courseid`),
  KEY `enroauth_use_ix` (`userid`),
  KEY `enroauth_sta_ix` (`status`),
  KEY `enroauth_tra_ix` (`transid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Holds all known information about authorize.net transactions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `enrol_authorize`
--

LOCK TABLES `enrol_authorize` WRITE;
/*!40000 ALTER TABLE `enrol_authorize` DISABLE KEYS */;
/*!40000 ALTER TABLE `enrol_authorize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrol_authorize_refunds`
--

DROP TABLE IF EXISTS `enrol_authorize_refunds`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `enrol_authorize_refunds` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `orderid` bigint(10) unsigned NOT NULL default '0',
  `status` tinyint(1) unsigned NOT NULL default '0',
  `amount` varchar(10) NOT NULL default '',
  `transid` bigint(20) unsigned default '0',
  `settletime` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `enroauthrefu_tra_ix` (`transid`),
  KEY `enroauthrefu_ord_ix` (`orderid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Authorize.net refunds';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `enrol_authorize_refunds`
--

LOCK TABLES `enrol_authorize_refunds` WRITE;
/*!40000 ALTER TABLE `enrol_authorize_refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `enrol_authorize_refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrol_paypal`
--

DROP TABLE IF EXISTS `enrol_paypal`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `enrol_paypal` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `business` varchar(255) NOT NULL default '',
  `receiver_email` varchar(255) NOT NULL default '',
  `receiver_id` varchar(255) NOT NULL default '',
  `item_name` varchar(255) NOT NULL default '',
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `memo` varchar(255) NOT NULL default '',
  `tax` varchar(255) NOT NULL default '',
  `option_name1` varchar(255) NOT NULL default '',
  `option_selection1_x` varchar(255) NOT NULL default '',
  `option_name2` varchar(255) NOT NULL default '',
  `option_selection2_x` varchar(255) NOT NULL default '',
  `payment_status` varchar(255) NOT NULL default '',
  `pending_reason` varchar(255) NOT NULL default '',
  `reason_code` varchar(30) NOT NULL default '',
  `txn_id` varchar(255) NOT NULL default '',
  `parent_txn_id` varchar(255) NOT NULL default '',
  `payment_type` varchar(30) NOT NULL default '',
  `timeupdated` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Holds all known information about PayPal transactions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `enrol_paypal`
--

LOCK TABLES `enrol_paypal` WRITE;
/*!40000 ALTER TABLE `enrol_paypal` DISABLE KEYS */;
/*!40000 ALTER TABLE `enrol_paypal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `event` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `format` smallint(4) unsigned NOT NULL default '0',
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `groupid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `repeatid` bigint(10) unsigned NOT NULL default '0',
  `modulename` varchar(20) NOT NULL default '',
  `instance` bigint(10) unsigned NOT NULL default '0',
  `eventtype` varchar(20) NOT NULL default '',
  `timestart` bigint(10) unsigned NOT NULL default '0',
  `timeduration` bigint(10) unsigned NOT NULL default '0',
  `visible` smallint(4) NOT NULL default '1',
  `uuid` varchar(36) NOT NULL default '',
  `sequence` bigint(10) unsigned NOT NULL default '1',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `even_cou_ix` (`courseid`),
  KEY `even_use_ix` (`userid`),
  KEY `even_tim_ix` (`timestart`),
  KEY `even_tim2_ix` (`timeduration`),
  KEY `even_grocouvisuse_ix` (`groupid`,`courseid`,`visible`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='For everything with a time associated to it';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events_handlers`
--

DROP TABLE IF EXISTS `events_handlers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `events_handlers` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `eventname` varchar(166) NOT NULL default '',
  `handlermodule` varchar(166) NOT NULL default '',
  `handlerfile` varchar(255) NOT NULL default '',
  `handlerfunction` mediumtext,
  `schedule` varchar(255) default NULL,
  `status` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `evenhand_evehan_uix` (`eventname`,`handlermodule`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='This table is for storing which components requests what typ';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `events_handlers`
--

LOCK TABLES `events_handlers` WRITE;
/*!40000 ALTER TABLE `events_handlers` DISABLE KEYS */;
/*!40000 ALTER TABLE `events_handlers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events_queue`
--

DROP TABLE IF EXISTS `events_queue`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `events_queue` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `eventdata` longtext NOT NULL,
  `stackdump` mediumtext,
  `userid` bigint(10) unsigned default NULL,
  `timecreated` bigint(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `evenqueu_use_ix` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='This table is for storing queued events. It stores only one ';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `events_queue`
--

LOCK TABLES `events_queue` WRITE;
/*!40000 ALTER TABLE `events_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `events_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events_queue_handlers`
--

DROP TABLE IF EXISTS `events_queue_handlers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `events_queue_handlers` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `queuedeventid` bigint(10) unsigned NOT NULL,
  `handlerid` bigint(10) unsigned NOT NULL,
  `status` bigint(10) default NULL,
  `errormessage` mediumtext,
  `timemodified` bigint(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `evenqueuhand_que_ix` (`queuedeventid`),
  KEY `evenqueuhand_han_ix` (`handlerid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='This is the list of queued handlers for processing. The even';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `events_queue_handlers`
--

LOCK TABLES `events_queue_handlers` WRITE;
/*!40000 ALTER TABLE `events_queue_handlers` DISABLE KEYS */;
/*!40000 ALTER TABLE `events_queue_handlers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum`
--

DROP TABLE IF EXISTS `forum`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `forum` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `type` enum('single','news','general','social','eachuser','teacher','qanda') NOT NULL default 'general',
  `name` varchar(255) NOT NULL default '',
  `intro` text NOT NULL,
  `assessed` bigint(10) unsigned NOT NULL default '0',
  `assesstimestart` bigint(10) unsigned NOT NULL default '0',
  `assesstimefinish` bigint(10) unsigned NOT NULL default '0',
  `scale` bigint(10) NOT NULL default '0',
  `maxbytes` bigint(10) unsigned NOT NULL default '0',
  `forcesubscribe` tinyint(1) unsigned NOT NULL default '0',
  `trackingtype` tinyint(2) unsigned NOT NULL default '1',
  `rsstype` tinyint(2) unsigned NOT NULL default '0',
  `rssarticles` tinyint(2) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `warnafter` bigint(10) unsigned NOT NULL default '0',
  `blockafter` bigint(10) unsigned NOT NULL default '0',
  `blockperiod` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `foru_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Forums contain and structure discussion';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `forum`
--

LOCK TABLES `forum` WRITE;
/*!40000 ALTER TABLE `forum` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_discussions`
--

DROP TABLE IF EXISTS `forum_discussions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `forum_discussions` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `forum` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `firstpost` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `groupid` bigint(10) NOT NULL default '-1',
  `assessed` tinyint(1) NOT NULL default '1',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `usermodified` bigint(10) unsigned NOT NULL default '0',
  `timestart` bigint(10) unsigned NOT NULL default '0',
  `timeend` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `forudisc_use_ix` (`userid`),
  KEY `forudisc_for_ix` (`forum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Forums are composed of discussions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `forum_discussions`
--

LOCK TABLES `forum_discussions` WRITE;
/*!40000 ALTER TABLE `forum_discussions` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_discussions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_posts`
--

DROP TABLE IF EXISTS `forum_posts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `forum_posts` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `discussion` bigint(10) unsigned NOT NULL default '0',
  `parent` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `created` bigint(10) unsigned NOT NULL default '0',
  `modified` bigint(10) unsigned NOT NULL default '0',
  `mailed` tinyint(2) unsigned NOT NULL default '0',
  `subject` varchar(255) NOT NULL default '',
  `message` text NOT NULL,
  `format` tinyint(2) NOT NULL default '0',
  `attachment` varchar(100) NOT NULL default '',
  `totalscore` smallint(4) NOT NULL default '0',
  `mailnow` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `forupost_use_ix` (`userid`),
  KEY `forupost_cre_ix` (`created`),
  KEY `forupost_mai_ix` (`mailed`),
  KEY `forupost_dis_ix` (`discussion`),
  KEY `forupost_par_ix` (`parent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='All posts are stored in this table';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `forum_posts`
--

LOCK TABLES `forum_posts` WRITE;
/*!40000 ALTER TABLE `forum_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_queue`
--

DROP TABLE IF EXISTS `forum_queue`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `forum_queue` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `discussionid` bigint(10) unsigned NOT NULL default '0',
  `postid` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `foruqueu_use_ix` (`userid`),
  KEY `foruqueu_dis_ix` (`discussionid`),
  KEY `foruqueu_pos_ix` (`postid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='For keeping track of posts that will be mailed in digest for';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `forum_queue`
--

LOCK TABLES `forum_queue` WRITE;
/*!40000 ALTER TABLE `forum_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_ratings`
--

DROP TABLE IF EXISTS `forum_ratings`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `forum_ratings` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `post` bigint(10) unsigned NOT NULL default '0',
  `time` bigint(10) unsigned NOT NULL default '0',
  `rating` smallint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `forurati_use_ix` (`userid`),
  KEY `forurati_pos_ix` (`post`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='forum_ratings table retrofitted from MySQL';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `forum_ratings`
--

LOCK TABLES `forum_ratings` WRITE;
/*!40000 ALTER TABLE `forum_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_read`
--

DROP TABLE IF EXISTS `forum_read`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `forum_read` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `forumid` bigint(10) unsigned NOT NULL default '0',
  `discussionid` bigint(10) unsigned NOT NULL default '0',
  `postid` bigint(10) unsigned NOT NULL default '0',
  `firstread` bigint(10) unsigned NOT NULL default '0',
  `lastread` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `foruread_usefor_ix` (`userid`,`forumid`),
  KEY `foruread_usedis_ix` (`userid`,`discussionid`),
  KEY `foruread_usepos_ix` (`userid`,`postid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Tracks each users read posts';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `forum_read`
--

LOCK TABLES `forum_read` WRITE;
/*!40000 ALTER TABLE `forum_read` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_read` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_subscriptions`
--

DROP TABLE IF EXISTS `forum_subscriptions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `forum_subscriptions` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `forum` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `forusubs_use_ix` (`userid`),
  KEY `forusubs_for_ix` (`forum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Keeps track of who is subscribed to what forum';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `forum_subscriptions`
--

LOCK TABLES `forum_subscriptions` WRITE;
/*!40000 ALTER TABLE `forum_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_track_prefs`
--

DROP TABLE IF EXISTS `forum_track_prefs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `forum_track_prefs` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `forumid` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `forutracpref_usefor_ix` (`userid`,`forumid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Tracks each users untracked forums';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `forum_track_prefs`
--

LOCK TABLES `forum_track_prefs` WRITE;
/*!40000 ALTER TABLE `forum_track_prefs` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_track_prefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glossary`
--

DROP TABLE IF EXISTS `glossary`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `glossary` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `intro` text NOT NULL,
  `allowduplicatedentries` tinyint(2) unsigned NOT NULL default '0',
  `displayformat` varchar(50) NOT NULL default 'dictionary',
  `mainglossary` tinyint(2) unsigned NOT NULL default '0',
  `showspecial` tinyint(2) unsigned NOT NULL default '1',
  `showalphabet` tinyint(2) unsigned NOT NULL default '1',
  `showall` tinyint(2) unsigned NOT NULL default '1',
  `allowcomments` tinyint(2) unsigned NOT NULL default '0',
  `allowprintview` tinyint(2) unsigned NOT NULL default '1',
  `usedynalink` tinyint(2) unsigned NOT NULL default '1',
  `defaultapproval` tinyint(2) unsigned NOT NULL default '1',
  `globalglossary` tinyint(2) unsigned NOT NULL default '0',
  `entbypage` smallint(3) unsigned NOT NULL default '10',
  `editalways` tinyint(2) unsigned NOT NULL default '0',
  `rsstype` tinyint(2) unsigned NOT NULL default '0',
  `rssarticles` tinyint(2) unsigned NOT NULL default '0',
  `assessed` bigint(10) unsigned NOT NULL default '0',
  `assesstimestart` bigint(10) unsigned NOT NULL default '0',
  `assesstimefinish` bigint(10) unsigned NOT NULL default '0',
  `scale` bigint(10) NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `glos_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='all glossaries';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `glossary`
--

LOCK TABLES `glossary` WRITE;
/*!40000 ALTER TABLE `glossary` DISABLE KEYS */;
/*!40000 ALTER TABLE `glossary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glossary_alias`
--

DROP TABLE IF EXISTS `glossary_alias`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `glossary_alias` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `entryid` bigint(10) unsigned NOT NULL default '0',
  `alias` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `glosalia_ent_ix` (`entryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='entries alias';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `glossary_alias`
--

LOCK TABLES `glossary_alias` WRITE;
/*!40000 ALTER TABLE `glossary_alias` DISABLE KEYS */;
/*!40000 ALTER TABLE `glossary_alias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glossary_categories`
--

DROP TABLE IF EXISTS `glossary_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `glossary_categories` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `glossaryid` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `usedynalink` tinyint(2) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `gloscate_glo_ix` (`glossaryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='all categories for glossary entries';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `glossary_categories`
--

LOCK TABLES `glossary_categories` WRITE;
/*!40000 ALTER TABLE `glossary_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `glossary_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glossary_comments`
--

DROP TABLE IF EXISTS `glossary_comments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `glossary_comments` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `entryid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `entrycomment` text NOT NULL,
  `format` tinyint(2) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `gloscomm_use_ix` (`userid`),
  KEY `gloscomm_ent_ix` (`entryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='comments on glossary entries';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `glossary_comments`
--

LOCK TABLES `glossary_comments` WRITE;
/*!40000 ALTER TABLE `glossary_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `glossary_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glossary_entries`
--

DROP TABLE IF EXISTS `glossary_entries`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `glossary_entries` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `glossaryid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `concept` varchar(255) NOT NULL default '',
  `definition` text NOT NULL,
  `format` tinyint(2) unsigned NOT NULL default '0',
  `attachment` varchar(100) NOT NULL default '',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `teacherentry` tinyint(2) unsigned NOT NULL default '0',
  `sourceglossaryid` bigint(10) unsigned NOT NULL default '0',
  `usedynalink` tinyint(2) unsigned NOT NULL default '1',
  `casesensitive` tinyint(2) unsigned NOT NULL default '0',
  `fullmatch` tinyint(2) unsigned NOT NULL default '1',
  `approved` tinyint(2) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `glosentr_use_ix` (`userid`),
  KEY `glosentr_con_ix` (`concept`),
  KEY `glosentr_glo_ix` (`glossaryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='all glossary entries';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `glossary_entries`
--

LOCK TABLES `glossary_entries` WRITE;
/*!40000 ALTER TABLE `glossary_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `glossary_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glossary_entries_categories`
--

DROP TABLE IF EXISTS `glossary_entries_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `glossary_entries_categories` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `categoryid` bigint(10) unsigned NOT NULL default '0',
  `entryid` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `glosentrcate_cat_ix` (`categoryid`),
  KEY `glosentrcate_ent_ix` (`entryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='categories of each glossary entry';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `glossary_entries_categories`
--

LOCK TABLES `glossary_entries_categories` WRITE;
/*!40000 ALTER TABLE `glossary_entries_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `glossary_entries_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glossary_formats`
--

DROP TABLE IF EXISTS `glossary_formats`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `glossary_formats` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `popupformatname` varchar(50) NOT NULL default '',
  `visible` tinyint(2) unsigned NOT NULL default '1',
  `showgroup` tinyint(2) unsigned NOT NULL default '1',
  `defaultmode` varchar(50) NOT NULL default '',
  `defaulthook` varchar(50) NOT NULL default '',
  `sortkey` varchar(50) NOT NULL default '',
  `sortorder` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='Setting of the display formats';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `glossary_formats`
--

LOCK TABLES `glossary_formats` WRITE;
/*!40000 ALTER TABLE `glossary_formats` DISABLE KEYS */;
INSERT INTO `glossary_formats` VALUES (1,'continuous','continuous',1,1,'','','',''),(2,'dictionary','dictionary',1,1,'','','',''),(3,'encyclopedia','encyclopedia',1,1,'','','',''),(4,'entrylist','entrylist',1,1,'','','',''),(5,'faq','faq',1,1,'','','',''),(6,'fullwithauthor','fullwithauthor',1,1,'','','',''),(7,'fullwithoutauthor','fullwithoutauthor',1,1,'','','','');
/*!40000 ALTER TABLE `glossary_formats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `glossary_ratings`
--

DROP TABLE IF EXISTS `glossary_ratings`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `glossary_ratings` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `entryid` bigint(10) unsigned NOT NULL default '0',
  `time` bigint(10) unsigned NOT NULL default '0',
  `rating` smallint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `glosrati_use_ix` (`userid`),
  KEY `glosrati_ent_ix` (`entryid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Contains user ratings for entries';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `glossary_ratings`
--

LOCK TABLES `glossary_ratings` WRITE;
/*!40000 ALTER TABLE `glossary_ratings` DISABLE KEYS */;
/*!40000 ALTER TABLE `glossary_ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_categories`
--

DROP TABLE IF EXISTS `grade_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_categories` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL,
  `parent` bigint(10) unsigned default NULL,
  `depth` bigint(10) unsigned NOT NULL default '0',
  `path` varchar(255) default NULL,
  `fullname` varchar(255) NOT NULL default '',
  `aggregation` bigint(10) NOT NULL default '0',
  `keephigh` bigint(10) NOT NULL default '0',
  `droplow` bigint(10) NOT NULL default '0',
  `aggregateonlygraded` tinyint(1) unsigned NOT NULL default '0',
  `aggregateoutcomes` tinyint(1) unsigned NOT NULL default '0',
  `aggregatesubcats` tinyint(1) unsigned NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `gradcate_cou_ix` (`courseid`),
  KEY `gradcate_par_ix` (`parent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='This table keeps information about categories, used for grou';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_categories`
--

LOCK TABLES `grade_categories` WRITE;
/*!40000 ALTER TABLE `grade_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_categories_history`
--

DROP TABLE IF EXISTS `grade_categories_history`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_categories_history` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `action` bigint(10) unsigned NOT NULL default '0',
  `oldid` bigint(10) unsigned NOT NULL,
  `source` varchar(255) default NULL,
  `timemodified` bigint(10) unsigned default NULL,
  `loggeduser` bigint(10) unsigned default NULL,
  `courseid` bigint(10) unsigned NOT NULL,
  `parent` bigint(10) unsigned default NULL,
  `depth` bigint(10) unsigned NOT NULL default '0',
  `path` varchar(255) default NULL,
  `fullname` varchar(255) NOT NULL default '',
  `aggregation` bigint(10) NOT NULL default '0',
  `keephigh` bigint(10) NOT NULL default '0',
  `droplow` bigint(10) NOT NULL default '0',
  `aggregateonlygraded` tinyint(1) unsigned NOT NULL default '0',
  `aggregateoutcomes` tinyint(1) unsigned NOT NULL default '0',
  `aggregatesubcats` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `gradcatehist_act_ix` (`action`),
  KEY `gradcatehist_old_ix` (`oldid`),
  KEY `gradcatehist_cou_ix` (`courseid`),
  KEY `gradcatehist_par_ix` (`parent`),
  KEY `gradcatehist_log_ix` (`loggeduser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='History of grade_categories';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_categories_history`
--

LOCK TABLES `grade_categories_history` WRITE;
/*!40000 ALTER TABLE `grade_categories_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_categories_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_grades`
--

DROP TABLE IF EXISTS `grade_grades`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_grades` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `itemid` bigint(10) unsigned NOT NULL,
  `userid` bigint(10) unsigned NOT NULL,
  `rawgrade` decimal(10,5) default NULL,
  `rawgrademax` decimal(10,5) NOT NULL default '100.00000',
  `rawgrademin` decimal(10,5) NOT NULL default '0.00000',
  `rawscaleid` bigint(10) unsigned default NULL,
  `usermodified` bigint(10) unsigned default NULL,
  `finalgrade` decimal(10,5) default NULL,
  `hidden` bigint(10) unsigned NOT NULL default '0',
  `locked` bigint(10) unsigned NOT NULL default '0',
  `locktime` bigint(10) unsigned NOT NULL default '0',
  `exported` bigint(10) unsigned NOT NULL default '0',
  `overridden` bigint(10) unsigned NOT NULL default '0',
  `excluded` bigint(10) unsigned NOT NULL default '0',
  `feedback` mediumtext,
  `feedbackformat` bigint(10) unsigned NOT NULL default '0',
  `information` mediumtext,
  `informationformat` bigint(10) unsigned NOT NULL default '0',
  `timecreated` bigint(10) unsigned default NULL,
  `timemodified` bigint(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `gradgrad_useite_uix` (`userid`,`itemid`),
  KEY `gradgrad_locloc_ix` (`locked`,`locktime`),
  KEY `gradgrad_ite_ix` (`itemid`),
  KEY `gradgrad_use_ix` (`userid`),
  KEY `gradgrad_raw_ix` (`rawscaleid`),
  KEY `gradgrad_use2_ix` (`usermodified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='grade_grades  This table keeps individual grades for each us';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_grades`
--

LOCK TABLES `grade_grades` WRITE;
/*!40000 ALTER TABLE `grade_grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_grades_history`
--

DROP TABLE IF EXISTS `grade_grades_history`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_grades_history` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `action` bigint(10) unsigned NOT NULL default '0',
  `oldid` bigint(10) unsigned NOT NULL,
  `source` varchar(255) default NULL,
  `timemodified` bigint(10) unsigned default NULL,
  `loggeduser` bigint(10) unsigned default NULL,
  `itemid` bigint(10) unsigned NOT NULL,
  `userid` bigint(10) unsigned NOT NULL,
  `rawgrade` decimal(10,5) default NULL,
  `rawgrademax` decimal(10,5) NOT NULL default '100.00000',
  `rawgrademin` decimal(10,5) NOT NULL default '0.00000',
  `rawscaleid` bigint(10) unsigned default NULL,
  `usermodified` bigint(10) unsigned default NULL,
  `finalgrade` decimal(10,5) default NULL,
  `hidden` bigint(10) unsigned NOT NULL default '0',
  `locked` bigint(10) unsigned NOT NULL default '0',
  `locktime` bigint(10) unsigned NOT NULL default '0',
  `exported` bigint(10) unsigned NOT NULL default '0',
  `overridden` bigint(10) unsigned NOT NULL default '0',
  `excluded` bigint(10) unsigned NOT NULL default '0',
  `feedback` mediumtext,
  `feedbackformat` bigint(10) unsigned NOT NULL default '0',
  `information` mediumtext,
  `informationformat` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `gradgradhist_act_ix` (`action`),
  KEY `gradgradhist_old_ix` (`oldid`),
  KEY `gradgradhist_ite_ix` (`itemid`),
  KEY `gradgradhist_use_ix` (`userid`),
  KEY `gradgradhist_raw_ix` (`rawscaleid`),
  KEY `gradgradhist_use2_ix` (`usermodified`),
  KEY `gradgradhist_log_ix` (`loggeduser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='History table';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_grades_history`
--

LOCK TABLES `grade_grades_history` WRITE;
/*!40000 ALTER TABLE `grade_grades_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_grades_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_import_newitem`
--

DROP TABLE IF EXISTS `grade_import_newitem`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_import_newitem` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `itemname` varchar(255) NOT NULL default '',
  `importcode` bigint(10) unsigned NOT NULL,
  `importer` bigint(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `gradimponewi_imp_ix` (`importer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='temporary table for storing new grade_item names from grade ';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_import_newitem`
--

LOCK TABLES `grade_import_newitem` WRITE;
/*!40000 ALTER TABLE `grade_import_newitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_import_newitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_import_values`
--

DROP TABLE IF EXISTS `grade_import_values`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_import_values` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `itemid` bigint(10) unsigned default NULL,
  `newgradeitem` bigint(10) unsigned default NULL,
  `userid` bigint(10) unsigned NOT NULL,
  `finalgrade` decimal(10,5) default NULL,
  `feedback` mediumtext,
  `importcode` bigint(10) unsigned NOT NULL,
  `importer` bigint(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  KEY `gradimpovalu_ite_ix` (`itemid`),
  KEY `gradimpovalu_new_ix` (`newgradeitem`),
  KEY `gradimpovalu_imp_ix` (`importer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Temporary table for importing grades';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_import_values`
--

LOCK TABLES `grade_import_values` WRITE;
/*!40000 ALTER TABLE `grade_import_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_import_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_items`
--

DROP TABLE IF EXISTS `grade_items`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_items` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned default NULL,
  `categoryid` bigint(10) unsigned default NULL,
  `itemname` varchar(255) default NULL,
  `itemtype` varchar(30) NOT NULL default '',
  `itemmodule` varchar(30) default NULL,
  `iteminstance` bigint(10) unsigned default NULL,
  `itemnumber` bigint(10) unsigned default NULL,
  `iteminfo` mediumtext,
  `idnumber` varchar(255) default NULL,
  `calculation` mediumtext,
  `gradetype` smallint(4) NOT NULL default '1',
  `grademax` decimal(10,5) NOT NULL default '100.00000',
  `grademin` decimal(10,5) NOT NULL default '0.00000',
  `scaleid` bigint(10) unsigned default NULL,
  `outcomeid` bigint(10) unsigned default NULL,
  `gradepass` decimal(10,5) NOT NULL default '0.00000',
  `multfactor` decimal(10,5) NOT NULL default '1.00000',
  `plusfactor` decimal(10,5) NOT NULL default '0.00000',
  `aggregationcoef` decimal(10,5) NOT NULL default '0.00000',
  `sortorder` bigint(10) NOT NULL default '0',
  `display` bigint(10) NOT NULL default '0',
  `decimals` tinyint(1) unsigned default NULL,
  `hidden` bigint(10) NOT NULL default '0',
  `locked` bigint(10) NOT NULL default '0',
  `locktime` bigint(10) unsigned NOT NULL default '0',
  `needsupdate` bigint(10) NOT NULL default '0',
  `timecreated` bigint(10) unsigned default NULL,
  `timemodified` bigint(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  KEY `graditem_locloc_ix` (`locked`,`locktime`),
  KEY `graditem_itenee_ix` (`itemtype`,`needsupdate`),
  KEY `graditem_gra_ix` (`gradetype`),
  KEY `graditem_idncou_ix` (`idnumber`,`courseid`),
  KEY `graditem_cou_ix` (`courseid`),
  KEY `graditem_cat_ix` (`categoryid`),
  KEY `graditem_sca_ix` (`scaleid`),
  KEY `graditem_out_ix` (`outcomeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='This table keeps information about gradeable items (ie colum';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_items`
--

LOCK TABLES `grade_items` WRITE;
/*!40000 ALTER TABLE `grade_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_items_history`
--

DROP TABLE IF EXISTS `grade_items_history`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_items_history` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `action` bigint(10) unsigned NOT NULL default '0',
  `oldid` bigint(10) unsigned NOT NULL,
  `source` varchar(255) default NULL,
  `timemodified` bigint(10) unsigned default NULL,
  `loggeduser` bigint(10) unsigned default NULL,
  `courseid` bigint(10) unsigned default NULL,
  `categoryid` bigint(10) unsigned default NULL,
  `itemname` varchar(255) default NULL,
  `itemtype` varchar(30) NOT NULL default '',
  `itemmodule` varchar(30) default NULL,
  `iteminstance` bigint(10) unsigned default NULL,
  `itemnumber` bigint(10) unsigned default NULL,
  `iteminfo` mediumtext,
  `idnumber` varchar(255) default NULL,
  `calculation` mediumtext,
  `gradetype` smallint(4) NOT NULL default '1',
  `grademax` decimal(10,5) NOT NULL default '100.00000',
  `grademin` decimal(10,5) NOT NULL default '0.00000',
  `scaleid` bigint(10) unsigned default NULL,
  `outcomeid` bigint(10) unsigned default NULL,
  `gradepass` decimal(10,5) NOT NULL default '0.00000',
  `multfactor` decimal(10,5) NOT NULL default '1.00000',
  `plusfactor` decimal(10,5) NOT NULL default '0.00000',
  `aggregationcoef` decimal(10,5) NOT NULL default '0.00000',
  `sortorder` bigint(10) NOT NULL default '0',
  `hidden` bigint(10) NOT NULL default '0',
  `locked` bigint(10) NOT NULL default '0',
  `locktime` bigint(10) unsigned NOT NULL default '0',
  `needsupdate` bigint(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `graditemhist_act_ix` (`action`),
  KEY `graditemhist_old_ix` (`oldid`),
  KEY `graditemhist_cou_ix` (`courseid`),
  KEY `graditemhist_cat_ix` (`categoryid`),
  KEY `graditemhist_sca_ix` (`scaleid`),
  KEY `graditemhist_out_ix` (`outcomeid`),
  KEY `graditemhist_log_ix` (`loggeduser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='History of grade_items';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_items_history`
--

LOCK TABLES `grade_items_history` WRITE;
/*!40000 ALTER TABLE `grade_items_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_items_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_letters`
--

DROP TABLE IF EXISTS `grade_letters`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_letters` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `contextid` bigint(10) unsigned NOT NULL,
  `lowerboundary` decimal(10,5) NOT NULL,
  `letter` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `gradlett_conlow_ix` (`contextid`,`lowerboundary`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Repository for grade letters, for courses and other moodle e';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_letters`
--

LOCK TABLES `grade_letters` WRITE;
/*!40000 ALTER TABLE `grade_letters` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_letters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_outcomes`
--

DROP TABLE IF EXISTS `grade_outcomes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_outcomes` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned default NULL,
  `shortname` varchar(255) NOT NULL default '',
  `fullname` text NOT NULL,
  `scaleid` bigint(10) unsigned default NULL,
  `description` text,
  `timecreated` bigint(10) unsigned default NULL,
  `timemodified` bigint(10) unsigned default NULL,
  `usermodified` bigint(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `gradoutc_cousho_uix` (`courseid`,`shortname`),
  KEY `gradoutc_cou_ix` (`courseid`),
  KEY `gradoutc_sca_ix` (`scaleid`),
  KEY `gradoutc_use_ix` (`usermodified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='This table describes the outcomes used in the system. An out';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_outcomes`
--

LOCK TABLES `grade_outcomes` WRITE;
/*!40000 ALTER TABLE `grade_outcomes` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_outcomes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_outcomes_courses`
--

DROP TABLE IF EXISTS `grade_outcomes_courses`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_outcomes_courses` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL,
  `outcomeid` bigint(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `gradoutccour_couout_uix` (`courseid`,`outcomeid`),
  KEY `gradoutccour_cou_ix` (`courseid`),
  KEY `gradoutccour_out_ix` (`outcomeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='stores what outcomes are used in what courses.';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_outcomes_courses`
--

LOCK TABLES `grade_outcomes_courses` WRITE;
/*!40000 ALTER TABLE `grade_outcomes_courses` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_outcomes_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_outcomes_history`
--

DROP TABLE IF EXISTS `grade_outcomes_history`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_outcomes_history` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `action` bigint(10) unsigned NOT NULL default '0',
  `oldid` bigint(10) unsigned NOT NULL,
  `source` varchar(255) default NULL,
  `timemodified` bigint(10) unsigned default NULL,
  `loggeduser` bigint(10) unsigned default NULL,
  `courseid` bigint(10) unsigned default NULL,
  `shortname` varchar(255) NOT NULL default '',
  `fullname` text NOT NULL,
  `scaleid` bigint(10) unsigned default NULL,
  `description` text,
  PRIMARY KEY  (`id`),
  KEY `gradoutchist_act_ix` (`action`),
  KEY `gradoutchist_old_ix` (`oldid`),
  KEY `gradoutchist_cou_ix` (`courseid`),
  KEY `gradoutchist_sca_ix` (`scaleid`),
  KEY `gradoutchist_log_ix` (`loggeduser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='History table';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_outcomes_history`
--

LOCK TABLES `grade_outcomes_history` WRITE;
/*!40000 ALTER TABLE `grade_outcomes_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_outcomes_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grade_settings`
--

DROP TABLE IF EXISTS `grade_settings`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `grade_settings` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL default '',
  `value` text,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `gradsett_counam_uix` (`courseid`,`name`),
  KEY `gradsett_cou_ix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='gradebook settings';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `grade_settings`
--

LOCK TABLES `grade_settings` WRITE;
/*!40000 ALTER TABLE `grade_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `grade_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupings`
--

DROP TABLE IF EXISTS `groupings`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `groupings` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `description` text,
  `configdata` text,
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `grou_cou2_ix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='A grouping is a collection of groups. WAS: groups_groupings';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `groupings`
--

LOCK TABLES `groupings` WRITE;
/*!40000 ALTER TABLE `groupings` DISABLE KEYS */;
/*!40000 ALTER TABLE `groupings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupings_groups`
--

DROP TABLE IF EXISTS `groupings_groups`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `groupings_groups` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `groupingid` bigint(10) unsigned NOT NULL default '0',
  `groupid` bigint(10) unsigned NOT NULL default '0',
  `timeadded` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `grougrou_gro_ix` (`groupingid`),
  KEY `grougrou_gro2_ix` (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Link a grouping to a group (note, groups can be in multiple ';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `groupings_groups`
--

LOCK TABLES `groupings_groups` WRITE;
/*!40000 ALTER TABLE `groupings_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groupings_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `groups` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL,
  `name` varchar(254) NOT NULL default '',
  `description` text,
  `enrolmentkey` varchar(50) default NULL,
  `picture` bigint(10) unsigned NOT NULL default '0',
  `hidepicture` tinyint(1) unsigned NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `grou_cou_ix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Each record represents a group.';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups_members`
--

DROP TABLE IF EXISTS `groups_members`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `groups_members` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `groupid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `timeadded` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `groumemb_gro_ix` (`groupid`),
  KEY `groumemb_use_ix` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Link a user to a group.';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `groups_members`
--

LOCK TABLES `groups_members` WRITE;
/*!40000 ALTER TABLE `groups_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotpot`
--

DROP TABLE IF EXISTS `hotpot`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `hotpot` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `summary` text NOT NULL,
  `timeopen` bigint(10) unsigned NOT NULL default '0',
  `timeclose` bigint(10) unsigned NOT NULL default '0',
  `location` smallint(4) unsigned NOT NULL default '0',
  `reference` varchar(255) NOT NULL default '',
  `outputformat` smallint(4) unsigned NOT NULL default '1',
  `navigation` smallint(4) unsigned NOT NULL default '1',
  `studentfeedback` smallint(4) unsigned NOT NULL default '0',
  `studentfeedbackurl` varchar(255) NOT NULL default '',
  `forceplugins` smallint(4) unsigned NOT NULL default '0',
  `shownextquiz` smallint(4) unsigned NOT NULL default '0',
  `review` smallint(4) NOT NULL default '0',
  `grade` bigint(10) NOT NULL default '0',
  `grademethod` smallint(4) NOT NULL default '1',
  `attempts` mediumint(6) NOT NULL default '0',
  `password` varchar(255) NOT NULL default '',
  `subnet` varchar(255) NOT NULL default '',
  `clickreporting` smallint(4) unsigned NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='details about Hot Potatoes quizzes';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `hotpot`
--

LOCK TABLES `hotpot` WRITE;
/*!40000 ALTER TABLE `hotpot` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotpot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotpot_attempts`
--

DROP TABLE IF EXISTS `hotpot_attempts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `hotpot_attempts` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `hotpot` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `starttime` bigint(10) unsigned NOT NULL default '0',
  `endtime` bigint(10) unsigned NOT NULL default '0',
  `score` mediumint(6) unsigned NOT NULL default '0',
  `penalties` mediumint(6) unsigned NOT NULL default '0',
  `attempt` mediumint(6) unsigned NOT NULL default '0',
  `timestart` bigint(10) unsigned NOT NULL default '0',
  `timefinish` bigint(10) unsigned NOT NULL default '0',
  `status` smallint(4) unsigned NOT NULL default '1',
  `clickreportid` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `hotpatte_use_ix` (`userid`),
  KEY `hotpatte_hot_ix` (`hotpot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='details about Hot Potatoes quiz attempts';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `hotpot_attempts`
--

LOCK TABLES `hotpot_attempts` WRITE;
/*!40000 ALTER TABLE `hotpot_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotpot_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotpot_details`
--

DROP TABLE IF EXISTS `hotpot_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `hotpot_details` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `attempt` bigint(10) unsigned NOT NULL default '0',
  `details` text,
  PRIMARY KEY  (`id`),
  KEY `hotpdeta_att_ix` (`attempt`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='raw details (as XML) of Hot Potatoes quiz attempts';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `hotpot_details`
--

LOCK TABLES `hotpot_details` WRITE;
/*!40000 ALTER TABLE `hotpot_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotpot_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotpot_questions`
--

DROP TABLE IF EXISTS `hotpot_questions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `hotpot_questions` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` text NOT NULL,
  `type` smallint(4) unsigned NOT NULL default '0',
  `text` bigint(10) unsigned NOT NULL default '0',
  `hotpot` bigint(10) unsigned NOT NULL default '0',
  `md5key` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `hotpques_md5_ix` (`md5key`),
  KEY `hotpques_hot_ix` (`hotpot`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='details about questions in Hot Potatoes quiz attempts';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `hotpot_questions`
--

LOCK TABLES `hotpot_questions` WRITE;
/*!40000 ALTER TABLE `hotpot_questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotpot_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotpot_responses`
--

DROP TABLE IF EXISTS `hotpot_responses`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `hotpot_responses` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `attempt` bigint(10) unsigned NOT NULL default '0',
  `question` bigint(10) unsigned NOT NULL default '0',
  `score` mediumint(6) NOT NULL default '0',
  `weighting` mediumint(6) NOT NULL default '0',
  `correct` varchar(255) NOT NULL default '',
  `wrong` varchar(255) NOT NULL default '',
  `ignored` varchar(255) NOT NULL default '',
  `hints` mediumint(6) unsigned NOT NULL default '0',
  `clues` mediumint(6) unsigned NOT NULL default '0',
  `checks` mediumint(6) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `hotpresp_att_ix` (`attempt`),
  KEY `hotpresp_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='details about responses in Hot Potatoes quiz attempts';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `hotpot_responses`
--

LOCK TABLES `hotpot_responses` WRITE;
/*!40000 ALTER TABLE `hotpot_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotpot_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotpot_strings`
--

DROP TABLE IF EXISTS `hotpot_strings`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `hotpot_strings` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `string` text NOT NULL,
  `md5key` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `hotpstri_md5_ix` (`md5key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='strings used in Hot Potatoes questions and responses';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `hotpot_strings`
--

LOCK TABLES `hotpot_strings` WRITE;
/*!40000 ALTER TABLE `hotpot_strings` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotpot_strings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal`
--

DROP TABLE IF EXISTS `journal`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `journal` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `intro` text NOT NULL,
  `introformat` tinyint(2) NOT NULL default '0',
  `days` mediumint(5) unsigned NOT NULL default '7',
  `assessed` bigint(10) NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `jour_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='data for each journal';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `journal`
--

LOCK TABLES `journal` WRITE;
/*!40000 ALTER TABLE `journal` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_entries`
--

DROP TABLE IF EXISTS `journal_entries`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `journal_entries` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `journal` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `modified` bigint(10) unsigned NOT NULL default '0',
  `text` text NOT NULL,
  `format` tinyint(2) NOT NULL default '0',
  `rating` bigint(10) default '0',
  `entrycomment` text,
  `teacher` bigint(10) unsigned NOT NULL default '0',
  `timemarked` bigint(10) unsigned NOT NULL default '0',
  `mailed` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `jourentr_use_ix` (`userid`),
  KEY `jourentr_jou_ix` (`journal`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='All the journal entries of all people';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `journal_entries`
--

LOCK TABLES `journal_entries` WRITE;
/*!40000 ALTER TABLE `journal_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `journal_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `label`
--

DROP TABLE IF EXISTS `label`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `label` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `content` text NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `labe_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines labels';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `label`
--

LOCK TABLES `label` WRITE;
/*!40000 ALTER TABLE `label` DISABLE KEYS */;
/*!40000 ALTER TABLE `label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lams`
--

DROP TABLE IF EXISTS `lams`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `lams` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `introduction` text NOT NULL,
  `learning_session_id` bigint(20) default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `lams_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='LAMS activity';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `lams`
--

LOCK TABLES `lams` WRITE;
/*!40000 ALTER TABLE `lams` DISABLE KEYS */;
/*!40000 ALTER TABLE `lams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson`
--

DROP TABLE IF EXISTS `lesson`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `lesson` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `practice` smallint(3) unsigned NOT NULL default '0',
  `modattempts` smallint(3) unsigned NOT NULL default '0',
  `usepassword` smallint(3) unsigned NOT NULL default '0',
  `password` varchar(32) NOT NULL default '',
  `dependency` bigint(10) unsigned NOT NULL default '0',
  `conditions` text NOT NULL,
  `grade` smallint(3) NOT NULL default '0',
  `custom` smallint(3) unsigned NOT NULL default '0',
  `ongoing` smallint(3) unsigned NOT NULL default '0',
  `usemaxgrade` smallint(3) NOT NULL default '0',
  `maxanswers` smallint(3) unsigned NOT NULL default '4',
  `maxattempts` smallint(3) unsigned NOT NULL default '5',
  `review` smallint(3) unsigned NOT NULL default '0',
  `nextpagedefault` smallint(3) unsigned NOT NULL default '0',
  `feedback` smallint(3) unsigned NOT NULL default '1',
  `minquestions` smallint(3) unsigned NOT NULL default '0',
  `maxpages` smallint(3) unsigned NOT NULL default '0',
  `timed` smallint(3) unsigned NOT NULL default '0',
  `maxtime` bigint(10) unsigned NOT NULL default '0',
  `retake` smallint(3) unsigned NOT NULL default '1',
  `activitylink` bigint(10) unsigned NOT NULL default '0',
  `mediafile` varchar(255) NOT NULL default '',
  `mediaheight` bigint(10) unsigned NOT NULL default '100',
  `mediawidth` bigint(10) unsigned NOT NULL default '650',
  `mediaclose` smallint(3) unsigned NOT NULL default '0',
  `slideshow` smallint(3) unsigned NOT NULL default '0',
  `width` bigint(10) unsigned NOT NULL default '640',
  `height` bigint(10) unsigned NOT NULL default '480',
  `bgcolor` varchar(7) NOT NULL default '#FFFFFF',
  `displayleft` smallint(3) unsigned NOT NULL default '0',
  `displayleftif` smallint(3) unsigned NOT NULL default '0',
  `progressbar` smallint(3) unsigned NOT NULL default '0',
  `highscores` smallint(3) unsigned NOT NULL default '0',
  `maxhighscores` bigint(10) unsigned NOT NULL default '0',
  `available` bigint(10) unsigned NOT NULL default '0',
  `deadline` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `less_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `lesson`
--

LOCK TABLES `lesson` WRITE;
/*!40000 ALTER TABLE `lesson` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_answers`
--

DROP TABLE IF EXISTS `lesson_answers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `lesson_answers` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `lessonid` bigint(10) unsigned NOT NULL default '0',
  `pageid` bigint(10) unsigned NOT NULL default '0',
  `jumpto` bigint(11) NOT NULL default '0',
  `grade` smallint(3) unsigned NOT NULL default '0',
  `score` bigint(10) NOT NULL default '0',
  `flags` smallint(3) unsigned NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `answer` text,
  `response` text,
  PRIMARY KEY  (`id`),
  KEY `lessansw_les_ix` (`lessonid`),
  KEY `lessansw_pag_ix` (`pageid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson_answers';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `lesson_answers`
--

LOCK TABLES `lesson_answers` WRITE;
/*!40000 ALTER TABLE `lesson_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_attempts`
--

DROP TABLE IF EXISTS `lesson_attempts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `lesson_attempts` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `lessonid` bigint(10) unsigned NOT NULL default '0',
  `pageid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `answerid` bigint(10) unsigned NOT NULL default '0',
  `retry` smallint(3) unsigned NOT NULL default '0',
  `correct` bigint(10) unsigned NOT NULL default '0',
  `useranswer` text,
  `timeseen` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `lessatte_use_ix` (`userid`),
  KEY `lessatte_les_ix` (`lessonid`),
  KEY `lessatte_pag_ix` (`pageid`),
  KEY `lessatte_ans_ix` (`answerid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson_attempts';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `lesson_attempts`
--

LOCK TABLES `lesson_attempts` WRITE;
/*!40000 ALTER TABLE `lesson_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_branch`
--

DROP TABLE IF EXISTS `lesson_branch`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `lesson_branch` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `lessonid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `pageid` bigint(10) unsigned NOT NULL default '0',
  `retry` bigint(10) unsigned NOT NULL default '0',
  `flag` smallint(3) unsigned NOT NULL default '0',
  `timeseen` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `lessbran_use_ix` (`userid`),
  KEY `lessbran_les_ix` (`lessonid`),
  KEY `lessbran_pag_ix` (`pageid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='branches for each lesson/user';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `lesson_branch`
--

LOCK TABLES `lesson_branch` WRITE;
/*!40000 ALTER TABLE `lesson_branch` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson_branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_default`
--

DROP TABLE IF EXISTS `lesson_default`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `lesson_default` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `practice` smallint(3) unsigned NOT NULL default '0',
  `modattempts` smallint(3) unsigned NOT NULL default '0',
  `usepassword` smallint(3) unsigned NOT NULL default '0',
  `password` varchar(32) NOT NULL default '',
  `conditions` text NOT NULL,
  `grade` smallint(3) NOT NULL default '0',
  `custom` smallint(3) unsigned NOT NULL default '0',
  `ongoing` smallint(3) unsigned NOT NULL default '0',
  `usemaxgrade` smallint(3) unsigned NOT NULL default '0',
  `maxanswers` smallint(3) unsigned NOT NULL default '4',
  `maxattempts` smallint(3) unsigned NOT NULL default '5',
  `review` smallint(3) unsigned NOT NULL default '0',
  `nextpagedefault` smallint(3) unsigned NOT NULL default '0',
  `feedback` smallint(3) unsigned NOT NULL default '1',
  `minquestions` smallint(3) unsigned NOT NULL default '0',
  `maxpages` smallint(3) unsigned NOT NULL default '0',
  `timed` smallint(3) unsigned NOT NULL default '0',
  `maxtime` bigint(10) unsigned NOT NULL default '0',
  `retake` smallint(3) unsigned NOT NULL default '1',
  `mediaheight` bigint(10) unsigned NOT NULL default '100',
  `mediawidth` bigint(10) unsigned NOT NULL default '650',
  `mediaclose` smallint(3) unsigned NOT NULL default '0',
  `slideshow` smallint(3) unsigned NOT NULL default '0',
  `width` bigint(10) unsigned NOT NULL default '640',
  `height` bigint(10) unsigned NOT NULL default '480',
  `bgcolor` varchar(7) default '#FFFFFF',
  `displayleft` smallint(3) unsigned NOT NULL default '0',
  `displayleftif` smallint(3) unsigned NOT NULL default '0',
  `progressbar` smallint(3) unsigned NOT NULL default '0',
  `highscores` smallint(3) unsigned NOT NULL default '0',
  `maxhighscores` bigint(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson_default';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `lesson_default`
--

LOCK TABLES `lesson_default` WRITE;
/*!40000 ALTER TABLE `lesson_default` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson_default` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_grades`
--

DROP TABLE IF EXISTS `lesson_grades`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `lesson_grades` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `lessonid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `grade` double unsigned NOT NULL default '0',
  `late` smallint(3) unsigned NOT NULL default '0',
  `completed` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `lessgrad_use_ix` (`userid`),
  KEY `lessgrad_les_ix` (`lessonid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson_grades';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `lesson_grades`
--

LOCK TABLES `lesson_grades` WRITE;
/*!40000 ALTER TABLE `lesson_grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson_grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_high_scores`
--

DROP TABLE IF EXISTS `lesson_high_scores`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `lesson_high_scores` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `lessonid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `gradeid` bigint(10) unsigned NOT NULL default '0',
  `nickname` varchar(5) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `lesshighscor_use_ix` (`userid`),
  KEY `lesshighscor_les_ix` (`lessonid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='high scores for each lesson';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `lesson_high_scores`
--

LOCK TABLES `lesson_high_scores` WRITE;
/*!40000 ALTER TABLE `lesson_high_scores` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson_high_scores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_pages`
--

DROP TABLE IF EXISTS `lesson_pages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `lesson_pages` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `lessonid` bigint(10) unsigned NOT NULL default '0',
  `prevpageid` bigint(10) unsigned NOT NULL default '0',
  `nextpageid` bigint(10) unsigned NOT NULL default '0',
  `qtype` smallint(3) unsigned NOT NULL default '0',
  `qoption` smallint(3) unsigned NOT NULL default '0',
  `layout` smallint(3) unsigned NOT NULL default '1',
  `display` smallint(3) unsigned NOT NULL default '1',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `contents` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `lesspage_les_ix` (`lessonid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines lesson_pages';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `lesson_pages`
--

LOCK TABLES `lesson_pages` WRITE;
/*!40000 ALTER TABLE `lesson_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lesson_timer`
--

DROP TABLE IF EXISTS `lesson_timer`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `lesson_timer` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `lessonid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `starttime` bigint(10) unsigned NOT NULL default '0',
  `lessontime` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `lesstime_use_ix` (`userid`),
  KEY `lesstime_les_ix` (`lessonid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='lesson timer for each lesson';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `lesson_timer`
--

LOCK TABLES `lesson_timer` WRITE;
/*!40000 ALTER TABLE `lesson_timer` DISABLE KEYS */;
/*!40000 ALTER TABLE `lesson_timer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `log` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `time` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  `course` bigint(10) unsigned NOT NULL default '0',
  `module` varchar(20) NOT NULL default '',
  `cmid` bigint(10) unsigned NOT NULL default '0',
  `action` varchar(40) NOT NULL default '',
  `url` varchar(100) NOT NULL default '',
  `info` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `log_coumodact_ix` (`course`,`module`,`action`),
  KEY `log_tim_ix` (`time`),
  KEY `log_act_ix` (`action`),
  KEY `log_usecou_ix` (`userid`,`course`),
  KEY `log_cmi_ix` (`cmid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Every action is logged as far as possible';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
INSERT INTO `log` VALUES (1,1253738276,2,'',1,'user',0,'update','view.php?id=2&course=1',' '),(2,1253738300,2,'',1,'course',0,'view','view.php?id=1','1'),(3,1253743628,2,'',1,'course',0,'view','view.php?id=1','1');
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_display`
--

DROP TABLE IF EXISTS `log_display`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `log_display` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `module` varchar(20) NOT NULL default '',
  `action` varchar(40) NOT NULL default '',
  `mtable` varchar(30) NOT NULL default '',
  `field` varchar(200) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `logdisp_modact_uix` (`module`,`action`)
) ENGINE=MyISAM AUTO_INCREMENT=112 DEFAULT CHARSET=utf8 COMMENT='For a particular module/action, specifies a moodle table/fie';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `log_display`
--

LOCK TABLES `log_display` WRITE;
/*!40000 ALTER TABLE `log_display` DISABLE KEYS */;
INSERT INTO `log_display` VALUES (1,'user','view','user','CONCAT(firstname,\' \',lastname)'),(2,'course','user report','user','CONCAT(firstname,\' \',lastname)'),(3,'course','view','course','fullname'),(4,'course','update','course','fullname'),(5,'course','enrol','course','fullname'),(6,'course','unenrol','course','fullname'),(7,'course','report log','course','fullname'),(8,'course','report live','course','fullname'),(9,'course','report outline','course','fullname'),(10,'course','report participation','course','fullname'),(11,'course','report stats','course','fullname'),(12,'message','write','user','CONCAT(firstname,\' \',lastname)'),(13,'message','read','user','CONCAT(firstname,\' \',lastname)'),(14,'message','add contact','user','CONCAT(firstname,\' \',lastname)'),(15,'message','remove contact','user','CONCAT(firstname,\' \',lastname)'),(16,'message','block contact','user','CONCAT(firstname,\' \',lastname)'),(17,'message','unblock contact','user','CONCAT(firstname,\' \',lastname)'),(18,'group','view','groups','name'),(19,'assignment','view','assignment','name'),(20,'assignment','add','assignment','name'),(21,'assignment','update','assignment','name'),(22,'assignment','view submission','assignment','name'),(23,'assignment','upload','assignment','name'),(24,'chat','view','chat','name'),(25,'chat','add','chat','name'),(26,'chat','update','chat','name'),(27,'chat','report','chat','name'),(28,'chat','talk','chat','name'),(29,'choice','view','choice','name'),(30,'choice','update','choice','name'),(31,'choice','add','choice','name'),(32,'choice','report','choice','name'),(33,'choice','choose','choice','name'),(34,'choice','choose again','choice','name'),(35,'data','view','data','name'),(36,'data','add','data','name'),(37,'data','update','data','name'),(38,'data','record delete','data','name'),(39,'data','fields add','data_fields','name'),(40,'data','fields update','data_fields','name'),(41,'data','templates saved','data','name'),(42,'data','templates def','data','name'),(43,'forum','add','forum','name'),(44,'forum','update','forum','name'),(45,'forum','add discussion','forum_discussions','name'),(46,'forum','add post','forum_posts','subject'),(47,'forum','update post','forum_posts','subject'),(48,'forum','user report','user','CONCAT(firstname,\' \',lastname)'),(49,'forum','move discussion','forum_discussions','name'),(50,'forum','view subscribers','forum','name'),(51,'forum','view discussion','forum_discussions','name'),(52,'forum','view forum','forum','name'),(53,'forum','subscribe','forum','name'),(54,'forum','unsubscribe','forum','name'),(55,'glossary','add','glossary','name'),(56,'glossary','update','glossary','name'),(57,'glossary','view','glossary','name'),(58,'glossary','view all','glossary','name'),(59,'glossary','add entry','glossary','name'),(60,'glossary','update entry','glossary','name'),(61,'glossary','add category','glossary','name'),(62,'glossary','update category','glossary','name'),(63,'glossary','delete category','glossary','name'),(64,'glossary','add comment','glossary','name'),(65,'glossary','update comment','glossary','name'),(66,'glossary','delete comment','glossary','name'),(67,'glossary','approve entry','glossary','name'),(68,'glossary','view entry','glossary_entries','concept'),(69,'journal','view','journal','name'),(70,'journal','add entry','journal','name'),(71,'journal','update entry','journal','name'),(72,'journal','view responses','journal','name'),(73,'label','add','label','name'),(74,'label','update','label','name'),(75,'lesson','start','lesson','name'),(76,'lesson','end','lesson','name'),(77,'lesson','view','lesson_pages','title'),(78,'quiz','add','quiz','name'),(79,'quiz','update','quiz','name'),(80,'quiz','view','quiz','name'),(81,'quiz','report','quiz','name'),(82,'quiz','attempt','quiz','name'),(83,'quiz','submit','quiz','name'),(84,'quiz','review','quiz','name'),(85,'quiz','editquestions','quiz','name'),(86,'quiz','preview','quiz','name'),(87,'quiz','start attempt','quiz','name'),(88,'quiz','close attempt','quiz','name'),(89,'quiz','continue attempt','quiz','name'),(90,'resource','view','resource','name'),(91,'resource','update','resource','name'),(92,'resource','add','resource','name'),(93,'scorm','view','scorm','name'),(94,'scorm','review','scorm','name'),(95,'scorm','update','scorm','name'),(96,'scorm','add','scorm','name'),(97,'survey','add','survey','name'),(98,'survey','update','survey','name'),(99,'survey','download','survey','name'),(100,'survey','view form','survey','name'),(101,'survey','view graph','survey','name'),(102,'survey','view report','survey','name'),(103,'survey','submit','survey','name'),(104,'workshop','assessments','workshop','name'),(105,'workshop','close','workshop','name'),(106,'workshop','display','workshop','name'),(107,'workshop','resubmit','workshop','name'),(108,'workshop','set up','workshop','name'),(109,'workshop','submissions','workshop','name'),(110,'workshop','view','workshop','name'),(111,'workshop','update','workshop','name');
/*!40000 ALTER TABLE `log_display` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `message` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `useridfrom` bigint(10) unsigned NOT NULL default '0',
  `useridto` bigint(10) unsigned NOT NULL default '0',
  `message` text NOT NULL,
  `format` smallint(4) unsigned NOT NULL default '0',
  `timecreated` bigint(10) NOT NULL default '0',
  `messagetype` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `mess_use_ix` (`useridfrom`),
  KEY `mess_use2_ix` (`useridto`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores all unread messages';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_contacts`
--

DROP TABLE IF EXISTS `message_contacts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `message_contacts` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `contactid` bigint(10) unsigned NOT NULL default '0',
  `blocked` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `messcont_usecon_uix` (`userid`,`contactid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Maintains lists of relationships between users';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `message_contacts`
--

LOCK TABLES `message_contacts` WRITE;
/*!40000 ALTER TABLE `message_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_read`
--

DROP TABLE IF EXISTS `message_read`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `message_read` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `useridfrom` bigint(10) unsigned NOT NULL default '0',
  `useridto` bigint(10) unsigned NOT NULL default '0',
  `message` text NOT NULL,
  `format` smallint(4) unsigned NOT NULL default '0',
  `timecreated` bigint(10) NOT NULL default '0',
  `timeread` bigint(10) NOT NULL default '0',
  `messagetype` varchar(50) NOT NULL default '',
  `mailed` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `messread_use_ix` (`useridfrom`),
  KEY `messread_use2_ix` (`useridto`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores all messages that have been read';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `message_read`
--

LOCK TABLES `message_read` WRITE;
/*!40000 ALTER TABLE `message_read` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_read` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mnet_application`
--

DROP TABLE IF EXISTS `mnet_application`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mnet_application` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `display_name` varchar(50) NOT NULL default '',
  `xmlrpc_server_url` varchar(255) NOT NULL default '',
  `sso_land_url` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Information about applications on remote hosts';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mnet_application`
--

LOCK TABLES `mnet_application` WRITE;
/*!40000 ALTER TABLE `mnet_application` DISABLE KEYS */;
INSERT INTO `mnet_application` VALUES (1,'moodle','Moodle','/mnet/xmlrpc/server.php','/auth/mnet/land.php'),(2,'mahara','Mahara','/api/xmlrpc/server.php','/auth/xmlrpc/land.php');
/*!40000 ALTER TABLE `mnet_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mnet_enrol_assignments`
--

DROP TABLE IF EXISTS `mnet_enrol_assignments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mnet_enrol_assignments` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `hostid` bigint(10) unsigned NOT NULL default '0',
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `rolename` varchar(255) NOT NULL default '',
  `enroltime` bigint(10) unsigned NOT NULL default '0',
  `enroltype` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `mnetenroassi_hoscou_ix` (`hostid`,`courseid`),
  KEY `mnetenroassi_use_ix` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Information about enrolments on courses on remote hosts';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mnet_enrol_assignments`
--

LOCK TABLES `mnet_enrol_assignments` WRITE;
/*!40000 ALTER TABLE `mnet_enrol_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `mnet_enrol_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mnet_enrol_course`
--

DROP TABLE IF EXISTS `mnet_enrol_course`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mnet_enrol_course` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `hostid` bigint(10) unsigned NOT NULL default '0',
  `remoteid` bigint(10) unsigned NOT NULL default '0',
  `cat_id` bigint(10) unsigned NOT NULL default '0',
  `cat_name` varchar(255) NOT NULL default '',
  `cat_description` mediumtext NOT NULL,
  `sortorder` bigint(10) unsigned NOT NULL default '0',
  `fullname` varchar(254) NOT NULL default '',
  `shortname` varchar(15) NOT NULL default '',
  `idnumber` varchar(100) NOT NULL default '',
  `summary` mediumtext NOT NULL,
  `startdate` bigint(10) unsigned NOT NULL default '0',
  `cost` varchar(10) NOT NULL default '',
  `currency` varchar(3) NOT NULL default '',
  `defaultroleid` smallint(4) unsigned NOT NULL default '0',
  `defaultrolename` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `mnetenrocour_hosrem_uix` (`hostid`,`remoteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Information about courses on remote hosts';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mnet_enrol_course`
--

LOCK TABLES `mnet_enrol_course` WRITE;
/*!40000 ALTER TABLE `mnet_enrol_course` DISABLE KEYS */;
/*!40000 ALTER TABLE `mnet_enrol_course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mnet_host`
--

DROP TABLE IF EXISTS `mnet_host`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mnet_host` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `deleted` tinyint(1) unsigned NOT NULL default '0',
  `wwwroot` varchar(255) NOT NULL default '',
  `ip_address` varchar(39) NOT NULL default '',
  `name` varchar(80) NOT NULL default '',
  `public_key` mediumtext NOT NULL,
  `public_key_expires` bigint(10) unsigned NOT NULL default '0',
  `transport` tinyint(2) unsigned NOT NULL default '0',
  `portno` tinyint(2) unsigned NOT NULL default '0',
  `last_connect_time` bigint(10) unsigned NOT NULL default '0',
  `last_log_id` bigint(10) unsigned NOT NULL default '0',
  `force_theme` tinyint(1) unsigned NOT NULL default '0',
  `theme` varchar(100) default NULL,
  `applicationid` bigint(10) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `mnethost_app_ix` (`applicationid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Information about the local and remote hosts for RPC';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mnet_host`
--

LOCK TABLES `mnet_host` WRITE;
/*!40000 ALTER TABLE `mnet_host` DISABLE KEYS */;
INSERT INTO `mnet_host` VALUES (1,0,'http://localhost/moodle','::1','','',0,0,0,0,0,0,NULL,1),(2,0,'','','All Hosts','',0,0,0,0,0,0,NULL,1);
/*!40000 ALTER TABLE `mnet_host` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mnet_host2service`
--

DROP TABLE IF EXISTS `mnet_host2service`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mnet_host2service` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `hostid` bigint(10) unsigned NOT NULL default '0',
  `serviceid` bigint(10) unsigned NOT NULL default '0',
  `publish` tinyint(1) unsigned NOT NULL default '0',
  `subscribe` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `mnethost_hosser_uix` (`hostid`,`serviceid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Information about the services for a given host';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mnet_host2service`
--

LOCK TABLES `mnet_host2service` WRITE;
/*!40000 ALTER TABLE `mnet_host2service` DISABLE KEYS */;
/*!40000 ALTER TABLE `mnet_host2service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mnet_log`
--

DROP TABLE IF EXISTS `mnet_log`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mnet_log` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `hostid` bigint(10) unsigned NOT NULL default '0',
  `remoteid` bigint(10) unsigned NOT NULL default '0',
  `time` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  `course` bigint(10) unsigned NOT NULL default '0',
  `coursename` varchar(40) NOT NULL default '',
  `module` varchar(20) NOT NULL default '',
  `cmid` bigint(10) unsigned NOT NULL default '0',
  `action` varchar(40) NOT NULL default '',
  `url` varchar(100) NOT NULL default '',
  `info` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `mnetlog_hosusecou_ix` (`hostid`,`userid`,`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Store session data from users migrating to other sites';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mnet_log`
--

LOCK TABLES `mnet_log` WRITE;
/*!40000 ALTER TABLE `mnet_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `mnet_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mnet_rpc`
--

DROP TABLE IF EXISTS `mnet_rpc`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mnet_rpc` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `function_name` varchar(40) NOT NULL default '',
  `xmlrpc_path` varchar(80) NOT NULL default '',
  `parent_type` varchar(6) NOT NULL default '',
  `parent` varchar(20) NOT NULL default '',
  `enabled` tinyint(1) unsigned NOT NULL default '0',
  `help` mediumtext NOT NULL,
  `profile` mediumtext NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `mnetrpc_enaxml_ix` (`enabled`,`xmlrpc_path`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='Functions or methods that we may publish or subscribe to';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mnet_rpc`
--

LOCK TABLES `mnet_rpc` WRITE;
/*!40000 ALTER TABLE `mnet_rpc` DISABLE KEYS */;
INSERT INTO `mnet_rpc` VALUES (1,'user_authorise','auth/mnet/auth.php/user_authorise','auth','mnet',0,'Return user data for the provided token, compare with user_agent string.','a:3:{i:0;a:2:{s:4:\"type\";s:5:\"array\";s:11:\"description\";s:44:\"$userdata Array of user info for remote host\";}i:1;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:45:\"token - The unique ID provided by remotehost.\";}i:2;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:30:\"useragent - User Agent string.\";}}'),(2,'keepalive_server','auth/mnet/auth.php/keepalive_server','auth','mnet',0,'Receives an array of usernames from a remote machine and prods their\\n sessions to keep them alive','a:2:{i:0;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:30:\"\"All ok\" or an error message\";}i:1;a:2:{s:4:\"type\";s:5:\"array\";s:11:\"description\";s:29:\"array - An array of usernames\";}}'),(3,'kill_children','auth/mnet/auth.php/kill_children','auth','mnet',0,'The IdP uses this function to kill child sessions on other hosts','a:3:{i:0;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:39:\"A plaintext report of what has happened\";}i:1;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:39:\"username - Username for session to kill\";}i:2;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:47:\"useragent - SHA1 hash of user agent to look for\";}}'),(4,'refresh_log','auth/mnet/auth.php/refresh_log','auth','mnet',0,'Receives an array of log entries from an SP and adds them to the mnet_log\\n table','a:2:{i:0;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:30:\"\"All ok\" or an error message\";}i:1;a:2:{s:4:\"type\";s:5:\"array\";s:11:\"description\";s:29:\"array - An array of usernames\";}}'),(5,'fetch_user_image','auth/mnet/auth.php/fetch_user_image','auth','mnet',0,'Returns the user\'s image as a base64 encoded string.','a:2:{i:0;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:17:\"The encoded image\";}i:1;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:29:\"username - The id of the user\";}}'),(6,'fetch_theme_info','auth/mnet/auth.php/fetch_theme_info','auth','mnet',0,'Returns the theme information and logo url as strings.','a:1:{i:0;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:14:\"The theme info\";}}'),(7,'update_enrolments','auth/mnet/auth.php/update_enrolments','auth','mnet',0,'Invoke this function _on_ the IDP to update it with enrolment info local to\\n the SP right after calling user_authorise()\\n \\n Normally called by the SP after calling','a:3:{i:0;a:2:{s:4:\"type\";s:7:\"boolean\";s:11:\"description\";N;}i:1;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:23:\"username - The username\";}i:2;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:77:\"courses - Assoc array of courses following the structure of mnet_enrol_course\";}}'),(8,'keepalive_client','auth/mnet/auth.php/keepalive_client','auth','mnet',0,'Poll the IdP server to let it know that a user it has authenticated is still\\n online','a:1:{i:0;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";N;}}'),(9,'kill_child','auth/mnet/auth.php/kill_child','auth','mnet',0,'TODO:Untested When the IdP requests that child sessions are terminated,\\n this function will be called on each of the child hosts. The machine that\\n calls the function (over xmlrpc) provides us with the mnethostid we need.','a:3:{i:0;a:2:{s:4:\"type\";s:7:\"boolean\";s:11:\"description\";s:15:\"True on success\";}i:1;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:39:\"username - Username for session to kill\";}i:2;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:47:\"useragent - SHA1 hash of user agent to look for\";}}'),(10,'available_courses','enrol/mnet/enrol.php/available_courses','enrol','mnet',0,'Does Foo','a:1:{i:0;a:2:{s:4:\"type\";s:7:\"boolean\";s:11:\"description\";s:47:\"Whether the user can login from the remote host\";}}'),(11,'user_enrolments','enrol/mnet/enrol.php/user_enrolments','enrol','mnet',0,'No description given.','a:2:{i:0;a:2:{s:4:\"type\";s:4:\"void\";s:11:\"description\";s:0:\"\";}i:1;s:6:\"userid\";}'),(12,'enrol_user','enrol/mnet/enrol.php/enrol_user','enrol','mnet',0,'Enrols user to course with the default role','a:3:{i:0;a:2:{s:4:\"type\";s:7:\"boolean\";s:11:\"description\";s:41:\"Whether the enrolment has been successful\";}i:1;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:37:\"user - The username of the remote use\";}i:2;a:2:{s:4:\"type\";s:3:\"int\";s:11:\"description\";s:37:\"courseid - The id of the local course\";}}'),(13,'unenrol_user','enrol/mnet/enrol.php/unenrol_user','enrol','mnet',0,'Unenrol a user from a course','a:3:{i:0;a:2:{s:4:\"type\";s:7:\"boolean\";s:11:\"description\";s:47:\"Whether the user can login from the remote host\";}i:1;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:23:\"username - The username\";}i:2;a:2:{s:4:\"type\";s:3:\"int\";s:11:\"description\";s:37:\"courseid - The id of the local course\";}}'),(14,'course_enrolments','enrol/mnet/enrol.php/course_enrolments','enrol','mnet',0,'Get a list of users from the client server who are enrolled in a course','a:3:{i:0;a:2:{s:4:\"type\";s:5:\"array\";s:11:\"description\";s:39:\"Array of usernames who are homed on the\";}i:1;a:2:{s:4:\"type\";s:3:\"int\";s:11:\"description\";s:24:\"courseid - The Course ID\";}i:2;a:2:{s:4:\"type\";s:6:\"string\";s:11:\"description\";s:47:\"roles - Comma-separated list of role shortnames\";}}');
/*!40000 ALTER TABLE `mnet_rpc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mnet_service`
--

DROP TABLE IF EXISTS `mnet_service`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mnet_service` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(40) NOT NULL default '',
  `description` varchar(40) NOT NULL default '',
  `apiversion` varchar(10) NOT NULL default '',
  `offer` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='A service is a group of functions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mnet_service`
--

LOCK TABLES `mnet_service` WRITE;
/*!40000 ALTER TABLE `mnet_service` DISABLE KEYS */;
INSERT INTO `mnet_service` VALUES (1,'sso_idp','','1',1),(2,'sso_sp','','1',1),(3,'mnet_enrol','','1',1);
/*!40000 ALTER TABLE `mnet_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mnet_service2rpc`
--

DROP TABLE IF EXISTS `mnet_service2rpc`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mnet_service2rpc` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `serviceid` bigint(10) unsigned NOT NULL default '0',
  `rpcid` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `mnetserv_rpcser_uix` (`rpcid`,`serviceid`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='Group functions or methods under a service';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mnet_service2rpc`
--

LOCK TABLES `mnet_service2rpc` WRITE;
/*!40000 ALTER TABLE `mnet_service2rpc` DISABLE KEYS */;
INSERT INTO `mnet_service2rpc` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,1,7),(8,2,8),(9,2,9),(10,3,10),(11,3,11),(12,3,12),(13,3,13),(14,3,14);
/*!40000 ALTER TABLE `mnet_service2rpc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mnet_session`
--

DROP TABLE IF EXISTS `mnet_session`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mnet_session` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `username` varchar(100) NOT NULL default '',
  `token` varchar(40) NOT NULL default '',
  `mnethostid` bigint(10) unsigned NOT NULL default '0',
  `useragent` varchar(40) NOT NULL default '',
  `confirm_timeout` bigint(10) unsigned NOT NULL default '0',
  `session_id` varchar(40) NOT NULL default '',
  `expires` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `mnetsess_tok_uix` (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Store session data from users migrating to other sites';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mnet_session`
--

LOCK TABLES `mnet_session` WRITE;
/*!40000 ALTER TABLE `mnet_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `mnet_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mnet_sso_access_control`
--

DROP TABLE IF EXISTS `mnet_sso_access_control`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `mnet_sso_access_control` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `username` varchar(100) NOT NULL default '',
  `mnet_host_id` bigint(10) unsigned NOT NULL default '0',
  `accessctrl` varchar(20) NOT NULL default 'allow',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `mnetssoaccecont_mneuse_uix` (`mnet_host_id`,`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Users by host permitted (or not) to login from a remote prov';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `mnet_sso_access_control`
--

LOCK TABLES `mnet_sso_access_control` WRITE;
/*!40000 ALTER TABLE `mnet_sso_access_control` DISABLE KEYS */;
/*!40000 ALTER TABLE `mnet_sso_access_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `modules` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(20) NOT NULL default '',
  `version` bigint(10) NOT NULL default '0',
  `cron` bigint(10) unsigned NOT NULL default '0',
  `lastcron` bigint(10) unsigned NOT NULL default '0',
  `search` varchar(255) NOT NULL default '',
  `visible` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `modu_nam_ix` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='modules available in the site';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,'assignment',2007101511,60,0,'',1),(2,'chat',2007101509,300,0,'',1),(3,'choice',2007101509,0,0,'',1),(4,'data',2007101513,60,0,'',1),(5,'forum',2007101512,60,0,'',1),(6,'glossary',2007101509,0,0,'',1),(7,'hotpot',2007101511,0,0,'',0),(8,'journal',2007101509,60,0,'',0),(9,'label',2007101510,0,0,'',1),(10,'lams',2007101509,0,0,'',0),(11,'lesson',2007101509,0,0,'',1),(12,'quiz',2007101510,0,0,'',1),(13,'resource',2007101509,0,0,'',1),(14,'scorm',2007110501,300,0,'',1),(15,'survey',2007101509,0,0,'',1),(16,'wiki',2007101509,3600,0,'',1),(17,'workshop',2007101509,60,0,'',0);
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `post` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `module` varchar(20) NOT NULL default '',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `groupid` bigint(10) unsigned NOT NULL default '0',
  `moduleid` bigint(10) unsigned NOT NULL default '0',
  `coursemoduleid` bigint(10) unsigned NOT NULL default '0',
  `subject` varchar(128) NOT NULL default '',
  `summary` longtext,
  `content` longtext,
  `uniquehash` varchar(128) NOT NULL default '',
  `rating` bigint(10) unsigned NOT NULL default '0',
  `format` bigint(10) unsigned NOT NULL default '0',
  `attachment` varchar(100) default NULL,
  `publishstate` enum('draft','site','public') NOT NULL default 'draft',
  `lastmodified` bigint(10) unsigned NOT NULL default '0',
  `created` bigint(10) unsigned NOT NULL default '0',
  `usermodified` bigint(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `post_iduse_uix` (`id`,`userid`),
  KEY `post_las_ix` (`lastmodified`),
  KEY `post_mod_ix` (`module`),
  KEY `post_sub_ix` (`subject`),
  KEY `post_use_ix` (`usermodified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Generic post table to hold data blog entries etc in differen';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `category` bigint(10) NOT NULL default '0',
  `parent` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `questiontext` text NOT NULL,
  `questiontextformat` tinyint(2) NOT NULL default '0',
  `image` varchar(255) NOT NULL default '',
  `generalfeedback` text NOT NULL,
  `defaultgrade` bigint(10) unsigned NOT NULL default '1',
  `penalty` double NOT NULL default '0.1',
  `qtype` varchar(20) NOT NULL default '',
  `length` bigint(10) unsigned NOT NULL default '1',
  `stamp` varchar(255) NOT NULL default '',
  `version` varchar(255) NOT NULL default '',
  `hidden` tinyint(1) unsigned NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `createdby` bigint(10) unsigned default NULL,
  `modifiedby` bigint(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  KEY `ques_cat_ix` (`category`),
  KEY `ques_par_ix` (`parent`),
  KEY `ques_cre_ix` (`createdby`),
  KEY `ques_mod_ix` (`modifiedby`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='The questions themselves';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_answers`
--

DROP TABLE IF EXISTS `question_answers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_answers` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `question` bigint(10) unsigned NOT NULL default '0',
  `answer` text NOT NULL,
  `fraction` double NOT NULL default '0',
  `feedback` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `quesansw_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Answers, with a fractional grade (0-1) and feedback';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_answers`
--

LOCK TABLES `question_answers` WRITE;
/*!40000 ALTER TABLE `question_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_attempts`
--

DROP TABLE IF EXISTS `question_attempts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_attempts` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `modulename` varchar(20) NOT NULL default 'quiz',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Student attempts. This table gets extended by the modules';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_attempts`
--

LOCK TABLES `question_attempts` WRITE;
/*!40000 ALTER TABLE `question_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_calculated`
--

DROP TABLE IF EXISTS `question_calculated`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_calculated` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `question` bigint(10) unsigned NOT NULL default '0',
  `answer` bigint(10) unsigned NOT NULL default '0',
  `tolerance` varchar(20) NOT NULL default '0.0',
  `tolerancetype` bigint(10) NOT NULL default '1',
  `correctanswerlength` bigint(10) NOT NULL default '2',
  `correctanswerformat` bigint(10) NOT NULL default '2',
  PRIMARY KEY  (`id`),
  KEY `quescalc_ans_ix` (`answer`),
  KEY `quescalc_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for questions of type calculated';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_calculated`
--

LOCK TABLES `question_calculated` WRITE;
/*!40000 ALTER TABLE `question_calculated` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_calculated` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_categories`
--

DROP TABLE IF EXISTS `question_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_categories` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `contextid` bigint(10) unsigned NOT NULL default '0',
  `info` text NOT NULL,
  `stamp` varchar(255) NOT NULL default '',
  `parent` bigint(10) unsigned NOT NULL default '0',
  `sortorder` bigint(10) unsigned NOT NULL default '999',
  PRIMARY KEY  (`id`),
  KEY `quescate_con_ix` (`contextid`),
  KEY `quescate_par_ix` (`parent`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Categories are for grouping questions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_categories`
--

LOCK TABLES `question_categories` WRITE;
/*!40000 ALTER TABLE `question_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_dataset_definitions`
--

DROP TABLE IF EXISTS `question_dataset_definitions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_dataset_definitions` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `category` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `type` bigint(10) NOT NULL default '0',
  `options` varchar(255) NOT NULL default '',
  `itemcount` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `quesdatadefi_cat_ix` (`category`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Organises and stores properties for dataset items';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_dataset_definitions`
--

LOCK TABLES `question_dataset_definitions` WRITE;
/*!40000 ALTER TABLE `question_dataset_definitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_dataset_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_dataset_items`
--

DROP TABLE IF EXISTS `question_dataset_items`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_dataset_items` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `definition` bigint(10) unsigned NOT NULL default '0',
  `itemnumber` bigint(10) unsigned NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `quesdataitem_def_ix` (`definition`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Individual dataset items';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_dataset_items`
--

LOCK TABLES `question_dataset_items` WRITE;
/*!40000 ALTER TABLE `question_dataset_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_dataset_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_datasets`
--

DROP TABLE IF EXISTS `question_datasets`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_datasets` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `question` bigint(10) unsigned NOT NULL default '0',
  `datasetdefinition` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `quesdata_quedat_ix` (`question`,`datasetdefinition`),
  KEY `quesdata_que_ix` (`question`),
  KEY `quesdata_dat_ix` (`datasetdefinition`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Many-many relation between questions and dataset definitions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_datasets`
--

LOCK TABLES `question_datasets` WRITE;
/*!40000 ALTER TABLE `question_datasets` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_datasets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_match`
--

DROP TABLE IF EXISTS `question_match`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_match` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `question` bigint(10) unsigned NOT NULL default '0',
  `subquestions` varchar(255) NOT NULL default '',
  `shuffleanswers` smallint(4) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `quesmatc_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines fixed matching questions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_match`
--

LOCK TABLES `question_match` WRITE;
/*!40000 ALTER TABLE `question_match` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_match` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_match_sub`
--

DROP TABLE IF EXISTS `question_match_sub`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_match_sub` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `code` bigint(10) unsigned NOT NULL default '0',
  `question` bigint(10) unsigned NOT NULL default '0',
  `questiontext` text NOT NULL,
  `answertext` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `quesmatcsub_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines the subquestions that make up a matching question';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_match_sub`
--

LOCK TABLES `question_match_sub` WRITE;
/*!40000 ALTER TABLE `question_match_sub` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_match_sub` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_multianswer`
--

DROP TABLE IF EXISTS `question_multianswer`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_multianswer` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `question` bigint(10) unsigned NOT NULL default '0',
  `sequence` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `quesmult_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for multianswer questions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_multianswer`
--

LOCK TABLES `question_multianswer` WRITE;
/*!40000 ALTER TABLE `question_multianswer` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_multianswer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_multichoice`
--

DROP TABLE IF EXISTS `question_multichoice`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_multichoice` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `question` bigint(10) unsigned NOT NULL default '0',
  `layout` smallint(4) NOT NULL default '0',
  `answers` varchar(255) NOT NULL default '',
  `single` smallint(4) NOT NULL default '0',
  `shuffleanswers` smallint(4) NOT NULL default '1',
  `correctfeedback` text NOT NULL,
  `partiallycorrectfeedback` text NOT NULL,
  `incorrectfeedback` text NOT NULL,
  `answernumbering` varchar(10) NOT NULL default 'abc',
  PRIMARY KEY  (`id`),
  KEY `quesmult_que2_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for multiple choice questions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_multichoice`
--

LOCK TABLES `question_multichoice` WRITE;
/*!40000 ALTER TABLE `question_multichoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_multichoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_numerical`
--

DROP TABLE IF EXISTS `question_numerical`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_numerical` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `question` bigint(10) unsigned NOT NULL default '0',
  `answer` bigint(10) unsigned NOT NULL default '0',
  `tolerance` varchar(255) NOT NULL default '0.0',
  PRIMARY KEY  (`id`),
  KEY `quesnume_ans_ix` (`answer`),
  KEY `quesnume_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for numerical questions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_numerical`
--

LOCK TABLES `question_numerical` WRITE;
/*!40000 ALTER TABLE `question_numerical` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_numerical` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_numerical_units`
--

DROP TABLE IF EXISTS `question_numerical_units`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_numerical_units` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `question` bigint(10) unsigned NOT NULL default '0',
  `multiplier` decimal(40,20) NOT NULL default '1.00000000000000000000',
  `unit` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `quesnumeunit_queuni_uix` (`question`,`unit`),
  KEY `quesnumeunit_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Optional unit options for numerical questions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_numerical_units`
--

LOCK TABLES `question_numerical_units` WRITE;
/*!40000 ALTER TABLE `question_numerical_units` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_numerical_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_randomsamatch`
--

DROP TABLE IF EXISTS `question_randomsamatch`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_randomsamatch` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `question` bigint(10) unsigned NOT NULL default '0',
  `choose` bigint(10) unsigned NOT NULL default '4',
  PRIMARY KEY  (`id`),
  KEY `quesrand_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about a random short-answer matching question';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_randomsamatch`
--

LOCK TABLES `question_randomsamatch` WRITE;
/*!40000 ALTER TABLE `question_randomsamatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_randomsamatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_sessions`
--

DROP TABLE IF EXISTS `question_sessions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_sessions` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `attemptid` bigint(10) unsigned NOT NULL default '0',
  `questionid` bigint(10) unsigned NOT NULL default '0',
  `newest` bigint(10) unsigned NOT NULL default '0',
  `newgraded` bigint(10) unsigned NOT NULL default '0',
  `sumpenalty` double NOT NULL default '0',
  `manualcomment` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `quessess_attque_uix` (`attemptid`,`questionid`),
  KEY `quessess_att_ix` (`attemptid`),
  KEY `quessess_que_ix` (`questionid`),
  KEY `quessess_new_ix` (`newest`),
  KEY `quessess_new2_ix` (`newgraded`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Gives ids of the newest open and newest graded states';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_sessions`
--

LOCK TABLES `question_sessions` WRITE;
/*!40000 ALTER TABLE `question_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_shortanswer`
--

DROP TABLE IF EXISTS `question_shortanswer`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_shortanswer` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `question` bigint(10) unsigned NOT NULL default '0',
  `answers` varchar(255) NOT NULL default '',
  `usecase` tinyint(2) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `quesshor_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for short answer questions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_shortanswer`
--

LOCK TABLES `question_shortanswer` WRITE;
/*!40000 ALTER TABLE `question_shortanswer` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_shortanswer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_states`
--

DROP TABLE IF EXISTS `question_states`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_states` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `attempt` bigint(10) unsigned NOT NULL default '0',
  `question` bigint(10) unsigned NOT NULL default '0',
  `originalquestion` bigint(10) unsigned NOT NULL default '0',
  `seq_number` mediumint(6) unsigned NOT NULL default '0',
  `answer` text NOT NULL,
  `timestamp` bigint(10) unsigned NOT NULL default '0',
  `event` smallint(4) unsigned NOT NULL default '0',
  `grade` double NOT NULL default '0',
  `raw_grade` double NOT NULL default '0',
  `penalty` double NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `quesstat_att_ix` (`attempt`),
  KEY `quesstat_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores user responses to an attempt, and percentage grades';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_states`
--

LOCK TABLES `question_states` WRITE;
/*!40000 ALTER TABLE `question_states` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_truefalse`
--

DROP TABLE IF EXISTS `question_truefalse`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `question_truefalse` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `question` bigint(10) unsigned NOT NULL default '0',
  `trueanswer` bigint(10) unsigned NOT NULL default '0',
  `falseanswer` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `questrue_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Options for True-False questions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `question_truefalse`
--

LOCK TABLES `question_truefalse` WRITE;
/*!40000 ALTER TABLE `question_truefalse` DISABLE KEYS */;
/*!40000 ALTER TABLE `question_truefalse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `quiz` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `intro` text NOT NULL,
  `timeopen` bigint(10) unsigned NOT NULL default '0',
  `timeclose` bigint(10) unsigned NOT NULL default '0',
  `optionflags` bigint(10) unsigned NOT NULL default '0',
  `penaltyscheme` smallint(4) unsigned NOT NULL default '0',
  `attempts` mediumint(6) NOT NULL default '0',
  `attemptonlast` smallint(4) NOT NULL default '0',
  `grademethod` smallint(4) NOT NULL default '1',
  `decimalpoints` smallint(4) NOT NULL default '2',
  `review` bigint(10) unsigned NOT NULL default '0',
  `questionsperpage` bigint(10) NOT NULL default '0',
  `shufflequestions` smallint(4) NOT NULL default '0',
  `shuffleanswers` smallint(4) NOT NULL default '0',
  `questions` text NOT NULL,
  `sumgrades` bigint(10) NOT NULL default '0',
  `grade` bigint(10) NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `timelimit` bigint(10) unsigned NOT NULL default '0',
  `password` varchar(255) NOT NULL default '',
  `subnet` varchar(255) NOT NULL default '',
  `popup` smallint(4) NOT NULL default '0',
  `delay1` bigint(10) NOT NULL default '0',
  `delay2` bigint(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `quiz_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Main information about each quiz';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `quiz`
--

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_attempts`
--

DROP TABLE IF EXISTS `quiz_attempts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `quiz_attempts` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `uniqueid` bigint(10) unsigned NOT NULL default '0',
  `quiz` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `attempt` mediumint(6) NOT NULL default '0',
  `sumgrades` double NOT NULL default '0',
  `timestart` bigint(10) unsigned NOT NULL default '0',
  `timefinish` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `layout` text NOT NULL,
  `preview` smallint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `quizatte_uni_uix` (`uniqueid`),
  KEY `quizatte_use_ix` (`userid`),
  KEY `quizatte_qui_ix` (`quiz`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores various attempts on a quiz';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `quiz_attempts`
--

LOCK TABLES `quiz_attempts` WRITE;
/*!40000 ALTER TABLE `quiz_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_feedback`
--

DROP TABLE IF EXISTS `quiz_feedback`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `quiz_feedback` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `quizid` bigint(10) unsigned NOT NULL default '0',
  `feedbacktext` text NOT NULL,
  `mingrade` double NOT NULL default '0',
  `maxgrade` double NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `quizfeed_qui_ix` (`quizid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Feedback given to students based on their overall score on t';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `quiz_feedback`
--

LOCK TABLES `quiz_feedback` WRITE;
/*!40000 ALTER TABLE `quiz_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_grades`
--

DROP TABLE IF EXISTS `quiz_grades`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `quiz_grades` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `quiz` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `grade` double NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `quizgrad_use_ix` (`userid`),
  KEY `quizgrad_qui_ix` (`quiz`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Final quiz grade (may be best of several attempts)';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `quiz_grades`
--

LOCK TABLES `quiz_grades` WRITE;
/*!40000 ALTER TABLE `quiz_grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_question_instances`
--

DROP TABLE IF EXISTS `quiz_question_instances`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `quiz_question_instances` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `quiz` bigint(10) unsigned NOT NULL default '0',
  `question` bigint(10) unsigned NOT NULL default '0',
  `grade` mediumint(6) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `quizquesinst_qui_ix` (`quiz`),
  KEY `quizquesinst_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='The grade for a question in a quiz';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `quiz_question_instances`
--

LOCK TABLES `quiz_question_instances` WRITE;
/*!40000 ALTER TABLE `quiz_question_instances` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_question_instances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quiz_question_versions`
--

DROP TABLE IF EXISTS `quiz_question_versions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `quiz_question_versions` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `quiz` bigint(10) unsigned NOT NULL default '0',
  `oldquestion` bigint(10) unsigned NOT NULL default '0',
  `newquestion` bigint(10) unsigned NOT NULL default '0',
  `originalquestion` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `timestamp` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `quizquesvers_qui_ix` (`quiz`),
  KEY `quizquesvers_old_ix` (`oldquestion`),
  KEY `quizquesvers_new_ix` (`newquestion`),
  KEY `quizquesvers_ori_ix` (`originalquestion`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='quiz_question_versions table retrofitted from MySQL';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `quiz_question_versions`
--

LOCK TABLES `quiz_question_versions` WRITE;
/*!40000 ALTER TABLE `quiz_question_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `quiz_question_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resource`
--

DROP TABLE IF EXISTS `resource`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `resource` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `type` varchar(30) NOT NULL default '',
  `reference` varchar(255) NOT NULL default '',
  `summary` text,
  `alltext` mediumtext NOT NULL,
  `popup` text NOT NULL,
  `options` varchar(255) NOT NULL default '',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `reso_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='each record is one resource and its config data';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `resource`
--

LOCK TABLES `resource` WRITE;
/*!40000 ALTER TABLE `resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `role` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `shortname` varchar(100) NOT NULL default '',
  `description` text NOT NULL,
  `sortorder` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `role_sor_uix` (`sortorder`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='moodle roles';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Administrator','admin','Administrators can usually do anything on the site, in all courses.',0),(2,'Course creator','coursecreator','Course creators can create new courses and teach in them.',1),(3,'Teacher','editingteacher','Teachers can do anything within a course, including changing the activities and grading students.',2),(4,'Non-editing teacher','teacher','Non-editing teachers can teach in courses and grade students, but may not alter activities.',3),(5,'Student','student','Students generally have fewer privileges within a course.',4),(6,'Guest','guest','Guests have minimal privileges and usually can not enter text anywhere.',5),(7,'Authenticated user','user','All logged in users.',6);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_allow_assign`
--

DROP TABLE IF EXISTS `role_allow_assign`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `role_allow_assign` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `roleid` bigint(10) unsigned NOT NULL default '0',
  `allowassign` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `rolealloassi_rolall_uix` (`roleid`,`allowassign`),
  KEY `rolealloassi_rol_ix` (`roleid`),
  KEY `rolealloassi_all_ix` (`allowassign`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='this defines what role can assign what role';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `role_allow_assign`
--

LOCK TABLES `role_allow_assign` WRITE;
/*!40000 ALTER TABLE `role_allow_assign` DISABLE KEYS */;
INSERT INTO `role_allow_assign` VALUES (1,1,1),(2,1,2),(3,1,4),(4,1,3),(5,1,5),(6,1,6),(7,2,4),(8,2,3),(9,2,5),(10,2,6),(11,3,4),(12,3,5),(13,3,6);
/*!40000 ALTER TABLE `role_allow_assign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_allow_override`
--

DROP TABLE IF EXISTS `role_allow_override`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `role_allow_override` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `roleid` bigint(10) unsigned NOT NULL default '0',
  `allowoverride` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `rolealloover_rolall_uix` (`roleid`,`allowoverride`),
  KEY `rolealloover_rol_ix` (`roleid`),
  KEY `rolealloover_all_ix` (`allowoverride`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='this defines what role can override what role';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `role_allow_override`
--

LOCK TABLES `role_allow_override` WRITE;
/*!40000 ALTER TABLE `role_allow_override` DISABLE KEYS */;
INSERT INTO `role_allow_override` VALUES (1,1,1),(2,1,2),(3,1,4),(4,1,3),(5,1,5),(6,1,6),(7,1,7);
/*!40000 ALTER TABLE `role_allow_override` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_assignments`
--

DROP TABLE IF EXISTS `role_assignments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `role_assignments` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `roleid` bigint(10) unsigned NOT NULL default '0',
  `contextid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `hidden` tinyint(1) unsigned NOT NULL default '0',
  `timestart` bigint(10) unsigned NOT NULL default '0',
  `timeend` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `modifierid` bigint(10) unsigned NOT NULL default '0',
  `enrol` varchar(20) NOT NULL default '',
  `sortorder` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `roleassi_conroluse_uix` (`contextid`,`roleid`,`userid`),
  KEY `roleassi_sor_ix` (`sortorder`),
  KEY `roleassi_rol_ix` (`roleid`),
  KEY `roleassi_con_ix` (`contextid`),
  KEY `roleassi_use_ix` (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='assigning roles to different context';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `role_assignments`
--

LOCK TABLES `role_assignments` WRITE;
/*!40000 ALTER TABLE `role_assignments` DISABLE KEYS */;
INSERT INTO `role_assignments` VALUES (1,1,1,2,0,0,0,1253737996,2,'manual',0);
/*!40000 ALTER TABLE `role_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_capabilities`
--

DROP TABLE IF EXISTS `role_capabilities`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `role_capabilities` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `contextid` bigint(10) unsigned NOT NULL default '0',
  `roleid` bigint(10) unsigned NOT NULL default '0',
  `capability` varchar(255) NOT NULL default '',
  `permission` bigint(10) NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `modifierid` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `rolecapa_rolconcap_uix` (`roleid`,`contextid`,`capability`),
  KEY `rolecapa_rol_ix` (`roleid`),
  KEY `rolecapa_con_ix` (`contextid`),
  KEY `rolecapa_mod_ix` (`modifierid`),
  KEY `rolecapa_cap_ix` (`capability`)
) ENGINE=MyISAM AUTO_INCREMENT=523 DEFAULT CHARSET=utf8 COMMENT='permission has to be signed, overriding a capability for a p';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `role_capabilities`
--

LOCK TABLES `role_capabilities` WRITE;
/*!40000 ALTER TABLE `role_capabilities` DISABLE KEYS */;
INSERT INTO `role_capabilities` VALUES (1,1,1,'moodle/legacy:admin',1,1253737973,2),(2,1,2,'moodle/legacy:coursecreator',1,1253737973,2),(3,1,3,'moodle/legacy:editingteacher',1,1253737973,2),(4,1,4,'moodle/legacy:teacher',1,1253737973,2),(5,1,5,'moodle/legacy:student',1,1253737973,2),(6,1,6,'moodle/legacy:guest',1,1253737973,2),(7,1,7,'moodle/legacy:user',1,1253737973,2),(8,1,1,'moodle/site:doanything',1,1253737973,2),(9,1,1,'moodle/site:config',1,1253737973,2),(10,1,1,'moodle/site:readallmessages',1,1253737973,2),(11,1,3,'moodle/site:readallmessages',1,1253737973,2),(12,1,1,'moodle/site:sendmessage',1,1253737973,2),(13,1,7,'moodle/site:sendmessage',1,1253737973,2),(14,1,1,'moodle/site:approvecourse',1,1253737973,2),(15,1,3,'moodle/site:import',1,1253737973,2),(16,1,1,'moodle/site:import',1,1253737973,2),(17,1,3,'moodle/site:backup',1,1253737973,2),(18,1,1,'moodle/site:backup',1,1253737973,2),(19,1,3,'moodle/site:restore',1,1253737973,2),(20,1,1,'moodle/site:restore',1,1253737973,2),(21,1,3,'moodle/site:manageblocks',1,1253737973,2),(22,1,1,'moodle/site:manageblocks',1,1253737973,2),(23,1,4,'moodle/site:accessallgroups',1,1253737973,2),(24,1,3,'moodle/site:accessallgroups',1,1253737973,2),(25,1,1,'moodle/site:accessallgroups',1,1253737973,2),(26,1,4,'moodle/site:viewfullnames',1,1253737973,2),(27,1,3,'moodle/site:viewfullnames',1,1253737973,2),(28,1,1,'moodle/site:viewfullnames',1,1253737973,2),(29,1,4,'moodle/site:viewreports',1,1253737973,2),(30,1,3,'moodle/site:viewreports',1,1253737973,2),(31,1,1,'moodle/site:viewreports',1,1253737973,2),(32,1,3,'moodle/site:trustcontent',1,1253737973,2),(33,1,1,'moodle/site:trustcontent',1,1253737973,2),(34,1,1,'moodle/site:uploadusers',1,1253737973,2),(35,1,1,'moodle/site:langeditmaster',-1,1253737973,2),(36,1,1,'moodle/site:langeditlocal',1,1253737973,2),(37,1,1,'moodle/user:create',1,1253737973,2),(38,1,1,'moodle/user:delete',1,1253737973,2),(39,1,1,'moodle/user:update',1,1253737973,2),(40,1,6,'moodle/user:viewdetails',1,1253737973,2),(41,1,5,'moodle/user:viewdetails',1,1253737973,2),(42,1,4,'moodle/user:viewdetails',1,1253737973,2),(43,1,3,'moodle/user:viewdetails',1,1253737973,2),(44,1,1,'moodle/user:viewdetails',1,1253737973,2),(45,1,4,'moodle/user:viewhiddendetails',1,1253737973,2),(46,1,3,'moodle/user:viewhiddendetails',1,1253737973,2),(47,1,1,'moodle/user:viewhiddendetails',1,1253737973,2),(48,1,1,'moodle/user:loginas',1,1253737973,2),(49,1,3,'moodle/role:assign',1,1253737973,2),(50,1,1,'moodle/role:assign',1,1253737973,2),(51,1,1,'moodle/role:override',1,1253737973,2),(52,1,3,'moodle/role:safeoverride',1,1253737973,2),(53,1,1,'moodle/role:manage',1,1253737973,2),(54,1,4,'moodle/role:unassignself',1,1253737973,2),(55,1,3,'moodle/role:unassignself',1,1253737974,2),(56,1,2,'moodle/role:unassignself',1,1253737974,2),(57,1,1,'moodle/role:unassignself',1,1253737974,2),(58,1,4,'moodle/role:viewhiddenassigns',1,1253737974,2),(59,1,3,'moodle/role:viewhiddenassigns',1,1253737974,2),(60,1,1,'moodle/role:viewhiddenassigns',1,1253737974,2),(61,1,3,'moodle/role:switchroles',1,1253737974,2),(62,1,1,'moodle/role:switchroles',1,1253737974,2),(63,1,1,'moodle/category:create',1,1253737974,2),(64,1,1,'moodle/category:delete',1,1253737974,2),(65,1,1,'moodle/category:update',1,1253737974,2),(66,1,1,'moodle/category:visibility',1,1253737974,2),(67,1,2,'moodle/course:create',1,1253737974,2),(68,1,1,'moodle/course:create',1,1253737974,2),(69,1,1,'moodle/course:delete',1,1253737974,2),(70,1,3,'moodle/course:update',1,1253737974,2),(71,1,1,'moodle/course:update',1,1253737974,2),(72,1,6,'moodle/course:view',1,1253737974,2),(73,1,5,'moodle/course:view',1,1253737974,2),(74,1,4,'moodle/course:view',1,1253737974,2),(75,1,3,'moodle/course:view',1,1253737974,2),(76,1,4,'moodle/course:bulkmessaging',1,1253737974,2),(77,1,3,'moodle/course:bulkmessaging',1,1253737974,2),(78,1,1,'moodle/course:bulkmessaging',1,1253737974,2),(79,1,4,'moodle/course:viewhiddenuserfields',1,1253737974,2),(80,1,3,'moodle/course:viewhiddenuserfields',1,1253737974,2),(81,1,1,'moodle/course:viewhiddenuserfields',1,1253737974,2),(82,1,2,'moodle/course:viewhiddencourses',1,1253737974,2),(83,1,4,'moodle/course:viewhiddencourses',1,1253737974,2),(84,1,3,'moodle/course:viewhiddencourses',1,1253737974,2),(85,1,1,'moodle/course:viewhiddencourses',1,1253737974,2),(86,1,1,'moodle/course:visibility',1,1253737974,2),(87,1,3,'moodle/course:managefiles',1,1253737974,2),(88,1,1,'moodle/course:managefiles',1,1253737974,2),(89,1,3,'moodle/course:manageactivities',1,1253737974,2),(90,1,1,'moodle/course:manageactivities',1,1253737974,2),(91,1,3,'moodle/course:managemetacourse',1,1253737974,2),(92,1,1,'moodle/course:managemetacourse',1,1253737974,2),(93,1,3,'moodle/course:activityvisibility',1,1253737974,2),(94,1,1,'moodle/course:activityvisibility',1,1253737974,2),(95,1,4,'moodle/course:viewhiddenactivities',1,1253737974,2),(96,1,3,'moodle/course:viewhiddenactivities',1,1253737974,2),(97,1,1,'moodle/course:viewhiddenactivities',1,1253737974,2),(98,1,5,'moodle/course:viewparticipants',1,1253737974,2),(99,1,4,'moodle/course:viewparticipants',1,1253737974,2),(100,1,3,'moodle/course:viewparticipants',1,1253737974,2),(101,1,1,'moodle/course:viewparticipants',1,1253737974,2),(102,1,3,'moodle/course:changefullname',1,1253737974,2),(103,1,1,'moodle/course:changefullname',1,1253737974,2),(104,1,3,'moodle/course:changeshortname',1,1253737974,2),(105,1,1,'moodle/course:changeshortname',1,1253737974,2),(106,1,3,'moodle/course:changeidnumber',1,1253737974,2),(107,1,1,'moodle/course:changeidnumber',1,1253737974,2),(108,1,1,'moodle/site:viewparticipants',1,1253737974,2),(109,1,5,'moodle/course:viewscales',1,1253737974,2),(110,1,4,'moodle/course:viewscales',1,1253737974,2),(111,1,3,'moodle/course:viewscales',1,1253737974,2),(112,1,1,'moodle/course:viewscales',1,1253737974,2),(113,1,3,'moodle/course:managescales',1,1253737974,2),(114,1,1,'moodle/course:managescales',1,1253737974,2),(115,1,3,'moodle/course:managegroups',1,1253737974,2),(116,1,1,'moodle/course:managegroups',1,1253737974,2),(117,1,3,'moodle/course:reset',1,1253737974,2),(118,1,1,'moodle/course:reset',1,1253737974,2),(119,1,6,'moodle/blog:view',1,1253737974,2),(120,1,7,'moodle/blog:view',1,1253737974,2),(121,1,5,'moodle/blog:view',1,1253737974,2),(122,1,4,'moodle/blog:view',1,1253737974,2),(123,1,3,'moodle/blog:view',1,1253737974,2),(124,1,1,'moodle/blog:view',1,1253737974,2),(125,1,7,'moodle/blog:create',1,1253737974,2),(126,1,1,'moodle/blog:create',1,1253737974,2),(127,1,4,'moodle/blog:manageentries',1,1253737974,2),(128,1,3,'moodle/blog:manageentries',1,1253737974,2),(129,1,1,'moodle/blog:manageentries',1,1253737974,2),(130,1,7,'moodle/calendar:manageownentries',1,1253737974,2),(131,1,1,'moodle/calendar:manageownentries',1,1253737974,2),(132,1,4,'moodle/calendar:managegroupentries',1,1253737974,2),(133,1,3,'moodle/calendar:managegroupentries',1,1253737974,2),(134,1,1,'moodle/calendar:managegroupentries',1,1253737974,2),(135,1,4,'moodle/calendar:manageentries',1,1253737974,2),(136,1,3,'moodle/calendar:manageentries',1,1253737974,2),(137,1,1,'moodle/calendar:manageentries',1,1253737974,2),(138,1,1,'moodle/user:editprofile',1,1253737974,2),(139,1,6,'moodle/user:editownprofile',-1000,1253737974,2),(140,1,7,'moodle/user:editownprofile',1,1253737974,2),(141,1,1,'moodle/user:editownprofile',1,1253737974,2),(142,1,6,'moodle/user:changeownpassword',-1000,1253737974,2),(143,1,7,'moodle/user:changeownpassword',1,1253737974,2),(144,1,1,'moodle/user:changeownpassword',1,1253737974,2),(145,1,5,'moodle/user:readuserposts',1,1253737974,2),(146,1,4,'moodle/user:readuserposts',1,1253737974,2),(147,1,3,'moodle/user:readuserposts',1,1253737974,2),(148,1,1,'moodle/user:readuserposts',1,1253737974,2),(149,1,5,'moodle/user:readuserblogs',1,1253737974,2),(150,1,4,'moodle/user:readuserblogs',1,1253737974,2),(151,1,3,'moodle/user:readuserblogs',1,1253737974,2),(152,1,1,'moodle/user:readuserblogs',1,1253737974,2),(153,1,4,'moodle/user:viewuseractivitiesreport',1,1253737974,2),(154,1,3,'moodle/user:viewuseractivitiesreport',1,1253737974,2),(155,1,1,'moodle/user:viewuseractivitiesreport',1,1253737974,2),(156,1,3,'moodle/question:managecategory',1,1253737974,2),(157,1,1,'moodle/question:managecategory',1,1253737974,2),(158,1,3,'moodle/question:add',1,1253737974,2),(159,1,1,'moodle/question:add',1,1253737974,2),(160,1,3,'moodle/question:editmine',1,1253737974,2),(161,1,1,'moodle/question:editmine',1,1253737974,2),(162,1,3,'moodle/question:editall',1,1253737974,2),(163,1,1,'moodle/question:editall',1,1253737974,2),(164,1,3,'moodle/question:viewmine',1,1253737974,2),(165,1,1,'moodle/question:viewmine',1,1253737974,2),(166,1,3,'moodle/question:viewall',1,1253737974,2),(167,1,1,'moodle/question:viewall',1,1253737974,2),(168,1,3,'moodle/question:usemine',1,1253737974,2),(169,1,1,'moodle/question:usemine',1,1253737974,2),(170,1,3,'moodle/question:useall',1,1253737974,2),(171,1,1,'moodle/question:useall',1,1253737974,2),(172,1,3,'moodle/question:movemine',1,1253737974,2),(173,1,1,'moodle/question:movemine',1,1253737974,2),(174,1,3,'moodle/question:moveall',1,1253737974,2),(175,1,1,'moodle/question:moveall',1,1253737974,2),(176,1,1,'moodle/question:config',1,1253737974,2),(177,1,4,'moodle/site:doclinks',1,1253737974,2),(178,1,3,'moodle/site:doclinks',1,1253737974,2),(179,1,1,'moodle/site:doclinks',1,1253737974,2),(180,1,3,'moodle/course:sectionvisibility',1,1253737974,2),(181,1,1,'moodle/course:sectionvisibility',1,1253737974,2),(182,1,3,'moodle/course:useremail',1,1253737974,2),(183,1,1,'moodle/course:useremail',1,1253737974,2),(184,1,3,'moodle/course:viewhiddensections',1,1253737974,2),(185,1,1,'moodle/course:viewhiddensections',1,1253737974,2),(186,1,3,'moodle/course:setcurrentsection',1,1253737974,2),(187,1,1,'moodle/course:setcurrentsection',1,1253737974,2),(188,1,1,'moodle/site:mnetlogintoremote',1,1253737974,2),(189,1,4,'moodle/grade:viewall',1,1253737974,2),(190,1,3,'moodle/grade:viewall',1,1253737974,2),(191,1,1,'moodle/grade:viewall',1,1253737974,2),(192,1,5,'moodle/grade:view',1,1253737974,2),(193,1,4,'moodle/grade:viewhidden',1,1253737974,2),(194,1,3,'moodle/grade:viewhidden',1,1253737974,2),(195,1,1,'moodle/grade:viewhidden',1,1253737974,2),(196,1,3,'moodle/grade:import',1,1253737974,2),(197,1,1,'moodle/grade:import',1,1253737974,2),(198,1,4,'moodle/grade:export',1,1253737974,2),(199,1,3,'moodle/grade:export',1,1253737974,2),(200,1,1,'moodle/grade:export',1,1253737974,2),(201,1,3,'moodle/grade:manage',1,1253737974,2),(202,1,1,'moodle/grade:manage',1,1253737974,2),(203,1,3,'moodle/grade:edit',1,1253737974,2),(204,1,1,'moodle/grade:edit',1,1253737974,2),(205,1,3,'moodle/grade:manageoutcomes',1,1253737974,2),(206,1,1,'moodle/grade:manageoutcomes',1,1253737974,2),(207,1,3,'moodle/grade:manageletters',1,1253737974,2),(208,1,1,'moodle/grade:manageletters',1,1253737974,2),(209,1,3,'moodle/grade:hide',1,1253737974,2),(210,1,1,'moodle/grade:hide',1,1253737974,2),(211,1,3,'moodle/grade:lock',1,1253737974,2),(212,1,1,'moodle/grade:lock',1,1253737974,2),(213,1,3,'moodle/grade:unlock',1,1253737974,2),(214,1,1,'moodle/grade:unlock',1,1253737974,2),(215,1,7,'moodle/my:manageblocks',1,1253737974,2),(216,1,4,'moodle/notes:view',1,1253737974,2),(217,1,3,'moodle/notes:view',1,1253737974,2),(218,1,1,'moodle/notes:view',1,1253737974,2),(219,1,4,'moodle/notes:manage',1,1253737974,2),(220,1,3,'moodle/notes:manage',1,1253737974,2),(221,1,1,'moodle/notes:manage',1,1253737974,2),(222,1,4,'moodle/tag:manage',1,1253737974,2),(223,1,3,'moodle/tag:manage',1,1253737974,2),(224,1,1,'moodle/tag:manage',1,1253737974,2),(225,1,1,'moodle/tag:create',1,1253737974,2),(226,1,7,'moodle/tag:create',1,1253737974,2),(227,1,1,'moodle/tag:edit',1,1253737974,2),(228,1,7,'moodle/tag:edit',1,1253737974,2),(229,1,4,'moodle/tag:editblocks',1,1253737974,2),(230,1,3,'moodle/tag:editblocks',1,1253737974,2),(231,1,1,'moodle/tag:editblocks',1,1253737974,2),(232,1,6,'moodle/block:view',1,1253737974,2),(233,1,7,'moodle/block:view',1,1253737974,2),(234,1,5,'moodle/block:view',1,1253737974,2),(235,1,4,'moodle/block:view',1,1253737974,2),(236,1,3,'moodle/block:view',1,1253737974,2),(237,1,2,'moodle/block:view',1,1253737974,2),(238,1,6,'mod/assignment:view',1,1253737976,2),(239,1,5,'mod/assignment:view',1,1253737976,2),(240,1,4,'mod/assignment:view',1,1253737976,2),(241,1,3,'mod/assignment:view',1,1253737976,2),(242,1,1,'mod/assignment:view',1,1253737976,2),(243,1,5,'mod/assignment:submit',1,1253737976,2),(244,1,4,'mod/assignment:grade',1,1253737976,2),(245,1,3,'mod/assignment:grade',1,1253737976,2),(246,1,1,'mod/assignment:grade',1,1253737976,2),(247,1,5,'mod/chat:chat',1,1253737977,2),(248,1,4,'mod/chat:chat',1,1253737977,2),(249,1,3,'mod/chat:chat',1,1253737977,2),(250,1,1,'mod/chat:chat',1,1253737977,2),(251,1,5,'mod/chat:readlog',1,1253737977,2),(252,1,4,'mod/chat:readlog',1,1253737977,2),(253,1,3,'mod/chat:readlog',1,1253737977,2),(254,1,1,'mod/chat:readlog',1,1253737977,2),(255,1,4,'mod/chat:deletelog',1,1253737977,2),(256,1,3,'mod/chat:deletelog',1,1253737977,2),(257,1,1,'mod/chat:deletelog',1,1253737977,2),(258,1,5,'mod/choice:choose',1,1253737977,2),(259,1,4,'mod/choice:choose',1,1253737977,2),(260,1,3,'mod/choice:choose',1,1253737977,2),(261,1,1,'mod/choice:choose',1,1253737977,2),(262,1,4,'mod/choice:readresponses',1,1253737977,2),(263,1,3,'mod/choice:readresponses',1,1253737977,2),(264,1,1,'mod/choice:readresponses',1,1253737977,2),(265,1,4,'mod/choice:deleteresponses',1,1253737977,2),(266,1,3,'mod/choice:deleteresponses',1,1253737977,2),(267,1,1,'mod/choice:deleteresponses',1,1253737977,2),(268,1,4,'mod/choice:downloadresponses',1,1253737977,2),(269,1,3,'mod/choice:downloadresponses',1,1253737977,2),(270,1,1,'mod/choice:downloadresponses',1,1253737977,2),(271,1,6,'mod/data:viewentry',1,1253737977,2),(272,1,5,'mod/data:viewentry',1,1253737977,2),(273,1,4,'mod/data:viewentry',1,1253737977,2),(274,1,3,'mod/data:viewentry',1,1253737977,2),(275,1,1,'mod/data:viewentry',1,1253737977,2),(276,1,5,'mod/data:writeentry',1,1253737977,2),(277,1,4,'mod/data:writeentry',1,1253737977,2),(278,1,3,'mod/data:writeentry',1,1253737977,2),(279,1,1,'mod/data:writeentry',1,1253737977,2),(280,1,5,'mod/data:comment',1,1253737977,2),(281,1,4,'mod/data:comment',1,1253737977,2),(282,1,3,'mod/data:comment',1,1253737977,2),(283,1,1,'mod/data:comment',1,1253737977,2),(284,1,4,'mod/data:viewrating',1,1253737977,2),(285,1,3,'mod/data:viewrating',1,1253737977,2),(286,1,1,'mod/data:viewrating',1,1253737977,2),(287,1,4,'mod/data:rate',1,1253737977,2),(288,1,3,'mod/data:rate',1,1253737977,2),(289,1,1,'mod/data:rate',1,1253737977,2),(290,1,4,'mod/data:approve',1,1253737977,2),(291,1,3,'mod/data:approve',1,1253737977,2),(292,1,1,'mod/data:approve',1,1253737977,2),(293,1,4,'mod/data:manageentries',1,1253737977,2),(294,1,3,'mod/data:manageentries',1,1253737977,2),(295,1,1,'mod/data:manageentries',1,1253737977,2),(296,1,4,'mod/data:managecomments',1,1253737977,2),(297,1,3,'mod/data:managecomments',1,1253737977,2),(298,1,1,'mod/data:managecomments',1,1253737977,2),(299,1,3,'mod/data:managetemplates',1,1253737977,2),(300,1,1,'mod/data:managetemplates',1,1253737977,2),(301,1,4,'mod/data:viewalluserpresets',1,1253737977,2),(302,1,3,'mod/data:viewalluserpresets',1,1253737977,2),(303,1,1,'mod/data:viewalluserpresets',1,1253737977,2),(304,1,1,'mod/data:manageuserpresets',1,1253737977,2),(305,1,6,'mod/forum:viewdiscussion',1,1253737978,2),(306,1,5,'mod/forum:viewdiscussion',1,1253737978,2),(307,1,4,'mod/forum:viewdiscussion',1,1253737978,2),(308,1,3,'mod/forum:viewdiscussion',1,1253737978,2),(309,1,1,'mod/forum:viewdiscussion',1,1253737978,2),(310,1,4,'mod/forum:viewhiddentimedposts',1,1253737978,2),(311,1,3,'mod/forum:viewhiddentimedposts',1,1253737978,2),(312,1,1,'mod/forum:viewhiddentimedposts',1,1253737978,2),(313,1,5,'mod/forum:startdiscussion',1,1253737978,2),(314,1,4,'mod/forum:startdiscussion',1,1253737978,2),(315,1,3,'mod/forum:startdiscussion',1,1253737978,2),(316,1,1,'mod/forum:startdiscussion',1,1253737978,2),(317,1,5,'mod/forum:replypost',1,1253737978,2),(318,1,4,'mod/forum:replypost',1,1253737978,2),(319,1,3,'mod/forum:replypost',1,1253737978,2),(320,1,1,'mod/forum:replypost',1,1253737978,2),(321,1,4,'mod/forum:addnews',1,1253737978,2),(322,1,3,'mod/forum:addnews',1,1253737978,2),(323,1,1,'mod/forum:addnews',1,1253737978,2),(324,1,4,'mod/forum:replynews',1,1253737978,2),(325,1,3,'mod/forum:replynews',1,1253737978,2),(326,1,1,'mod/forum:replynews',1,1253737978,2),(327,1,5,'mod/forum:viewrating',1,1253737978,2),(328,1,4,'mod/forum:viewrating',1,1253737978,2),(329,1,3,'mod/forum:viewrating',1,1253737978,2),(330,1,1,'mod/forum:viewrating',1,1253737978,2),(331,1,4,'mod/forum:viewanyrating',1,1253737978,2),(332,1,3,'mod/forum:viewanyrating',1,1253737978,2),(333,1,1,'mod/forum:viewanyrating',1,1253737978,2),(334,1,4,'mod/forum:rate',1,1253737978,2),(335,1,3,'mod/forum:rate',1,1253737978,2),(336,1,1,'mod/forum:rate',1,1253737978,2),(337,1,5,'mod/forum:createattachment',1,1253737978,2),(338,1,4,'mod/forum:createattachment',1,1253737978,2),(339,1,3,'mod/forum:createattachment',1,1253737978,2),(340,1,1,'mod/forum:createattachment',1,1253737978,2),(341,1,5,'mod/forum:deleteownpost',1,1253737978,2),(342,1,4,'mod/forum:deleteownpost',1,1253737978,2),(343,1,3,'mod/forum:deleteownpost',1,1253737978,2),(344,1,1,'mod/forum:deleteownpost',1,1253737978,2),(345,1,4,'mod/forum:deleteanypost',1,1253737978,2),(346,1,3,'mod/forum:deleteanypost',1,1253737978,2),(347,1,1,'mod/forum:deleteanypost',1,1253737978,2),(348,1,4,'mod/forum:splitdiscussions',1,1253737978,2),(349,1,3,'mod/forum:splitdiscussions',1,1253737978,2),(350,1,1,'mod/forum:splitdiscussions',1,1253737978,2),(351,1,4,'mod/forum:movediscussions',1,1253737978,2),(352,1,3,'mod/forum:movediscussions',1,1253737978,2),(353,1,1,'mod/forum:movediscussions',1,1253737978,2),(354,1,4,'mod/forum:editanypost',1,1253737978,2),(355,1,3,'mod/forum:editanypost',1,1253737978,2),(356,1,1,'mod/forum:editanypost',1,1253737978,2),(357,1,4,'mod/forum:viewqandawithoutposting',1,1253737978,2),(358,1,3,'mod/forum:viewqandawithoutposting',1,1253737978,2),(359,1,1,'mod/forum:viewqandawithoutposting',1,1253737978,2),(360,1,4,'mod/forum:viewsubscribers',1,1253737978,2),(361,1,3,'mod/forum:viewsubscribers',1,1253737978,2),(362,1,1,'mod/forum:viewsubscribers',1,1253737978,2),(363,1,4,'mod/forum:managesubscriptions',1,1253737978,2),(364,1,3,'mod/forum:managesubscriptions',1,1253737978,2),(365,1,1,'mod/forum:managesubscriptions',1,1253737978,2),(366,1,4,'mod/forum:initialsubscriptions',1,1253737978,2),(367,1,3,'mod/forum:initialsubscriptions',1,1253737978,2),(368,1,5,'mod/forum:initialsubscriptions',1,1253737978,2),(369,1,5,'mod/glossary:write',1,1253737978,2),(370,1,4,'mod/glossary:write',1,1253737978,2),(371,1,3,'mod/glossary:write',1,1253737978,2),(372,1,1,'mod/glossary:write',1,1253737978,2),(373,1,4,'mod/glossary:manageentries',1,1253737978,2),(374,1,3,'mod/glossary:manageentries',1,1253737978,2),(375,1,1,'mod/glossary:manageentries',1,1253737978,2),(376,1,4,'mod/glossary:managecategories',1,1253737978,2),(377,1,3,'mod/glossary:managecategories',1,1253737978,2),(378,1,1,'mod/glossary:managecategories',1,1253737978,2),(379,1,5,'mod/glossary:comment',1,1253737978,2),(380,1,4,'mod/glossary:comment',1,1253737978,2),(381,1,3,'mod/glossary:comment',1,1253737978,2),(382,1,1,'mod/glossary:comment',1,1253737978,2),(383,1,4,'mod/glossary:managecomments',1,1253737978,2),(384,1,3,'mod/glossary:managecomments',1,1253737978,2),(385,1,1,'mod/glossary:managecomments',1,1253737978,2),(386,1,4,'mod/glossary:import',1,1253737978,2),(387,1,3,'mod/glossary:import',1,1253737978,2),(388,1,1,'mod/glossary:import',1,1253737978,2),(389,1,4,'mod/glossary:export',1,1253737978,2),(390,1,3,'mod/glossary:export',1,1253737978,2),(391,1,1,'mod/glossary:export',1,1253737978,2),(392,1,4,'mod/glossary:approve',1,1253737978,2),(393,1,3,'mod/glossary:approve',1,1253737978,2),(394,1,1,'mod/glossary:approve',1,1253737978,2),(395,1,4,'mod/glossary:rate',1,1253737978,2),(396,1,3,'mod/glossary:rate',1,1253737979,2),(397,1,1,'mod/glossary:rate',1,1253737979,2),(398,1,4,'mod/glossary:viewrating',1,1253737979,2),(399,1,3,'mod/glossary:viewrating',1,1253737979,2),(400,1,1,'mod/glossary:viewrating',1,1253737979,2),(401,1,5,'mod/hotpot:attempt',1,1253737979,2),(402,1,4,'mod/hotpot:attempt',1,1253737979,2),(403,1,3,'mod/hotpot:attempt',1,1253737979,2),(404,1,1,'mod/hotpot:attempt',1,1253737979,2),(405,1,4,'mod/hotpot:viewreport',1,1253737979,2),(406,1,3,'mod/hotpot:viewreport',1,1253737979,2),(407,1,1,'mod/hotpot:viewreport',1,1253737979,2),(408,1,4,'mod/hotpot:grade',1,1253737979,2),(409,1,3,'mod/hotpot:grade',1,1253737979,2),(410,1,1,'mod/hotpot:grade',1,1253737979,2),(411,1,3,'mod/hotpot:deleteattempt',1,1253737979,2),(412,1,1,'mod/hotpot:deleteattempt',1,1253737979,2),(413,1,5,'mod/lams:participate',1,1253737979,2),(414,1,4,'mod/lams:manage',1,1253737979,2),(415,1,3,'mod/lams:manage',1,1253737979,2),(416,1,1,'mod/lams:manage',1,1253737979,2),(417,1,3,'mod/lesson:edit',1,1253737980,2),(418,1,1,'mod/lesson:edit',1,1253737980,2),(419,1,4,'mod/lesson:manage',1,1253737980,2),(420,1,3,'mod/lesson:manage',1,1253737980,2),(421,1,1,'mod/lesson:manage',1,1253737980,2),(422,1,6,'mod/quiz:view',1,1253737981,2),(423,1,5,'mod/quiz:view',1,1253737981,2),(424,1,4,'mod/quiz:view',1,1253737981,2),(425,1,3,'mod/quiz:view',1,1253737981,2),(426,1,1,'mod/quiz:view',1,1253737981,2),(427,1,5,'mod/quiz:attempt',1,1253737981,2),(428,1,3,'mod/quiz:manage',1,1253737981,2),(429,1,1,'mod/quiz:manage',1,1253737981,2),(430,1,4,'mod/quiz:preview',1,1253737981,2),(431,1,3,'mod/quiz:preview',1,1253737981,2),(432,1,1,'mod/quiz:preview',1,1253737981,2),(433,1,4,'mod/quiz:grade',1,1253737981,2),(434,1,3,'mod/quiz:grade',1,1253737981,2),(435,1,1,'mod/quiz:grade',1,1253737981,2),(436,1,4,'mod/quiz:viewreports',1,1253737981,2),(437,1,3,'mod/quiz:viewreports',1,1253737981,2),(438,1,1,'mod/quiz:viewreports',1,1253737981,2),(439,1,3,'mod/quiz:deleteattempts',1,1253737981,2),(440,1,1,'mod/quiz:deleteattempts',1,1253737981,2),(441,1,4,'mod/scorm:viewreport',1,1253737982,2),(442,1,3,'mod/scorm:viewreport',1,1253737982,2),(443,1,1,'mod/scorm:viewreport',1,1253737982,2),(444,1,5,'mod/scorm:skipview',1,1253737982,2),(445,1,5,'mod/scorm:savetrack',1,1253737982,2),(446,1,4,'mod/scorm:savetrack',1,1253737982,2),(447,1,3,'mod/scorm:savetrack',1,1253737982,2),(448,1,1,'mod/scorm:savetrack',1,1253737982,2),(449,1,5,'mod/scorm:viewscores',1,1253737982,2),(450,1,4,'mod/scorm:viewscores',1,1253737982,2),(451,1,3,'mod/scorm:viewscores',1,1253737982,2),(452,1,1,'mod/scorm:viewscores',1,1253737982,2),(453,1,5,'mod/survey:participate',1,1253737982,2),(454,1,4,'mod/survey:participate',1,1253737982,2),(455,1,3,'mod/survey:participate',1,1253737982,2),(456,1,1,'mod/survey:participate',1,1253737982,2),(457,1,4,'mod/survey:readresponses',1,1253737982,2),(458,1,3,'mod/survey:readresponses',1,1253737982,2),(459,1,1,'mod/survey:readresponses',1,1253737982,2),(460,1,4,'mod/survey:download',1,1253737982,2),(461,1,3,'mod/survey:download',1,1253737982,2),(462,1,1,'mod/survey:download',1,1253737982,2),(463,1,5,'mod/wiki:participate',1,1253737983,2),(464,1,4,'mod/wiki:participate',1,1253737983,2),(465,1,3,'mod/wiki:participate',1,1253737983,2),(466,1,1,'mod/wiki:participate',1,1253737983,2),(467,1,4,'mod/wiki:manage',1,1253737983,2),(468,1,3,'mod/wiki:manage',1,1253737983,2),(469,1,1,'mod/wiki:manage',1,1253737983,2),(470,1,4,'mod/wiki:overridelock',1,1253737983,2),(471,1,3,'mod/wiki:overridelock',1,1253737983,2),(472,1,1,'mod/wiki:overridelock',1,1253737983,2),(473,1,5,'mod/workshop:participate',1,1253737983,2),(474,1,4,'mod/workshop:manage',1,1253737983,2),(475,1,3,'mod/workshop:manage',1,1253737983,2),(476,1,1,'mod/workshop:manage',1,1253737983,2),(477,1,4,'block/rss_client:createprivatefeeds',1,1253737987,2),(478,1,3,'block/rss_client:createprivatefeeds',1,1253737987,2),(479,1,1,'block/rss_client:createprivatefeeds',1,1253737987,2),(480,1,3,'block/rss_client:createsharedfeeds',1,1253737987,2),(481,1,1,'block/rss_client:createsharedfeeds',1,1253737987,2),(482,1,4,'block/rss_client:manageownfeeds',1,1253737987,2),(483,1,3,'block/rss_client:manageownfeeds',1,1253737987,2),(484,1,1,'block/rss_client:manageownfeeds',1,1253737987,2),(485,1,1,'block/rss_client:manageanyfeeds',1,1253737987,2),(486,1,1,'enrol/authorize:managepayments',1,1253737989,2),(487,1,1,'enrol/authorize:uploadcsv',1,1253737989,2),(488,1,4,'gradeexport/ods:view',1,1253737990,2),(489,1,3,'gradeexport/ods:view',1,1253737990,2),(490,1,1,'gradeexport/ods:view',1,1253737990,2),(491,1,1,'gradeexport/ods:publish',1,1253737990,2),(492,1,4,'gradeexport/txt:view',1,1253737990,2),(493,1,3,'gradeexport/txt:view',1,1253737990,2),(494,1,1,'gradeexport/txt:view',1,1253737990,2),(495,1,1,'gradeexport/txt:publish',1,1253737990,2),(496,1,4,'gradeexport/xls:view',1,1253737990,2),(497,1,3,'gradeexport/xls:view',1,1253737990,2),(498,1,1,'gradeexport/xls:view',1,1253737990,2),(499,1,1,'gradeexport/xls:publish',1,1253737990,2),(500,1,4,'gradeexport/xml:view',1,1253737990,2),(501,1,3,'gradeexport/xml:view',1,1253737990,2),(502,1,1,'gradeexport/xml:view',1,1253737990,2),(503,1,1,'gradeexport/xml:publish',1,1253737990,2),(504,1,3,'gradeimport/csv:view',1,1253737992,2),(505,1,1,'gradeimport/csv:view',1,1253737992,2),(506,1,3,'gradeimport/xml:view',1,1253737992,2),(507,1,1,'gradeimport/xml:view',1,1253737992,2),(508,1,1,'gradeimport/xml:publish',1,1253737992,2),(509,1,4,'gradereport/grader:view',1,1253737993,2),(510,1,3,'gradereport/grader:view',1,1253737993,2),(511,1,1,'gradereport/grader:view',1,1253737993,2),(512,1,4,'gradereport/outcomes:view',1,1253737993,2),(513,1,3,'gradereport/outcomes:view',1,1253737993,2),(514,1,1,'gradereport/outcomes:view',1,1253737993,2),(515,1,4,'gradereport/overview:view',1,1253737993,2),(516,1,3,'gradereport/overview:view',1,1253737993,2),(517,1,5,'gradereport/overview:view',1,1253737993,2),(518,1,1,'gradereport/overview:view',1,1253737993,2),(519,1,5,'gradereport/user:view',1,1253737993,2),(520,1,4,'gradereport/user:view',1,1253737993,2),(521,1,3,'gradereport/user:view',1,1253737993,2),(522,1,1,'gradereport/user:view',1,1253737993,2);
/*!40000 ALTER TABLE `role_capabilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_names`
--

DROP TABLE IF EXISTS `role_names`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `role_names` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `roleid` bigint(10) unsigned NOT NULL default '0',
  `contextid` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `rolename_rolcon_uix` (`roleid`,`contextid`),
  KEY `rolename_rol_ix` (`roleid`),
  KEY `rolename_con_ix` (`contextid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='role names in native strings';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `role_names`
--

LOCK TABLES `role_names` WRITE;
/*!40000 ALTER TABLE `role_names` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_sortorder`
--

DROP TABLE IF EXISTS `role_sortorder`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `role_sortorder` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL,
  `roleid` bigint(10) unsigned NOT NULL,
  `contextid` bigint(10) unsigned NOT NULL,
  `sortoder` bigint(10) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `rolesort_userolcon_uix` (`userid`,`roleid`,`contextid`),
  KEY `rolesort_use_ix` (`userid`),
  KEY `rolesort_rol_ix` (`roleid`),
  KEY `rolesort_con_ix` (`contextid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='sort order of course managers in a course';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `role_sortorder`
--

LOCK TABLES `role_sortorder` WRITE;
/*!40000 ALTER TABLE `role_sortorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_sortorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scale`
--

DROP TABLE IF EXISTS `scale`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scale` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `scale` text NOT NULL,
  `description` text NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `scal_cou_ix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines grading scales';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scale`
--

LOCK TABLES `scale` WRITE;
/*!40000 ALTER TABLE `scale` DISABLE KEYS */;
/*!40000 ALTER TABLE `scale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scale_history`
--

DROP TABLE IF EXISTS `scale_history`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scale_history` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `action` bigint(10) unsigned NOT NULL default '0',
  `oldid` bigint(10) unsigned NOT NULL,
  `source` varchar(255) default NULL,
  `timemodified` bigint(10) unsigned default NULL,
  `loggeduser` bigint(10) unsigned default NULL,
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `scale` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `scalhist_act_ix` (`action`),
  KEY `scalhist_old_ix` (`oldid`),
  KEY `scalhist_cou_ix` (`courseid`),
  KEY `scalhist_log_ix` (`loggeduser`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='History table';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scale_history`
--

LOCK TABLES `scale_history` WRITE;
/*!40000 ALTER TABLE `scale_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `scale_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scorm`
--

DROP TABLE IF EXISTS `scorm`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scorm` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `reference` varchar(255) NOT NULL default '',
  `summary` text NOT NULL,
  `version` varchar(9) NOT NULL default '',
  `maxgrade` double NOT NULL default '0',
  `grademethod` tinyint(2) NOT NULL default '0',
  `whatgrade` bigint(10) NOT NULL default '0',
  `maxattempt` bigint(10) NOT NULL default '1',
  `updatefreq` tinyint(1) unsigned NOT NULL default '0',
  `md5hash` varchar(32) NOT NULL default '',
  `launch` bigint(10) unsigned NOT NULL default '0',
  `skipview` tinyint(1) unsigned NOT NULL default '1',
  `hidebrowse` tinyint(1) NOT NULL default '0',
  `hidetoc` tinyint(1) NOT NULL default '0',
  `hidenav` tinyint(1) NOT NULL default '0',
  `auto` tinyint(1) unsigned NOT NULL default '0',
  `popup` tinyint(1) unsigned NOT NULL default '0',
  `options` varchar(255) NOT NULL default '',
  `width` bigint(10) unsigned NOT NULL default '100',
  `height` bigint(10) unsigned NOT NULL default '600',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `scor_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='each table is one SCORM module and its configuration';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scorm`
--

LOCK TABLES `scorm` WRITE;
/*!40000 ALTER TABLE `scorm` DISABLE KEYS */;
/*!40000 ALTER TABLE `scorm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scorm_scoes`
--

DROP TABLE IF EXISTS `scorm_scoes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scorm_scoes` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `scorm` bigint(10) unsigned NOT NULL default '0',
  `manifest` varchar(255) NOT NULL default '',
  `organization` varchar(255) NOT NULL default '',
  `parent` varchar(255) NOT NULL default '',
  `identifier` varchar(255) NOT NULL default '',
  `launch` varchar(255) NOT NULL default '',
  `scormtype` varchar(5) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `scorscoe_sco_ix` (`scorm`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='each SCO part of the SCORM module';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scorm_scoes`
--

LOCK TABLES `scorm_scoes` WRITE;
/*!40000 ALTER TABLE `scorm_scoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `scorm_scoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scorm_scoes_data`
--

DROP TABLE IF EXISTS `scorm_scoes_data`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scorm_scoes_data` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `scoid` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `value` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `scorscoedata_sco_ix` (`scoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Contains variable data get from packages';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scorm_scoes_data`
--

LOCK TABLES `scorm_scoes_data` WRITE;
/*!40000 ALTER TABLE `scorm_scoes_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `scorm_scoes_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scorm_scoes_track`
--

DROP TABLE IF EXISTS `scorm_scoes_track`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scorm_scoes_track` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `scormid` bigint(10) NOT NULL default '0',
  `scoid` bigint(10) unsigned NOT NULL default '0',
  `attempt` bigint(10) unsigned NOT NULL default '1',
  `element` varchar(255) NOT NULL default '',
  `value` longtext NOT NULL,
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `scorscoetrac_usescoscoatte_uix` (`userid`,`scormid`,`scoid`,`attempt`,`element`),
  KEY `scorscoetrac_use_ix` (`userid`),
  KEY `scorscoetrac_ele_ix` (`element`),
  KEY `scorscoetrac_sco_ix` (`scormid`),
  KEY `scorscoetrac_sco2_ix` (`scoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to track SCOes';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scorm_scoes_track`
--

LOCK TABLES `scorm_scoes_track` WRITE;
/*!40000 ALTER TABLE `scorm_scoes_track` DISABLE KEYS */;
/*!40000 ALTER TABLE `scorm_scoes_track` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scorm_seq_mapinfo`
--

DROP TABLE IF EXISTS `scorm_seq_mapinfo`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scorm_seq_mapinfo` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `scoid` bigint(10) unsigned NOT NULL default '0',
  `objectiveid` bigint(10) unsigned NOT NULL default '0',
  `targetobjectiveid` bigint(10) unsigned NOT NULL default '0',
  `readsatisfiedstatus` tinyint(1) NOT NULL default '1',
  `readnormalizedmeasure` tinyint(1) NOT NULL default '1',
  `writesatisfiedstatus` tinyint(1) NOT NULL default '0',
  `writenormalizedmeasure` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `scorseqmapi_scoidobj_uix` (`scoid`,`id`,`objectiveid`),
  KEY `scorseqmapi_sco_ix` (`scoid`),
  KEY `scorseqmapi_obj_ix` (`objectiveid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 objective mapinfo description';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scorm_seq_mapinfo`
--

LOCK TABLES `scorm_seq_mapinfo` WRITE;
/*!40000 ALTER TABLE `scorm_seq_mapinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `scorm_seq_mapinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scorm_seq_objective`
--

DROP TABLE IF EXISTS `scorm_seq_objective`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scorm_seq_objective` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `scoid` bigint(10) unsigned NOT NULL default '0',
  `primaryobj` tinyint(1) NOT NULL default '0',
  `objectiveid` bigint(10) unsigned NOT NULL default '0',
  `satisfiedbymeasure` tinyint(1) NOT NULL default '1',
  `minnormalizedmeasure` float(11,4) unsigned NOT NULL default '0.0000',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `scorseqobje_scoid_uix` (`scoid`,`id`),
  KEY `scorseqobje_sco_ix` (`scoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 objective description';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scorm_seq_objective`
--

LOCK TABLES `scorm_seq_objective` WRITE;
/*!40000 ALTER TABLE `scorm_seq_objective` DISABLE KEYS */;
/*!40000 ALTER TABLE `scorm_seq_objective` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scorm_seq_rolluprule`
--

DROP TABLE IF EXISTS `scorm_seq_rolluprule`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scorm_seq_rolluprule` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `scoid` bigint(10) unsigned NOT NULL default '0',
  `childactivityset` varchar(15) NOT NULL default '',
  `minimumcount` bigint(10) unsigned NOT NULL default '0',
  `minimumpercent` float(11,4) unsigned NOT NULL default '0.0000',
  `conditioncombination` varchar(3) NOT NULL default 'all',
  `action` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `scorseqroll_scoid_uix` (`scoid`,`id`),
  KEY `scorseqroll_sco_ix` (`scoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 sequencing rule';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scorm_seq_rolluprule`
--

LOCK TABLES `scorm_seq_rolluprule` WRITE;
/*!40000 ALTER TABLE `scorm_seq_rolluprule` DISABLE KEYS */;
/*!40000 ALTER TABLE `scorm_seq_rolluprule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scorm_seq_rolluprulecond`
--

DROP TABLE IF EXISTS `scorm_seq_rolluprulecond`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scorm_seq_rolluprulecond` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `scoid` bigint(10) unsigned NOT NULL default '0',
  `rollupruleid` bigint(10) unsigned NOT NULL default '0',
  `operator` varchar(5) NOT NULL default 'noOp',
  `cond` varchar(25) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `scorseqroll_scorolid_uix` (`scoid`,`rollupruleid`,`id`),
  KEY `scorseqroll_sco2_ix` (`scoid`),
  KEY `scorseqroll_rol_ix` (`rollupruleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 sequencing rule';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scorm_seq_rolluprulecond`
--

LOCK TABLES `scorm_seq_rolluprulecond` WRITE;
/*!40000 ALTER TABLE `scorm_seq_rolluprulecond` DISABLE KEYS */;
/*!40000 ALTER TABLE `scorm_seq_rolluprulecond` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scorm_seq_rulecond`
--

DROP TABLE IF EXISTS `scorm_seq_rulecond`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scorm_seq_rulecond` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `scoid` bigint(10) unsigned NOT NULL default '0',
  `ruleconditionsid` bigint(10) unsigned NOT NULL default '0',
  `refrencedobjective` varchar(255) NOT NULL default '',
  `measurethreshold` float(11,4) NOT NULL default '0.0000',
  `operator` varchar(5) NOT NULL default 'noOp',
  `cond` varchar(30) NOT NULL default 'always',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `scorseqrule_idscorul_uix` (`id`,`scoid`,`ruleconditionsid`),
  KEY `scorseqrule_sco2_ix` (`scoid`),
  KEY `scorseqrule_rul_ix` (`ruleconditionsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 rule condition';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scorm_seq_rulecond`
--

LOCK TABLES `scorm_seq_rulecond` WRITE;
/*!40000 ALTER TABLE `scorm_seq_rulecond` DISABLE KEYS */;
/*!40000 ALTER TABLE `scorm_seq_rulecond` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scorm_seq_ruleconds`
--

DROP TABLE IF EXISTS `scorm_seq_ruleconds`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `scorm_seq_ruleconds` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `scoid` bigint(10) unsigned NOT NULL default '0',
  `conditioncombination` varchar(3) NOT NULL default 'all',
  `ruletype` tinyint(2) unsigned NOT NULL default '0',
  `action` varchar(25) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `scorseqrule_scoid_uix` (`scoid`,`id`),
  KEY `scorseqrule_sco_ix` (`scoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='SCORM2004 rule conditions';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `scorm_seq_ruleconds`
--

LOCK TABLES `scorm_seq_ruleconds` WRITE;
/*!40000 ALTER TABLE `scorm_seq_ruleconds` DISABLE KEYS */;
/*!40000 ALTER TABLE `scorm_seq_ruleconds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions2`
--

DROP TABLE IF EXISTS `sessions2`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sessions2` (
  `sesskey` varchar(64) NOT NULL default '',
  `expiry` datetime NOT NULL,
  `expireref` varchar(250) default '',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `sessdata` longtext,
  PRIMARY KEY  (`sesskey`),
  KEY `sess_exp_ix` (`expiry`),
  KEY `sess_exp2_ix` (`expireref`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Optional database session storage in new format, not used by';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `sessions2`
--

LOCK TABLES `sessions2` WRITE;
/*!40000 ALTER TABLE `sessions2` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats_daily`
--

DROP TABLE IF EXISTS `stats_daily`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `stats_daily` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `timeend` bigint(10) unsigned NOT NULL default '0',
  `roleid` bigint(10) unsigned NOT NULL default '0',
  `stattype` enum('enrolments','activity','logins') NOT NULL default 'activity',
  `stat1` bigint(10) unsigned NOT NULL default '0',
  `stat2` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `statdail_cou_ix` (`courseid`),
  KEY `statdail_tim_ix` (`timeend`),
  KEY `statdail_rol_ix` (`roleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='to accumulate daily stats';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `stats_daily`
--

LOCK TABLES `stats_daily` WRITE;
/*!40000 ALTER TABLE `stats_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `stats_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats_monthly`
--

DROP TABLE IF EXISTS `stats_monthly`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `stats_monthly` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `timeend` bigint(10) unsigned NOT NULL default '0',
  `roleid` bigint(10) unsigned NOT NULL default '0',
  `stattype` enum('enrolments','activity','logins') NOT NULL default 'activity',
  `stat1` bigint(10) unsigned NOT NULL default '0',
  `stat2` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `statmont_cou_ix` (`courseid`),
  KEY `statmont_tim_ix` (`timeend`),
  KEY `statmont_rol_ix` (`roleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To accumulate monthly stats';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `stats_monthly`
--

LOCK TABLES `stats_monthly` WRITE;
/*!40000 ALTER TABLE `stats_monthly` DISABLE KEYS */;
/*!40000 ALTER TABLE `stats_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats_user_daily`
--

DROP TABLE IF EXISTS `stats_user_daily`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `stats_user_daily` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `roleid` bigint(10) unsigned NOT NULL default '0',
  `timeend` bigint(10) unsigned NOT NULL default '0',
  `statsreads` bigint(10) unsigned NOT NULL default '0',
  `statswrites` bigint(10) unsigned NOT NULL default '0',
  `stattype` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `statuserdail_cou_ix` (`courseid`),
  KEY `statuserdail_use_ix` (`userid`),
  KEY `statuserdail_rol_ix` (`roleid`),
  KEY `statuserdail_tim_ix` (`timeend`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To accumulate daily stats per course/user';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `stats_user_daily`
--

LOCK TABLES `stats_user_daily` WRITE;
/*!40000 ALTER TABLE `stats_user_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `stats_user_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats_user_monthly`
--

DROP TABLE IF EXISTS `stats_user_monthly`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `stats_user_monthly` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `roleid` bigint(10) unsigned NOT NULL default '0',
  `timeend` bigint(10) unsigned NOT NULL default '0',
  `statsreads` bigint(10) unsigned NOT NULL default '0',
  `statswrites` bigint(10) unsigned NOT NULL default '0',
  `stattype` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `statusermont_cou_ix` (`courseid`),
  KEY `statusermont_use_ix` (`userid`),
  KEY `statusermont_rol_ix` (`roleid`),
  KEY `statusermont_tim_ix` (`timeend`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To accumulate monthly stats per course/user';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `stats_user_monthly`
--

LOCK TABLES `stats_user_monthly` WRITE;
/*!40000 ALTER TABLE `stats_user_monthly` DISABLE KEYS */;
/*!40000 ALTER TABLE `stats_user_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats_user_weekly`
--

DROP TABLE IF EXISTS `stats_user_weekly`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `stats_user_weekly` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `roleid` bigint(10) unsigned NOT NULL default '0',
  `timeend` bigint(10) unsigned NOT NULL default '0',
  `statsreads` bigint(10) unsigned NOT NULL default '0',
  `statswrites` bigint(10) unsigned NOT NULL default '0',
  `stattype` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `statuserweek_cou_ix` (`courseid`),
  KEY `statuserweek_use_ix` (`userid`),
  KEY `statuserweek_rol_ix` (`roleid`),
  KEY `statuserweek_tim_ix` (`timeend`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To accumulate weekly stats per course/user';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `stats_user_weekly`
--

LOCK TABLES `stats_user_weekly` WRITE;
/*!40000 ALTER TABLE `stats_user_weekly` DISABLE KEYS */;
/*!40000 ALTER TABLE `stats_user_weekly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats_weekly`
--

DROP TABLE IF EXISTS `stats_weekly`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `stats_weekly` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `timeend` bigint(10) unsigned NOT NULL default '0',
  `roleid` bigint(10) unsigned NOT NULL default '0',
  `stattype` enum('enrolments','activity','logins') NOT NULL default 'activity',
  `stat1` bigint(10) unsigned NOT NULL default '0',
  `stat2` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `statweek_cou_ix` (`courseid`),
  KEY `statweek_tim_ix` (`timeend`),
  KEY `statweek_rol_ix` (`roleid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To accumulate weekly stats';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `stats_weekly`
--

LOCK TABLES `stats_weekly` WRITE;
/*!40000 ALTER TABLE `stats_weekly` DISABLE KEYS */;
/*!40000 ALTER TABLE `stats_weekly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `survey` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `template` bigint(10) unsigned NOT NULL default '0',
  `days` mediumint(6) NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `intro` text NOT NULL,
  `questions` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `surv_cou_ix` (`course`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='Each record is one SURVEY module with its configuration';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `survey`
--

LOCK TABLES `survey` WRITE;
/*!40000 ALTER TABLE `survey` DISABLE KEYS */;
INSERT INTO `survey` VALUES (1,0,0,0,985017600,985017600,'collesaname','collesaintro','25,26,27,28,29,30,43,44'),(2,0,0,0,985017600,985017600,'collespname','collespintro','31,32,33,34,35,36,43,44'),(3,0,0,0,985017600,985017600,'collesapname','collesapintro','37,38,39,40,41,42,43,44'),(4,0,0,0,985017600,985017600,'attlsname','attlsintro','65,67,68'),(5,0,0,0,985017600,985017600,'ciqname','ciqintro','69,70,71,72,73');
/*!40000 ALTER TABLE `survey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_analysis`
--

DROP TABLE IF EXISTS `survey_analysis`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `survey_analysis` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `survey` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `notes` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `survanal_use_ix` (`userid`),
  KEY `survanal_sur_ix` (`survey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='text about each survey submission';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `survey_analysis`
--

LOCK TABLES `survey_analysis` WRITE;
/*!40000 ALTER TABLE `survey_analysis` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_analysis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_answers`
--

DROP TABLE IF EXISTS `survey_answers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `survey_answers` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `survey` bigint(10) unsigned NOT NULL default '0',
  `question` bigint(10) unsigned NOT NULL default '0',
  `time` bigint(10) unsigned NOT NULL default '0',
  `answer1` text NOT NULL,
  `answer2` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `survansw_use_ix` (`userid`),
  KEY `survansw_sur_ix` (`survey`),
  KEY `survansw_que_ix` (`question`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='the answers to each questions filled by the users';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `survey_answers`
--

LOCK TABLES `survey_answers` WRITE;
/*!40000 ALTER TABLE `survey_answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `survey_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `survey_questions`
--

DROP TABLE IF EXISTS `survey_questions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `survey_questions` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `text` varchar(255) NOT NULL default '',
  `shorttext` varchar(30) NOT NULL default '',
  `multi` varchar(100) NOT NULL default '',
  `intro` varchar(50) NOT NULL default '',
  `type` smallint(3) NOT NULL default '0',
  `options` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8 COMMENT='the questions conforming one survey';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `survey_questions`
--

LOCK TABLES `survey_questions` WRITE;
/*!40000 ALTER TABLE `survey_questions` DISABLE KEYS */;
INSERT INTO `survey_questions` VALUES (1,'colles1','colles1short','','',1,'scaletimes5'),(2,'colles2','colles2short','','',1,'scaletimes5'),(3,'colles3','colles3short','','',1,'scaletimes5'),(4,'colles4','colles4short','','',1,'scaletimes5'),(5,'colles5','colles5short','','',1,'scaletimes5'),(6,'colles6','colles6short','','',1,'scaletimes5'),(7,'colles7','colles7short','','',1,'scaletimes5'),(8,'colles8','colles8short','','',1,'scaletimes5'),(9,'colles9','colles9short','','',1,'scaletimes5'),(10,'colles10','colles10short','','',1,'scaletimes5'),(11,'colles11','colles11short','','',1,'scaletimes5'),(12,'colles12','colles12short','','',1,'scaletimes5'),(13,'colles13','colles13short','','',1,'scaletimes5'),(14,'colles14','colles14short','','',1,'scaletimes5'),(15,'colles15','colles15short','','',1,'scaletimes5'),(16,'colles16','colles16short','','',1,'scaletimes5'),(17,'colles17','colles17short','','',1,'scaletimes5'),(18,'colles18','colles18short','','',1,'scaletimes5'),(19,'colles19','colles19short','','',1,'scaletimes5'),(20,'colles20','colles20short','','',1,'scaletimes5'),(21,'colles21','colles21short','','',1,'scaletimes5'),(22,'colles22','colles22short','','',1,'scaletimes5'),(23,'colles23','colles23short','','',1,'scaletimes5'),(24,'colles24','colles24short','','',1,'scaletimes5'),(25,'collesm1','collesm1short','1,2,3,4','collesmintro',1,'scaletimes5'),(26,'collesm2','collesm2short','5,6,7,8','collesmintro',1,'scaletimes5'),(27,'collesm3','collesm3short','9,10,11,12','collesmintro',1,'scaletimes5'),(28,'collesm4','collesm4short','13,14,15,16','collesmintro',1,'scaletimes5'),(29,'collesm5','collesm5short','17,18,19,20','collesmintro',1,'scaletimes5'),(30,'collesm6','collesm6short','21,22,23,24','collesmintro',1,'scaletimes5'),(31,'collesm1','collesm1short','1,2,3,4','collesmintro',2,'scaletimes5'),(32,'collesm2','collesm2short','5,6,7,8','collesmintro',2,'scaletimes5'),(33,'collesm3','collesm3short','9,10,11,12','collesmintro',2,'scaletimes5'),(34,'collesm4','collesm4short','13,14,15,16','collesmintro',2,'scaletimes5'),(35,'collesm5','collesm5short','17,18,19,20','collesmintro',2,'scaletimes5'),(36,'collesm6','collesm6short','21,22,23,24','collesmintro',2,'scaletimes5'),(37,'collesm1','collesm1short','1,2,3,4','collesmintro',3,'scaletimes5'),(38,'collesm2','collesm2short','5,6,7,8','collesmintro',3,'scaletimes5'),(39,'collesm3','collesm3short','9,10,11,12','collesmintro',3,'scaletimes5'),(40,'collesm4','collesm4short','13,14,15,16','collesmintro',3,'scaletimes5'),(41,'collesm5','collesm5short','17,18,19,20','collesmintro',3,'scaletimes5'),(42,'collesm6','collesm6short','21,22,23,24','collesmintro',3,'scaletimes5'),(43,'howlong','','','',1,'howlongoptions'),(44,'othercomments','','','',0,NULL),(45,'attls1','attls1short','','',1,'scaleagree5'),(46,'attls2','attls2short','','',1,'scaleagree5'),(47,'attls3','attls3short','','',1,'scaleagree5'),(48,'attls4','attls4short','','',1,'scaleagree5'),(49,'attls5','attls5short','','',1,'scaleagree5'),(50,'attls6','attls6short','','',1,'scaleagree5'),(51,'attls7','attls7short','','',1,'scaleagree5'),(52,'attls8','attls8short','','',1,'scaleagree5'),(53,'attls9','attls9short','','',1,'scaleagree5'),(54,'attls10','attls10short','','',1,'scaleagree5'),(55,'attls11','attls11short','','',1,'scaleagree5'),(56,'attls12','attls12short','','',1,'scaleagree5'),(57,'attls13','attls13short','','',1,'scaleagree5'),(58,'attls14','attls14short','','',1,'scaleagree5'),(59,'attls15','attls15short','','',1,'scaleagree5'),(60,'attls16','attls16short','','',1,'scaleagree5'),(61,'attls17','attls17short','','',1,'scaleagree5'),(62,'attls18','attls18short','','',1,'scaleagree5'),(63,'attls19','attls19short','','',1,'scaleagree5'),(64,'attls20','attls20short','','',1,'scaleagree5'),(65,'attlsm1','attlsm1','45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64','attlsmintro',1,'scaleagree5'),(66,'-','-','-','-',0,'-'),(67,'attlsm2','attlsm2','63,62,59,57,55,49,52,50,48,47','attlsmintro',-1,'scaleagree5'),(68,'attlsm3','attlsm3','46,54,45,51,60,53,56,58,61,64','attlsmintro',-1,'scaleagree5'),(69,'ciq1','ciq1short','','',0,NULL),(70,'ciq2','ciq2short','','',0,NULL),(71,'ciq3','ciq3short','','',0,NULL),(72,'ciq4','ciq4short','','',0,NULL),(73,'ciq5','ciq5short','','',0,NULL);
/*!40000 ALTER TABLE `survey_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `tag` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL default '',
  `rawname` varchar(255) NOT NULL default '',
  `tagtype` varchar(255) default NULL,
  `description` text,
  `descriptionformat` tinyint(2) unsigned NOT NULL default '0',
  `flag` smallint(4) unsigned default '0',
  `timemodified` bigint(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `tag_nam_uix` (`name`),
  KEY `tag_use_ix` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Tag table - this generic table will replace the old "tags" t';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_correlation`
--

DROP TABLE IF EXISTS `tag_correlation`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `tag_correlation` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `tagid` bigint(10) unsigned NOT NULL,
  `correlatedtags` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `tagcorr_tag_ix` (`tagid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='The rationale for the ''tag_correlation'' table is performance';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `tag_correlation`
--

LOCK TABLES `tag_correlation` WRITE;
/*!40000 ALTER TABLE `tag_correlation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_correlation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_instance`
--

DROP TABLE IF EXISTS `tag_instance`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `tag_instance` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `tagid` bigint(10) unsigned NOT NULL,
  `itemtype` varchar(255) NOT NULL default '',
  `itemid` bigint(10) unsigned NOT NULL,
  `ordering` bigint(10) unsigned default NULL,
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `taginst_iteitetag_uix` (`itemtype`,`itemid`,`tagid`),
  KEY `taginst_tag_ix` (`tagid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='tag_instance table holds the information of associations bet';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `tag_instance`
--

LOCK TABLES `tag_instance` WRITE;
/*!40000 ALTER TABLE `tag_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timezone`
--

DROP TABLE IF EXISTS `timezone`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `timezone` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `year` bigint(11) NOT NULL default '0',
  `tzrule` varchar(20) NOT NULL default '',
  `gmtoff` bigint(11) NOT NULL default '0',
  `dstoff` bigint(11) NOT NULL default '0',
  `dst_month` tinyint(2) NOT NULL default '0',
  `dst_startday` smallint(3) NOT NULL default '0',
  `dst_weekday` smallint(3) NOT NULL default '0',
  `dst_skipweeks` smallint(3) NOT NULL default '0',
  `dst_time` varchar(6) NOT NULL default '00:00',
  `std_month` tinyint(2) NOT NULL default '0',
  `std_startday` smallint(3) NOT NULL default '0',
  `std_weekday` smallint(3) NOT NULL default '0',
  `std_skipweeks` smallint(3) NOT NULL default '0',
  `std_time` varchar(6) NOT NULL default '00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Rules for calculating local wall clock time for users';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `timezone`
--

LOCK TABLES `timezone` WRITE;
/*!40000 ALTER TABLE `timezone` DISABLE KEYS */;
/*!40000 ALTER TABLE `timezone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `auth` varchar(20) NOT NULL default 'manual',
  `confirmed` tinyint(1) NOT NULL default '0',
  `policyagreed` tinyint(1) NOT NULL default '0',
  `deleted` tinyint(1) NOT NULL default '0',
  `mnethostid` bigint(10) unsigned NOT NULL default '0',
  `username` varchar(100) NOT NULL default '',
  `password` varchar(32) NOT NULL default '',
  `idnumber` varchar(255) NOT NULL default '',
  `firstname` varchar(100) NOT NULL default '',
  `lastname` varchar(100) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `emailstop` tinyint(1) unsigned NOT NULL default '0',
  `icq` varchar(15) NOT NULL default '',
  `skype` varchar(50) NOT NULL default '',
  `yahoo` varchar(50) NOT NULL default '',
  `aim` varchar(50) NOT NULL default '',
  `msn` varchar(50) NOT NULL default '',
  `phone1` varchar(20) NOT NULL default '',
  `phone2` varchar(20) NOT NULL default '',
  `institution` varchar(40) NOT NULL default '',
  `department` varchar(30) NOT NULL default '',
  `address` varchar(70) NOT NULL default '',
  `city` varchar(20) NOT NULL default '',
  `country` varchar(2) NOT NULL default '',
  `lang` varchar(30) NOT NULL default 'en_utf8',
  `theme` varchar(50) NOT NULL default '',
  `timezone` varchar(100) NOT NULL default '99',
  `firstaccess` bigint(10) unsigned NOT NULL default '0',
  `lastaccess` bigint(10) unsigned NOT NULL default '0',
  `lastlogin` bigint(10) unsigned NOT NULL default '0',
  `currentlogin` bigint(10) unsigned NOT NULL default '0',
  `lastip` varchar(15) NOT NULL default '',
  `secret` varchar(15) NOT NULL default '',
  `picture` tinyint(1) NOT NULL default '0',
  `url` varchar(255) NOT NULL default '',
  `description` text,
  `mailformat` tinyint(1) unsigned NOT NULL default '1',
  `maildigest` tinyint(1) unsigned NOT NULL default '0',
  `maildisplay` tinyint(2) unsigned NOT NULL default '2',
  `htmleditor` tinyint(1) unsigned NOT NULL default '1',
  `ajax` tinyint(1) unsigned NOT NULL default '1',
  `autosubscribe` tinyint(1) unsigned NOT NULL default '1',
  `trackforums` tinyint(1) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `trustbitmask` bigint(10) unsigned NOT NULL default '0',
  `imagealt` varchar(255) default NULL,
  `screenreader` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `user_mneuse_uix` (`mnethostid`,`username`),
  KEY `user_del_ix` (`deleted`),
  KEY `user_con_ix` (`confirmed`),
  KEY `user_fir_ix` (`firstname`),
  KEY `user_las_ix` (`lastname`),
  KEY `user_cit_ix` (`city`),
  KEY `user_cou_ix` (`country`),
  KEY `user_las2_ix` (`lastaccess`),
  KEY `user_ema_ix` (`email`),
  KEY `user_aut_ix` (`auth`),
  KEY `user_idn_ix` (`idnumber`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='One record for each person';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'manual',1,0,0,1,'guest','084e0343a0486ff05530df6c705c8bb4','','Guest User',' ','root@localhost',0,'','','','','','','','','','','','','en_utf8','','99',0,0,0,0,'','',0,'','This user is a special user that allows read-only access to some courses.',1,0,2,1,1,1,0,1253737996,0,NULL,0),(2,'manual',1,0,0,1,'so-admin','b2d7c76236c0891adac2b0e0dbed6cd4','','Switched','On','moodle_so_admin@switchedon.org',0,'','','','','','','','','','','Ipswich','GB','en_utf8','','99',0,1253743628,0,0,'','',0,'','',1,0,1,1,1,1,0,1253738276,0,NULL,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_info_category`
--

DROP TABLE IF EXISTS `user_info_category`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_info_category` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `sortorder` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Customisable fields categories';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_info_category`
--

LOCK TABLES `user_info_category` WRITE;
/*!40000 ALTER TABLE `user_info_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_info_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_info_data`
--

DROP TABLE IF EXISTS `user_info_data`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_info_data` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `fieldid` bigint(10) unsigned NOT NULL default '0',
  `data` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Data for the customisable user fields';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_info_data`
--

LOCK TABLES `user_info_data` WRITE;
/*!40000 ALTER TABLE `user_info_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_info_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_info_field`
--

DROP TABLE IF EXISTS `user_info_field`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_info_field` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `shortname` varchar(255) NOT NULL default 'shortname',
  `name` longtext NOT NULL,
  `datatype` varchar(255) NOT NULL default '',
  `description` longtext,
  `categoryid` bigint(10) unsigned NOT NULL default '0',
  `sortorder` bigint(10) unsigned NOT NULL default '0',
  `required` tinyint(2) unsigned NOT NULL default '0',
  `locked` tinyint(2) unsigned NOT NULL default '0',
  `visible` smallint(4) unsigned NOT NULL default '0',
  `forceunique` tinyint(2) unsigned NOT NULL default '0',
  `signup` tinyint(2) unsigned NOT NULL default '0',
  `defaultdata` longtext,
  `param1` longtext,
  `param2` longtext,
  `param3` longtext,
  `param4` longtext,
  `param5` longtext,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Customisable user profile fields';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_info_field`
--

LOCK TABLES `user_info_field` WRITE;
/*!40000 ALTER TABLE `user_info_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_info_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_lastaccess`
--

DROP TABLE IF EXISTS `user_lastaccess`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_lastaccess` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `courseid` bigint(10) unsigned NOT NULL default '0',
  `timeaccess` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userlast_usecou_uix` (`userid`,`courseid`),
  KEY `userlast_use_ix` (`userid`),
  KEY `userlast_cou_ix` (`courseid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='To keep track of course page access times, used in online pa';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_lastaccess`
--

LOCK TABLES `user_lastaccess` WRITE;
/*!40000 ALTER TABLE `user_lastaccess` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_lastaccess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_preferences`
--

DROP TABLE IF EXISTS `user_preferences`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_preferences` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `userid` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `userpref_usenam_uix` (`userid`,`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Allows modules to store arbitrary user preferences';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_preferences`
--

LOCK TABLES `user_preferences` WRITE;
/*!40000 ALTER TABLE `user_preferences` DISABLE KEYS */;
INSERT INTO `user_preferences` VALUES (1,2,'auth_forcepasswordchange','0'),(2,2,'email_bounce_count','1'),(3,2,'email_send_count','1');
/*!40000 ALTER TABLE `user_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_private_key`
--

DROP TABLE IF EXISTS `user_private_key`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_private_key` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `script` varchar(128) NOT NULL default '',
  `value` varchar(128) NOT NULL default '',
  `userid` bigint(10) unsigned NOT NULL,
  `instance` bigint(10) unsigned default NULL,
  `iprestriction` varchar(255) default NULL,
  `validuntil` bigint(10) unsigned default NULL,
  `timecreated` bigint(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  KEY `userprivkey_scrval_ix` (`script`,`value`),
  KEY `userprivkey_use_ix` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='access keys used in cookieless scripts - rss, etc.';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_private_key`
--

LOCK TABLES `user_private_key` WRITE;
/*!40000 ALTER TABLE `user_private_key` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_private_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webdav_locks`
--

DROP TABLE IF EXISTS `webdav_locks`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `webdav_locks` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `token` varchar(255) NOT NULL default '',
  `path` varchar(255) NOT NULL default '',
  `expiry` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `recursive` tinyint(1) unsigned NOT NULL default '0',
  `exclusivelock` tinyint(1) unsigned NOT NULL default '0',
  `created` bigint(10) unsigned NOT NULL default '0',
  `modified` bigint(10) unsigned NOT NULL default '0',
  `owner` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `webdlock_tok_uix` (`token`),
  KEY `webdlock_pat_ix` (`path`),
  KEY `webdlock_exp_ix` (`expiry`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Resource locks for WebDAV users';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `webdav_locks`
--

LOCK TABLES `webdav_locks` WRITE;
/*!40000 ALTER TABLE `webdav_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `webdav_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki`
--

DROP TABLE IF EXISTS `wiki`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `wiki` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `summary` text NOT NULL,
  `pagename` varchar(255) NOT NULL default '',
  `wtype` enum('teacher','group','student') NOT NULL default 'group',
  `ewikiprinttitle` smallint(4) unsigned NOT NULL default '1',
  `htmlmode` smallint(4) unsigned NOT NULL default '0',
  `ewikiacceptbinary` smallint(4) unsigned NOT NULL default '0',
  `disablecamelcase` smallint(4) unsigned NOT NULL default '0',
  `setpageflags` smallint(4) unsigned NOT NULL default '1',
  `strippages` smallint(4) unsigned NOT NULL default '1',
  `removepages` smallint(4) unsigned NOT NULL default '1',
  `revertchanges` smallint(4) unsigned NOT NULL default '1',
  `initialcontent` varchar(255) NOT NULL default '',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `wiki_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Main wik table';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `wiki`
--

LOCK TABLES `wiki` WRITE;
/*!40000 ALTER TABLE `wiki` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_entries`
--

DROP TABLE IF EXISTS `wiki_entries`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `wiki_entries` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `wikiid` bigint(10) unsigned NOT NULL default '0',
  `course` bigint(10) unsigned NOT NULL default '0',
  `groupid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `pagename` varchar(255) NOT NULL default '',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `wikientr_cou_ix` (`course`),
  KEY `wikientr_gro_ix` (`groupid`),
  KEY `wikientr_use_ix` (`userid`),
  KEY `wikientr_pag_ix` (`pagename`),
  KEY `wikientr_wik_ix` (`wikiid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Holds entries for each wiki start instance';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `wiki_entries`
--

LOCK TABLES `wiki_entries` WRITE;
/*!40000 ALTER TABLE `wiki_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_locks`
--

DROP TABLE IF EXISTS `wiki_locks`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `wiki_locks` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `wikiid` bigint(10) unsigned NOT NULL,
  `pagename` varchar(160) NOT NULL default '',
  `lockedby` bigint(10) unsigned NOT NULL default '0',
  `lockedsince` bigint(10) unsigned NOT NULL default '0',
  `lockedseen` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `wikilock_wikpag_uix` (`wikiid`,`pagename`),
  KEY `wikilock_loc_ix` (`lockedseen`),
  KEY `wikilock_wik_ix` (`wikiid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Stores editing locks on Wiki pages';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `wiki_locks`
--

LOCK TABLES `wiki_locks` WRITE;
/*!40000 ALTER TABLE `wiki_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wiki_pages`
--

DROP TABLE IF EXISTS `wiki_pages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `wiki_pages` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `pagename` varchar(160) NOT NULL default '',
  `version` bigint(10) unsigned NOT NULL default '0',
  `flags` bigint(10) unsigned default '0',
  `content` mediumtext,
  `author` varchar(100) default 'ewiki',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `created` bigint(10) unsigned default '0',
  `lastmodified` bigint(10) unsigned default '0',
  `refs` mediumtext,
  `meta` mediumtext,
  `hits` bigint(10) unsigned default '0',
  `wiki` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `wikipage_pagverwik_uix` (`pagename`,`version`,`wiki`),
  KEY `wikipage_wik_ix` (`wiki`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Holds the Wiki-Pages';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `wiki_pages`
--

LOCK TABLES `wiki_pages` WRITE;
/*!40000 ALTER TABLE `wiki_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `wiki_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workshop`
--

DROP TABLE IF EXISTS `workshop`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `workshop` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `course` bigint(10) unsigned NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `description` text NOT NULL,
  `wtype` smallint(3) unsigned NOT NULL default '0',
  `nelements` smallint(3) unsigned NOT NULL default '1',
  `nattachments` smallint(3) unsigned NOT NULL default '0',
  `phase` tinyint(2) unsigned NOT NULL default '0',
  `format` tinyint(2) unsigned NOT NULL default '0',
  `gradingstrategy` tinyint(2) unsigned NOT NULL default '1',
  `resubmit` tinyint(2) unsigned NOT NULL default '0',
  `agreeassessments` tinyint(2) unsigned NOT NULL default '0',
  `hidegrades` tinyint(2) unsigned NOT NULL default '0',
  `anonymous` tinyint(2) unsigned NOT NULL default '0',
  `includeself` tinyint(2) unsigned NOT NULL default '0',
  `maxbytes` bigint(10) unsigned NOT NULL default '100000',
  `submissionstart` bigint(10) unsigned NOT NULL default '0',
  `assessmentstart` bigint(10) unsigned NOT NULL default '0',
  `submissionend` bigint(10) unsigned NOT NULL default '0',
  `assessmentend` bigint(10) unsigned NOT NULL default '0',
  `releasegrades` bigint(10) unsigned NOT NULL default '0',
  `grade` smallint(3) NOT NULL default '0',
  `gradinggrade` smallint(3) NOT NULL default '0',
  `ntassessments` smallint(3) unsigned NOT NULL default '0',
  `assessmentcomps` smallint(3) unsigned NOT NULL default '2',
  `nsassessments` smallint(3) unsigned NOT NULL default '0',
  `overallocation` smallint(3) unsigned NOT NULL default '0',
  `timemodified` bigint(10) unsigned NOT NULL default '0',
  `teacherweight` smallint(3) unsigned NOT NULL default '1',
  `showleaguetable` smallint(3) unsigned NOT NULL default '0',
  `usepassword` smallint(3) unsigned NOT NULL default '0',
  `password` varchar(32) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `work_cou_ix` (`course`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines workshop';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `workshop`
--

LOCK TABLES `workshop` WRITE;
/*!40000 ALTER TABLE `workshop` DISABLE KEYS */;
/*!40000 ALTER TABLE `workshop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workshop_assessments`
--

DROP TABLE IF EXISTS `workshop_assessments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `workshop_assessments` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `workshopid` bigint(10) unsigned NOT NULL default '0',
  `submissionid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `timegraded` bigint(10) unsigned NOT NULL default '0',
  `timeagreed` bigint(10) unsigned NOT NULL default '0',
  `grade` double NOT NULL default '0',
  `gradinggrade` smallint(3) NOT NULL default '0',
  `teachergraded` smallint(3) unsigned NOT NULL default '0',
  `mailed` smallint(3) unsigned NOT NULL default '0',
  `resubmission` smallint(3) unsigned NOT NULL default '0',
  `donotuse` smallint(3) unsigned NOT NULL default '0',
  `generalcomment` text NOT NULL,
  `teachercomment` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `workasse_use_ix` (`userid`),
  KEY `workasse_mai_ix` (`mailed`),
  KEY `workasse_wor_ix` (`workshopid`),
  KEY `workasse_sub_ix` (`submissionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about assessments by teacher and students';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `workshop_assessments`
--

LOCK TABLES `workshop_assessments` WRITE;
/*!40000 ALTER TABLE `workshop_assessments` DISABLE KEYS */;
/*!40000 ALTER TABLE `workshop_assessments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workshop_comments`
--

DROP TABLE IF EXISTS `workshop_comments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `workshop_comments` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `workshopid` bigint(10) unsigned NOT NULL default '0',
  `assessmentid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `mailed` tinyint(2) unsigned NOT NULL default '0',
  `comments` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `workcomm_use_ix` (`userid`),
  KEY `workcomm_mai_ix` (`mailed`),
  KEY `workcomm_wor_ix` (`workshopid`),
  KEY `workcomm_ass_ix` (`assessmentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Defines comments';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `workshop_comments`
--

LOCK TABLES `workshop_comments` WRITE;
/*!40000 ALTER TABLE `workshop_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `workshop_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workshop_elements`
--

DROP TABLE IF EXISTS `workshop_elements`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `workshop_elements` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `workshopid` bigint(10) unsigned NOT NULL default '0',
  `elementno` smallint(3) unsigned NOT NULL default '0',
  `description` text NOT NULL,
  `scale` smallint(3) unsigned NOT NULL default '0',
  `maxscore` smallint(3) unsigned NOT NULL default '1',
  `weight` smallint(3) unsigned NOT NULL default '11',
  `stddev` double NOT NULL default '0',
  `totalassessments` bigint(10) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `workelem_wor_ix` (`workshopid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about marking scheme of assignment';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `workshop_elements`
--

LOCK TABLES `workshop_elements` WRITE;
/*!40000 ALTER TABLE `workshop_elements` DISABLE KEYS */;
/*!40000 ALTER TABLE `workshop_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workshop_grades`
--

DROP TABLE IF EXISTS `workshop_grades`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `workshop_grades` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `workshopid` bigint(10) unsigned NOT NULL default '0',
  `assessmentid` bigint(10) unsigned NOT NULL default '0',
  `elementno` bigint(10) unsigned NOT NULL default '0',
  `feedback` text NOT NULL,
  `grade` smallint(3) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `workgrad_wor_ix` (`workshopid`),
  KEY `workgrad_ass_ix` (`assessmentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about individual grades given to each element';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `workshop_grades`
--

LOCK TABLES `workshop_grades` WRITE;
/*!40000 ALTER TABLE `workshop_grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `workshop_grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workshop_rubrics`
--

DROP TABLE IF EXISTS `workshop_rubrics`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `workshop_rubrics` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `workshopid` bigint(10) unsigned NOT NULL default '0',
  `elementno` bigint(10) unsigned NOT NULL default '0',
  `rubricno` smallint(3) unsigned NOT NULL default '0',
  `description` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `workrubr_wor_ix` (`workshopid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about the rubrics marking scheme';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `workshop_rubrics`
--

LOCK TABLES `workshop_rubrics` WRITE;
/*!40000 ALTER TABLE `workshop_rubrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `workshop_rubrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workshop_stockcomments`
--

DROP TABLE IF EXISTS `workshop_stockcomments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `workshop_stockcomments` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `workshopid` bigint(10) unsigned NOT NULL default '0',
  `elementno` bigint(10) unsigned NOT NULL default '0',
  `comments` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `workstoc_wor_ix` (`workshopid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about the teacher comment bank';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `workshop_stockcomments`
--

LOCK TABLES `workshop_stockcomments` WRITE;
/*!40000 ALTER TABLE `workshop_stockcomments` DISABLE KEYS */;
/*!40000 ALTER TABLE `workshop_stockcomments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workshop_submissions`
--

DROP TABLE IF EXISTS `workshop_submissions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `workshop_submissions` (
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `workshopid` bigint(10) unsigned NOT NULL default '0',
  `userid` bigint(10) unsigned NOT NULL default '0',
  `title` varchar(100) NOT NULL default '',
  `timecreated` bigint(10) unsigned NOT NULL default '0',
  `mailed` tinyint(2) unsigned NOT NULL default '0',
  `description` text NOT NULL,
  `gradinggrade` smallint(3) unsigned NOT NULL default '0',
  `finalgrade` smallint(3) unsigned NOT NULL default '0',
  `late` smallint(3) unsigned NOT NULL default '0',
  `nassessments` bigint(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `worksubm_use_ix` (`userid`),
  KEY `worksubm_mai_ix` (`mailed`),
  KEY `worksubm_wor_ix` (`workshopid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Info about submitted work from teacher and students';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `workshop_submissions`
--

LOCK TABLES `workshop_submissions` WRITE;
/*!40000 ALTER TABLE `workshop_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `workshop_submissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-09-23 22:13:09
